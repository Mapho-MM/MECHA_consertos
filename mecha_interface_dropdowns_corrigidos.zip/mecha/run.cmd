@echo off
cd /d "%~dp0"
if exist mvnw.cmd (
  call mvnw.cmd clean javafx:run
) else (
  mvn clean javafx:run
)
pause
