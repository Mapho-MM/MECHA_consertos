package com.senai.javafx.projeto02.entidades;

public class PecaUtilizada {
    private final Estoque origemEstoque;
    private final String nome;
    private final double precoUnitario;
    private int quantidade;

    public PecaUtilizada(Estoque origemEstoque, int quantidade) {
        if (origemEstoque == null) throw new IllegalArgumentException("A peça de origem é obrigatória.");
        if (quantidade <= 0) throw new IllegalArgumentException("A quantidade deve ser positiva.");
        this.origemEstoque = origemEstoque;
        this.nome = origemEstoque.getProduto();
        this.precoUnitario = origemEstoque.getPreco();
        this.quantidade = quantidade;
    }

    public Estoque getOrigemEstoque() { return origemEstoque; }
    public String getNome() { return nome; }
    public double getPrecoUnitario() { return precoUnitario; }
    public int getQuantidade() { return quantidade; }
    public double getSubtotal() { return precoUnitario * quantidade; }

    public void setQuantidade(int quantidade) {
        if (quantidade <= 0) throw new IllegalArgumentException("A quantidade deve ser positiva.");
        this.quantidade = quantidade;
    }
}
