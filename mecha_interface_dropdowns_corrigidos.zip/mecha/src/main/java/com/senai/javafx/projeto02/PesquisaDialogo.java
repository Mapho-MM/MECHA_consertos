package com.senai.javafx.projeto02;

import javafx.application.Platform;
import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.LinkedHashMap;
import java.util.Map;

import com.senai.javafx.projeto02.Tema.Paleta;

import static com.senai.javafx.projeto02.Tema.*;
import static com.senai.javafx.projeto02.Dialogos.*;

/** Janela de pesquisa com sugestões. Cada tela informa os itens (rotas) que quer oferecer. */
public final class PesquisaDialogo {

    private PesquisaDialogo() {
    }

    private static final Map<String, String> ICONES = new LinkedHashMap<>();
    static {
        ICONES.put("Dashboard", "⌂");
        ICONES.put("Início", "⌂");
        ICONES.put("Serviços", "🔧");
        ICONES.put("Atendimentos", "📋");
        ICONES.put("Meus atendimentos", "📋");
        ICONES.put("Veículos", "🚗");
        ICONES.put("Estoque", "📦");
        ICONES.put("Funcionários", "👥");
        ICONES.put("Financeiro", "💰");
        ICONES.put("Relatórios", "📊");
        ICONES.put("Minhas tarefas", "✓");
    }

    public static void abrir(Map<String, Runnable> rotas) {
        try {
            abrirPesquisaSegura(rotas);
        } catch (Exception e) {
            e.printStackTrace();
            mostrarMensagem("Pesquisar", "Não foi possível abrir a pesquisa.");
        }
    }

    private static void abrirPesquisaSegura(Map<String, Runnable> rotas) {
        Paleta p = paletaAtual();
        Stage janela = criarJanelaTematica();
        VBox cartao = criarCartaoTematico(480, p);
        cartao.setSpacing(14);

        Label dica = criarTexto("Digite para filtrar e clique (ou Enter) para abrir o módulo.", p);
        dica.setWrapText(true);
        dica.setStyle("-fx-text-fill: " + p.textoSec() + "; -fx-font-size: 12px;");

        TextField campo = new TextField();
        campo.setPromptText("Ex.: estoque, veículos, nota fiscal...");
        campo.setPrefHeight(48);
        campo.setStyle(
                "-fx-background-color: " + p.overlay() + "0.12);" +
                "-fx-text-fill: " + p.texto() + ";" +
                "-fx-prompt-text-fill: " + p.textoTerc() + ";" +
                "-fx-background-radius: 14;" +
                "-fx-border-color: " + p.borda() + ";" +
                "-fx-border-radius: 14;" +
                "-fx-border-width: 1;" +
                "-fx-font-size: 14px;" +
                "-fx-padding: 0 14 0 14;"
        );

        Label contador = new Label();
        contador.setStyle("-fx-text-fill: " + p.textoTerc() + "; -fx-font-size: 11px;");

        ListView<String> sugestoes = new ListView<>();
        sugestoes.setPrefHeight(280);
        sugestoes.setMaxHeight(280);
        sugestoes.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        sugestoes.setFocusTraversable(true);

        // Fundo da lista no tema (evita o branco padrão do JavaFX)
        sugestoes.setStyle(
                "-fx-background-color: " + p.overlay() + "0.08);" +
                "-fx-background-radius: 14;" +
                "-fx-border-color: " + p.borda() + ";" +
                "-fx-border-radius: 14;" +
                "-fx-border-width: 1;" +
                "-fx-control-inner-background: transparent;" +
                "-fx-background-insets: 0;" +
                "-fx-padding: 6;"
        );

        // Células customizadas no tema escuro/claro
        final String textoCor = p.texto();
        final String textoSec = p.textoSec();
        final String overlay = p.overlay();
        final String destaqueFundo = fundoDestaque();
        final String textoSobre = textoSobreDestaque();

        sugestoes.setCellFactory(list -> new ListCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);
                    setStyle("-fx-background-color: transparent;");
                    return;
                }
                String icone = ICONES.getOrDefault(item, "•");
                Label iconLbl = new Label(icone);
                iconLbl.setStyle("-fx-font-size: 15px; -fx-min-width: 28px;");

                Label nomeLbl = new Label(item);
                nomeLbl.setStyle("-fx-font-size: 13px; -fx-font-weight: bold;");

                Label desc = new Label("Abrir módulo");
                desc.setStyle("-fx-font-size: 10px;");

                VBox textos = new VBox(1, nomeLbl, desc);
                HBox row = new HBox(10, iconLbl, textos);
                row.setAlignment(Pos.CENTER_LEFT);
                row.setPadding(new Insets(6, 10, 6, 10));
                setGraphic(row);
                setText(null);

                if (isSelected() || isFocused()) {
                    nomeLbl.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: " + textoSobre + ";");
                    desc.setStyle("-fx-font-size: 10px; -fx-text-fill: " + textoSobre + ";");
                    iconLbl.setStyle("-fx-font-size: 15px; -fx-min-width: 28px; -fx-text-fill: " + textoSobre + ";");
                    setStyle(
                            "-fx-background-color: " + destaqueFundo + ";" +
                            "-fx-background-radius: 10;" +
                            "-fx-cursor: hand;"
                    );
                } else {
                    nomeLbl.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: " + textoCor + ";");
                    desc.setStyle("-fx-font-size: 10px; -fx-text-fill: " + textoSec + ";");
                    iconLbl.setStyle("-fx-font-size: 15px; -fx-min-width: 28px; -fx-text-fill: " + textoCor + ";");
                    setStyle(
                            "-fx-background-color: transparent;" +
                            "-fx-background-radius: 10;" +
                            "-fx-cursor: hand;"
                    );
                }
            }
        });

        Label vazio = new Label("Nenhum módulo encontrado");
        vazio.setStyle("-fx-text-fill: " + p.textoTerc() + "; -fx-font-size: 13px;");
        sugestoes.setPlaceholder(vazio);

        Label resultado = criarTexto("", p);
        resultado.setStyle("-fx-text-fill: " + p.textoSec() + "; -fx-font-size: 12px;");

        Runnable atualizarSugestoes = () -> {
            String filtro = campo.getText() == null ? "" : campo.getText().trim().toLowerCase();
            sugestoes.getItems().clear();
            for (String chave : rotas.keySet()) {
                if (filtro.isEmpty() || chave.toLowerCase().contains(filtro)) {
                    sugestoes.getItems().add(chave);
                }
            }
            int n = sugestoes.getItems().size();
            contador.setText(n == 0 ? "0 resultados" : (n + (n == 1 ? " módulo" : " módulos")));
            if (n == 0) {
                resultado.setText(filtro.isEmpty()
                        ? "Nenhum módulo disponível."
                        : "Nada encontrado para \"" + campo.getText().trim() + "\".");
            } else {
                resultado.setText("Enter ou clique para abrir.");
                if (sugestoes.getSelectionModel().isEmpty()) {
                    sugestoes.getSelectionModel().selectFirst();
                }
            }
        };

        Runnable navegarItemSelecionado = () -> {
            String selecionado = sugestoes.getSelectionModel().getSelectedItem();
            if (selecionado == null || selecionado.isBlank()) {
                resultado.setText("Selecione um item da lista.");
                return;
            }
            Runnable rota = rotas.get(selecionado);
            if (rota == null) {
                resultado.setText("Não foi possível abrir esse módulo.");
                return;
            }
            debugLog("Pesquisa: abrindo '" + selecionado + "'.");
            janela.close();
            rota.run();
        };

        campo.textProperty().addListener((obs, a, b) -> atualizarSugestoes.run());

        sugestoes.setOnMouseClicked(event -> {
            if (event.getClickCount() >= 1 && sugestoes.getSelectionModel().getSelectedItem() != null) {
                Platform.runLater(navegarItemSelecionado);
            }
        });

        sugestoes.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                navegarItemSelecionado.run();
                event.consume();
            } else if (event.getCode() == KeyCode.ESCAPE) {
                janela.close();
                event.consume();
            }
        });

        campo.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.DOWN && !sugestoes.getItems().isEmpty()) {
                sugestoes.requestFocus();
                if (sugestoes.getSelectionModel().isEmpty()) {
                    sugestoes.getSelectionModel().selectFirst();
                }
                event.consume();
            } else if (event.getCode() == KeyCode.ENTER) {
                navegarItemSelecionado.run();
                event.consume();
            } else if (event.getCode() == KeyCode.ESCAPE) {
                janela.close();
                event.consume();
            }
        });

        Button fechar = botaoPrimario("Fechar", p);
        fechar.setOnAction(event -> janela.close());

        HBox rodapeInfo = new HBox(contador);
        rodapeInfo.setAlignment(Pos.CENTER_LEFT);

        atualizarSugestoes.run();

        cartao.getChildren().addAll(
                criarTitulo("🔍  Pesquisar", p),
                dica,
                campo,
                rodapeInfo,
                sugestoes,
                resultado,
                fechar
        );
        exibirJanela(janela, cartao);
        Platform.runLater(campo::requestFocus);
    }
}
