package com.senai.javafx.projeto02;

import javafx.animation.*;
import javafx.application.Platform;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.effect.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.stage.*;
import javafx.util.Duration;
import java.util.function.Consumer;

import com.senai.javafx.projeto02.Tema.Paleta;

import static com.senai.javafx.projeto02.Tema.*;
import static com.senai.javafx.projeto02.Dialogos.*;

/** Janela de configurações (Tema / Interface / Sobre). Só é aberta pelo menu do administrador e pelo login. */
public final class ConfiguracoesDialogo {

    private ConfiguracoesDialogo() {
    }

    public static void abrir() {
        try {
            abrirConfiguracoesSeguro();
        } catch (Exception e) {
            e.printStackTrace();
            mostrarMensagem("Configurações", "Não foi possível abrir as configurações.");
        } finally {
            if (Navegador.controladorAtual() instanceof LoginController login) {
                login.atualizarBotaoDebug();
            }
        }
    }

    private static void definirTema(int tema, Stage janela) {
        Tema.definirTema(tema);
        janela.close();
    }

    private static void definirCor(int cor, Stage janela) {
        Tema.definirCor(cor);
        janela.close();
    }

    private static void definirTamanhoJanela(int modo, Stage janelaConfiguracoes) {
        try {
            Tema.definirTamanhoJanela(modo);
        } finally {
            janelaConfiguracoes.close();
        }
    }

    /**
     * Ativa/desativa o modo desenvolvedor.
     * Para ATIVAR, exige a senha "123".
     * @return true se o estado mudou conforme solicitado
     */
    private static boolean ativarModoDebug(boolean ativo) {
        if (ativo) {
            String senha = pedirSenhaDebug();
            if (!"123".equals(senha)) {
                mostrarMensagem("Modo desenvolvedor",
                        senha == null
                                ? "Ativação cancelada."
                                : "Senha incorreta. O modo desenvolvedor não foi ativado.");
                return false;
            }
            Tema.definirDebug(true);
            mostrarMensagem("Modo desenvolvedor",
                    "Modo de diagnóstico ativado.\n• Logs técnicos no console\n• Ferramentas de diagnóstico para desenvolvimento\n• O login normal continua exigindo credenciais.");
            return true;
        } else {
            Tema.definirDebug(false);
            mostrarMensagem("Modo desenvolvedor",
                    "Modo de diagnóstico desativado. O login continua protegido por credenciais.");
            return true;
        }
    }

    private static String pedirSenhaDebug() {
        Paleta p = paletaAtual();
        Stage janela = criarJanelaTematica();
        VBox cartao = criarCartaoTematico(380, p);
        cartao.setSpacing(12);

        Label info = criarTexto("Digite a senha do modo desenvolvedor para ativar:", p);
        info.setWrapText(true);

        PasswordField campo = new PasswordField();
        campo.setPromptText("Senha");
        campo.setPrefHeight(44);
        campo.setStyle(
                "-fx-background-color: " + p.overlay() + "0.12);" +
                "-fx-text-fill: " + p.texto() + ";" +
                "-fx-background-radius: 12;" +
                "-fx-border-color: " + p.borda() + ";" +
                "-fx-border-radius: 12;" +
                "-fx-padding: 0 12;"
        );

        final String[] resultado = {null};

        Button confirmar = botaoPrimario("Confirmar", p);
        confirmar.setDefaultButton(true);
        confirmar.setOnAction(e -> {
            resultado[0] = campo.getText() == null ? "" : campo.getText();
            janela.close();
        });

        Button cancelar = botaoSecundario("Cancelar", p);
        cancelar.setCancelButton(true);
        cancelar.setOnAction(e -> {
            resultado[0] = null;
            janela.close();
        });

        campo.setOnAction(e -> confirmar.fire());

        HBox botoes = new HBox(10, cancelar, confirmar);
        botoes.setAlignment(Pos.CENTER);
        HBox.setHgrow(cancelar, Priority.ALWAYS);
        HBox.setHgrow(confirmar, Priority.ALWAYS);
        cancelar.setMaxWidth(Double.MAX_VALUE);
        confirmar.setMaxWidth(Double.MAX_VALUE);

        cartao.getChildren().addAll(
                criarTitulo("Senha do Debug", p),
                info,
                campo,
                botoes
        );
        exibirJanela(janela, cartao);
        return resultado[0];
    }

    private static void abrirConfiguracoesSeguro() {
        Paleta p = paletaAtual();
        Stage janela = criarJanelaTematica();
        VBox cartao = criarCartaoTematico(660, p);
        cartao.setMaxWidth(660);
        cartao.setPrefWidth(660);
        cartao.setSpacing(12);
        cartao.setPadding(new Insets(20));

        // Tamanho FIXO: a janela não muda mais ao trocar de aba (Tema / Interface / Sobre).
        double alturaDisponivel = Screen.getPrimary().getVisualBounds().getHeight() - 140;
        double alturaCartao = Math.max(420, Math.min(580, alturaDisponivel));
        cartao.setPrefHeight(alturaCartao);
        cartao.setMinHeight(alturaCartao);
        cartao.setMaxHeight(alturaCartao);

        VBox conteudo = new VBox(10);
        conteudo.setAlignment(Pos.TOP_CENTER);
        conteudo.setFillWidth(true);
        conteudo.getChildren().setAll(criarConteudoInterfaceConfiguracoes(janela, p));

        Button fechar = botaoSecundario("Fechar", p);
        fechar.setPrefHeight(40);
        fechar.setMaxWidth(220);
        fechar.setOnAction(event -> janela.close());

        // O conteúdo rola dentro de um espaço fixo, então nada fica cortado.
        ScrollPane rolagem = new ScrollPane(conteudo);
        rolagem.setFitToWidth(true);
        rolagem.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        rolagem.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        rolagem.setStyle("-fx-background: transparent; -fx-background-color: transparent; -fx-padding: 0;");
        VBox.setVgrow(rolagem, Priority.ALWAYS);

        cartao.getChildren().addAll(
                criarTitulo("Configurações", p),
                rolagem,
                fechar
        );

        janela.setResizable(true);
        janela.setMinWidth(420);
        janela.setMinHeight(480);
        exibirJanela(janela, cartao);
    }

    public static VBox criarConteudoTemaConfiguracoes(Stage janela, Paleta p) {
        VBox caixa = new VBox(14);
        caixa.setAlignment(Pos.TOP_CENTER);

        Label titulo = criarTituloPequeno("Aparência", p);
        Label legenda = criarTexto("O sistema utiliza apenas o tema escuro.", p);
        legenda.setStyle(legenda.getStyle() + "-fx-font-size: 12px;");

        // Somente tema escuro
        if (modoTema() != 2) {
            definirTema(2, janela);
        }
        HBox temas = new HBox(16);
        temas.setAlignment(Pos.CENTER);
        temas.getChildren().add(
                cardTemaVisual("☾", "Escuro", "Grafite e contraste",
                        "#1a1a1a", "#f5f5f5", "#2a2a2a", true, () -> definirTema(2, janela), p)
        );

        caixa.getChildren().addAll(titulo, legenda, temas);
        return caixa;
    }

    /** Card visual de tema (concept: claro / escuro / dinâmico). */
    private static VBox cardTemaVisual(String icone, String nome, String desc,
                                       String fundoCard, String corTexto, String corBorda,
                                       boolean ativo, Runnable acao, Paleta p) {
        VBox card = new VBox(8);
        card.setAlignment(Pos.CENTER);
        card.setPrefSize(170, 150);
        card.setMinSize(150, 140);
        card.setPadding(new Insets(16, 12, 14, 12));
        card.setCursor(javafx.scene.Cursor.HAND);

        Label badge = new Label(ativo ? "Selecionado" : "Toque para usar");
        badge.setStyle("-fx-font-size: 10px; -fx-text-fill: " + (ativo ? "#22c55e" : corTexto) + "; -fx-opacity: 0.85;");

        Label icon = new Label(icone);
        icon.setStyle("-fx-font-size: 28px; -fx-text-fill: " + corTexto + ";");

        Label title = new Label(nome);
        title.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + corTexto + ";");

        Label sub = new Label(desc);
        sub.setWrapText(true);
        sub.setAlignment(Pos.CENTER);
        sub.setMaxWidth(140);
        sub.setStyle("-fx-font-size: 11px; -fx-text-fill: " + corTexto + "; -fx-opacity: 0.75; -fx-text-alignment: center;");

        String borda = ativo ? "#22c55e" : corBorda;
        String extra = ativo ? "-fx-effect: dropshadow(gaussian, rgba(34,197,94,0.35), 12, 0.2, 0, 2);" : "";
        card.setStyle(
                "-fx-background-color: " + fundoCard + ";" +
                "-fx-background-radius: 18;" +
                "-fx-border-color: " + borda + ";" +
                "-fx-border-radius: 18;" +
                "-fx-border-width: " + (ativo ? "2" : "1") + ";" +
                extra
        );
        card.getChildren().addAll(badge, icon, title, sub);
        card.setOnMouseClicked(e -> acao.run());
        return card;
    }

    public static VBox criarConteudoInterfaceConfiguracoes(Stage janela, Paleta p) {
        VBox caixa = new VBox(10);
        caixa.setAlignment(Pos.TOP_CENTER);

        Label titulo = criarTituloPequeno("Janela do computador", p);
        Label legenda = criarTexto("Escolha um tamanho ou use o monitor automaticamente.", p);
        legenda.setStyle(legenda.getStyle() + "-fx-font-size: 12px;");

        GridPane janelas = new GridPane();
        janelas.setHgap(10);
        janelas.setVgap(10);
        janelas.setAlignment(Pos.CENTER);
        janelas.add(itemOpcaoCompacta("⛶  Tela cheia", "Monitor detectado", modoJanela() == 0, () -> definirTamanhoJanela(0, janela), p), 0, 0);
        janelas.add(itemOpcaoCompacta("▣  1280 × 720", "PC compacto", modoJanela() == 1, () -> definirTamanhoJanela(1, janela), p), 1, 0);
        janelas.add(itemOpcaoCompacta("▣  1440 × 900", "Recomendado", modoJanela() == 2, () -> definirTamanhoJanela(2, janela), p), 0, 1);
        janelas.add(itemOpcaoCompacta("▣  1920 × 1080", "Full HD", modoJanela() == 3, () -> definirTamanhoJanela(3, janela), p), 1, 1);

        Region separador = criarSeparador(p);
        VBox debug = criarInterruptorDebug(p);
        caixa.getChildren().addAll(titulo, legenda, janelas, separador, debug);
        return caixa;
    }

    public static VBox criarConteudoSobre(Paleta p) {
        VBox sobre = new VBox(14);
        sobre.setAlignment(Pos.TOP_CENTER);
        sobre.setPadding(new Insets(8, 8, 14, 8));
        sobre.setFillWidth(true);

        // Cabeçalho de apresentação com identidade visual do sistema.
        HBox cabecalho = new HBox(16);
        cabecalho.setAlignment(Pos.CENTER_LEFT);
        cabecalho.setPadding(new Insets(18));
        cabecalho.setMaxWidth(Double.MAX_VALUE);
        cabecalho.setStyle("-fx-background-color: " + p.fundoCartao() + ";" +
                "-fx-background-radius: 18;" +
                "-fx-border-color: " + p.borda() + ";-fx-border-radius: 18;");

        StackPane simbolo = new StackPane();
        simbolo.setMinSize(72, 72);
        simbolo.setPrefSize(72, 72);
        simbolo.setMaxSize(72, 72);
        simbolo.setStyle("-fx-background-color: " + fundoDestaque() + ";-fx-background-radius: 20;");
        Label marca = new Label("MC");
        marca.setStyle("-fx-text-fill: " + textoSobreDestaque() + ";-fx-font-size: 25px;-fx-font-weight: bold;");
        simbolo.getChildren().add(marca);

        VBox identidade = new VBox(5);
        identidade.setAlignment(Pos.CENTER_LEFT);
        ImageView nome = new ImageView();
        java.net.URL logoUrl = ConfiguracoesDialogo.class.getResource("/com/senai/javafx/projeto02/logo-oficina.png");
        if (logoUrl != null) nome.setImage(new Image(logoUrl.toExternalForm(), true));
        nome.setFitWidth(300);
        nome.setFitHeight(88);
        nome.setPreserveRatio(true);
        nome.setSmooth(true);
        Label subtitulo = new Label("Gestão inteligente para oficina mecânica");
        subtitulo.setWrapText(true);
        subtitulo.setStyle("-fx-text-fill: " + p.textoSec() + ";-fx-font-size: 12px;");
        Label versao = new Label("VERSÃO 1.0-SNAPSHOT");
        versao.setStyle("-fx-text-fill: " + textoSobreDestaque() + ";-fx-background-color: " + fundoDestaque() + ";" +
                "-fx-background-radius: 20;-fx-padding: 5 9 5 9;-fx-font-size: 10px;-fx-font-weight: bold;");
        identidade.getChildren().addAll(nome, subtitulo, versao);
        HBox.setHgrow(identidade, Priority.ALWAYS);
        cabecalho.getChildren().addAll(simbolo, identidade);

        VBox apresentacao = criarCartaoTematico(440, p);
        apresentacao.setMaxWidth(Double.MAX_VALUE);
        apresentacao.setSpacing(7);
        apresentacao.setPadding(new Insets(15));
        Label sobreTitulo = criarTituloPequeno("Sobre o sistema", p);
        Label descricao = criarTexto("Uma aplicação desktop para centralizar a rotina de uma oficina mecânica, facilitar o acompanhamento dos serviços e manter as informações operacionais organizadas em um só lugar.", p);
        descricao.setWrapText(true);
        descricao.setMaxWidth(Double.MAX_VALUE);
        descricao.setStyle(descricao.getStyle() + "-fx-font-size: 12px; -fx-line-spacing: 3px;");
        apresentacao.getChildren().setAll(sobreTitulo, descricao);

        Label recursosTitulo = criarTituloPequeno("Recursos do sistema", p);
        GridPane recursos = new GridPane();
        recursos.setHgap(10);
        recursos.setVgap(10);
        recursos.setMaxWidth(Double.MAX_VALUE);
        ColumnConstraints coluna1 = new ColumnConstraints();
        coluna1.setPercentWidth(50);
        coluna1.setHgrow(Priority.ALWAYS);
        ColumnConstraints coluna2 = new ColumnConstraints();
        coluna2.setPercentWidth(50);
        coluna2.setHgrow(Priority.ALWAYS);
        recursos.getColumnConstraints().addAll(coluna1, coluna2);
        recursos.add(cartaoRecurso("▤", "Ordens de serviço", "Acompanhe etapas e andamento dos trabalhos.", p), 0, 0);
        recursos.add(cartaoRecurso("♙", "Clientes e veículos", "Consulte e organize os cadastros da oficina.", p), 1, 0);
        recursos.add(cartaoRecurso("⚙", "Estoque e peças", "Tenha visão dos itens e movimentações de estoque.", p), 0, 1);
        recursos.add(cartaoRecurso("▥", "Gestão e relatórios", "Apoio à administração e à rotina da equipe.", p), 1, 1);

        VBox tecnologia = criarCartaoTematico(440, p);
        tecnologia.setMaxWidth(Double.MAX_VALUE);
        tecnologia.setPadding(new Insets(14));
        tecnologia.setSpacing(10);
        tecnologia.getChildren().setAll(criarTituloPequeno("Tecnologias", p));
        FlowPane etiquetas = new FlowPane(8, 8);
        etiquetas.setAlignment(Pos.CENTER_LEFT);
        etiquetas.getChildren().addAll(
                etiquetaTecnologia("Java 21", p),
                etiquetaTecnologia("JavaFX 21", p),
                etiquetaTecnologia("Maven", p),
                etiquetaTecnologia("Aplicação desktop", p)
        );
        tecnologia.getChildren().add(etiquetas);

        VBox informacoes = criarCartaoTematico(440, p);
        informacoes.setMaxWidth(Double.MAX_VALUE);
        informacoes.setPadding(new Insets(14));
        informacoes.setSpacing(8);
        informacoes.getChildren().setAll(
                criarTituloPequeno("Informações do projeto", p),
                linhaInformacao("Tipo", "Sistema desktop para oficina", p),
                criarSeparador(p),
                linhaInformacao("Ambiente", "Computador / JavaFX", p),
                criarSeparador(p),
                linhaInformacao("Créditos", "Projeto acadêmico — equipe de desenvolvimento", p)
        );

        Label rodape = criarTexto("© 2026  •  Desenvolvido para organizar o dia a dia da oficina", p);
        rodape.setWrapText(true);
        rodape.setTextAlignment(TextAlignment.CENTER);
        rodape.setStyle(rodape.getStyle() + "-fx-font-size: 10px;");

        sobre.getChildren().addAll(cabecalho, apresentacao, recursosTitulo, recursos, tecnologia, informacoes, rodape);
        return sobre;
    }

    private static VBox cartaoRecurso(String icone, String titulo, String descricao, Paleta p) {
        VBox cartao = new VBox(7);
        cartao.setPadding(new Insets(13));
        cartao.setMinHeight(112);
        cartao.setMaxWidth(Double.MAX_VALUE);
        cartao.setStyle("-fx-background-color: " + p.fundoCartao() + ";-fx-background-radius: 14;" +
                "-fx-border-color: " + p.borda() + ";-fx-border-radius: 14;");
        Label simbolo = new Label(icone);
        simbolo.setStyle("-fx-text-fill: " + p.link() + ";-fx-font-size: 19px;-fx-font-weight: bold;");
        Label nome = new Label(titulo);
        nome.setWrapText(true);
        nome.setStyle("-fx-text-fill: " + p.texto() + ";-fx-font-size: 12px;-fx-font-weight: bold;");
        Label detalhe = new Label(descricao);
        detalhe.setWrapText(true);
        detalhe.setStyle("-fx-text-fill: " + p.textoSec() + ";-fx-font-size: 10px;");
        cartao.getChildren().addAll(simbolo, nome, detalhe);
        return cartao;
    }

    private static Label etiquetaTecnologia(String texto, Paleta p) {
        Label etiqueta = new Label(texto);
        etiqueta.setStyle("-fx-background-color: " + p.overlay() + ";-fx-background-radius: 14;" +
                "-fx-border-color: " + p.borda() + ";-fx-border-radius: 14;" +
                "-fx-text-fill: " + p.texto() + ";-fx-padding: 7 10 7 10;-fx-font-size: 11px;");
        return etiqueta;
    }

    private static HBox linhaInformacao(String rotulo, String valor, Paleta p) {
        HBox linha = new HBox(12);
        linha.setAlignment(Pos.CENTER_LEFT);
        Label esquerda = new Label(rotulo);
        esquerda.setMinWidth(82);
        esquerda.setStyle("-fx-text-fill: " + p.textoSec() + ";-fx-font-size: 11px;");
        Label direita = new Label(valor);
        direita.setWrapText(true);
        direita.setStyle("-fx-text-fill: " + p.texto() + ";-fx-font-size: 11px;-fx-font-weight: bold;");
        HBox.setHgrow(direita, Priority.ALWAYS);
        linha.getChildren().addAll(esquerda, direita);
        return linha;
    }



    public static FlowPane criarSeletorCores(Stage janela, Paleta p) {
        FlowPane cores = new FlowPane(8, 8);
        cores.setAlignment(Pos.CENTER);
        cores.setPrefWrapLength(560);

        cores.getChildren().addAll(
                botaoCor("Padrão", "", 6, janela, p),
                botaoCor("Azul", "#1473e6", 1, janela, p),
                botaoCor("Rosa", "linear-gradient(to right, #ff4f9a, #ff87bc)", 2, janela, p),
                botaoCor("Roxo", "linear-gradient(to right, #8b5cf6, #b78cff)", 3, janela, p),
                botaoCor("Aurora", "linear-gradient(to right, #3b82f6, #7c5cff, #ff4f9a)", 4, janela, p),
                botaoCor("Amarelo", "linear-gradient(to right, #e0a500, #ffd45a)", 5, janela, p)
        );
        return cores;
    }

    public static Button botaoCor(String nome, String fundoOriginal, int modo, Stage janela, Paleta p) {
        Button botao = new Button(nome);
        botao.setPrefWidth(108);
        botao.setPrefHeight(36);
        String contorno = modo == modoCor() ? p.texto() : p.borda();
        String fundo = fundoOriginal;
        boolean neutra = (modo == 6);
        if (neutra) fundo = destaqueNeutro();
        String corTexto = neutra ? textoSobreDestaque() : "white";
        botao.setStyle(
                "-fx-background-color: " + fundo + ";" +
                "-fx-background-radius: 19;" +
                "-fx-border-color: " + contorno + ";" +
                "-fx-border-radius: 19;" +
                "-fx-border-width: 2;" +
                "-fx-text-fill: " + corTexto + ";" +
                "-fx-font-size: 11px;" +
                "-fx-font-weight: bold;" +
                "-fx-cursor: hand;"
        );
        botao.setOnAction(event -> definirCor(modo, janela));
        return botao;
    }



    public static ToggleButton criarAba(String texto, ToggleGroup grupo, Paleta p) {
        ToggleButton aba = new ToggleButton(texto);
        aba.setToggleGroup(grupo);
        aba.setPrefWidth(150);
        aba.setPrefHeight(38);
        aba.setStyle(estiloPerfil(false, p));
        aba.selectedProperty().addListener((obs, antes, agora) -> aba.setStyle(estiloPerfil(agora, p)));
        return aba;
    }

    public static VBox itemOpcaoCompacta(String nome, String legenda, boolean ativo, Runnable acao, Paleta p) {
        Button botao = new Button(nome);
        botao.setPrefSize(285, 42);
        botao.setStyle(ativo
                ? "-fx-background-color: " + fundoDestaque() + ";-fx-background-radius: 14;-fx-text-fill: " + textoSobreDestaque() + ";-fx-font-size: 13px;-fx-font-weight: bold;-fx-cursor: hand;"
                : "-fx-background-color: " + p.overlay() + "0.09);-fx-background-radius: 14;-fx-border-color: " + p.borda() + ";-fx-border-radius: 14;-fx-border-width: 1;-fx-text-fill: " + p.texto() + ";-fx-font-size: 13px;-fx-cursor: hand;");
        botao.setOnAction(event -> acao.run());

        Label rotulo = new Label(legenda);
        rotulo.setStyle("-fx-text-fill: " + p.textoTerc() + "; -fx-font-size: 10px;");
        rotulo.setMaxWidth(270);

        VBox item = new VBox(3, botao, rotulo);
        item.setAlignment(Pos.CENTER);
        item.setPrefWidth(295);
        return item;
    }


    private static VBox criarInterruptorDebug(Paleta p) {
        String nome = "🛠  Modo desenvolvedor";
        boolean ativo = modoDebug();
        ToggleButton interruptor = new ToggleButton(ativo ? nome + "  •  ATIVO" : nome + "  •  DESATIVADO");
        interruptor.setSelected(ativo);
        interruptor.setPrefSize(590, 40);
        interruptor.setStyle(estiloPerfil(ativo, p) + "-fx-background-radius: 14;-fx-font-size: 12px;");
        interruptor.setOnAction(event -> {
            boolean desejado = interruptor.isSelected();
            boolean ok = ativarModoDebug(desejado);
            if (!ok) {
                interruptor.setSelected(false);
                interruptor.setText(nome + "  •  DESATIVADO");
                interruptor.setStyle(estiloPerfil(false, p) + "-fx-background-radius: 14;-fx-font-size: 12px;");
            } else {
                boolean agora = modoDebug();
                interruptor.setSelected(agora);
                interruptor.setText(agora ? nome + "  •  ATIVO" : nome + "  •  DESATIVADO");
                interruptor.setStyle(estiloPerfil(agora, p) + "-fx-background-radius: 14;-fx-font-size: 12px;");
            }
        });

        Label rotulo = new Label(ativo ? "Ativado — nada é salvo enquanto estiver ligado" : "Desativado — ative para exibir o botão de diagnóstico");
        rotulo.setStyle("-fx-text-fill: " + p.textoTerc() + "; -fx-font-size: 10px;");
        VBox item = new VBox(3, interruptor, rotulo);
        item.setAlignment(Pos.CENTER);
        return item;
    }

    public static VBox itemInterruptorCompacto(String nome, String legenda, boolean ativo, Consumer<Boolean> acao, Paleta p) {
        ToggleButton interruptor = new ToggleButton(ativo ? nome + "  •  ATIVO" : nome + "  •  DESATIVADO");
        interruptor.setSelected(ativo);
        interruptor.setPrefSize(590, 40);
        interruptor.setStyle(estiloPerfil(ativo, p) + "-fx-background-radius: 14;-fx-font-size: 12px;");
        interruptor.setOnAction(event -> {
            boolean novoEstado = interruptor.isSelected();
            interruptor.setText(novoEstado ? nome + "  •  ATIVO" : nome + "  •  DESATIVADO");
            interruptor.setStyle(estiloPerfil(novoEstado, p) + "-fx-background-radius: 14;-fx-font-size: 12px;");
            acao.accept(novoEstado);
        });

        Label rotulo = new Label(legenda);
        rotulo.setStyle("-fx-text-fill: " + p.textoTerc() + "; -fx-font-size: 10px;");
        VBox item = new VBox(3, interruptor, rotulo);
        item.setAlignment(Pos.CENTER);
        return item;
    }

    public static VBox itemInterruptor(String nome, String legenda, boolean ativo, Consumer<Boolean> acao, Paleta p) {
        ToggleButton interruptor = new ToggleButton(ativo ? nome + "   ATIVO" : nome + "   DESATIVADO");
        interruptor.setSelected(ativo);
        interruptor.setMaxWidth(Double.MAX_VALUE);
        interruptor.setPrefHeight(44);
        interruptor.setStyle(estiloPerfil(ativo, p));
        interruptor.setOnAction(event -> {
            boolean novoEstado = interruptor.isSelected();
            interruptor.setText(novoEstado ? nome + "   ATIVO" : nome + "   DESATIVADO");
            interruptor.setStyle(estiloPerfil(novoEstado, p));
            acao.accept(novoEstado);
        });

        Label rotulo = new Label(legenda);
        rotulo.setWrapText(true);
        rotulo.setAlignment(Pos.CENTER);
        rotulo.setStyle("-fx-text-fill: " + p.textoTerc() + "; -fx-font-size: 11px;");

        VBox item = new VBox(3, interruptor, rotulo);
        item.setAlignment(Pos.CENTER);
        return item;
    }

}
