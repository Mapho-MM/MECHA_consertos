package com.senai.javafx.projeto02;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Armazena cópias editáveis das notas/documentos gerados no sistema. */
final class NotaFiscalRepositorio {
    private static final Path DIR = Path.of(System.getProperty("user.home"), ".mecha-consertos", "notas-fiscais");
    private NotaFiscalRepositorio() {}
    static final class Registro {
        final String id, cliente, documento, veiculo, os, servico, data;
        Registro(Properties p) {
            id=p.getProperty("id", ""); cliente=p.getProperty("cliente", ""); documento=p.getProperty("documento", "");
            veiculo=p.getProperty("veiculo", ""); os=p.getProperty("os", ""); servico=p.getProperty("servico", ""); data=p.getProperty("data", "");
        }
        @Override public String toString() { return "OS " + os + " • " + cliente + " • " + data; }
    }
    static List<Registro> listar() {
        List<Registro> out=new ArrayList<>();
        try { Files.createDirectories(DIR); try (DirectoryStream<Path> ds=Files.newDirectoryStream(DIR, "*.properties")) {
            for(Path p:ds) { Properties x=new Properties(); try(InputStream in=Files.newInputStream(p)){x.load(in);} out.add(new Registro(x)); }
        }} catch(Exception e){ e.printStackTrace(); }
        out.sort(Comparator.comparing((Registro r)->r.data).reversed()); return out;
    }
    static String salvar(String id, String html, String cliente, String documento, String veiculo, String os, String servico) throws IOException {
        Files.createDirectories(DIR); String key=(id==null||id.isBlank())?UUID.randomUUID().toString():id;
        String now=LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
        Files.writeString(DIR.resolve(key+".html"), html, StandardCharsets.UTF_8);
        Properties p=new Properties(); p.setProperty("id",key); p.setProperty("cliente",n(cliente)); p.setProperty("documento",n(documento));
        p.setProperty("veiculo",n(veiculo)); p.setProperty("os",n(os)); p.setProperty("servico",n(servico)); p.setProperty("data",now);
        try(OutputStream out=Files.newOutputStream(DIR.resolve(key+".properties"))){p.store(out,"Nota salva pela aplicação de oficina");} return key;
    }
    static String lerHtml(String id) throws IOException { return Files.readString(DIR.resolve(id+".html"), StandardCharsets.UTF_8); }
    private static String n(String s){return s==null?"":s;}
}
