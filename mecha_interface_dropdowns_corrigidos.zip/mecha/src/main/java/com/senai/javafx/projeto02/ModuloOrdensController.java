package com.senai.javafx.projeto02;

import com.senai.javafx.projeto02.entidades.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.TextAlignment;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static com.senai.javafx.projeto02.Dialogos.mostrarMensagem;
import static com.senai.javafx.projeto02.Tema.*;

/**
 * Ordens e Serviços — tela inicial com 3 abas (concept):
 * 1) serviços de clientes  → ordens + fluxo (aprovar / iniciar / finalizar)
 * 2) lista de serviços     → catálogo
 * 3) notas serviços e fiscais → consulta de notas
 */
public class ModuloOrdensController {

    @FXML private StackPane raizModulo;

    private Runnable aoCatalogo;
    private Runnable aoRecarregar;
    private Runnable aoNotaFiscal;
    private AcaoNotaFiscal aoNotaFiscalComServico;
    private AcaoNotaFiscal aoNotaServicoComServico;
    private Runnable aoClientes;

    @FunctionalInterface
    public interface AcaoNotaFiscal {
        void abrir(Cliente cliente, Veiculo veiculo, Servico servico);
    }

    private VBox viewHome;
    private VBox viewClientes;
    private VBox viewLista;
    private VBox viewNotas;

    private TableView<Map<String, String>> tabelaOrdens;
    private TableView<Map<String, String>> tabelaCatalogo;
    private TableView<Map<String, String>> tabelaNotas;
    private ComboBox<String> filtroStatus;
    private Label dicaStatus;
    private HBox caixaEtapas;
    private HBox caixaPills;

    private Button btnNova, btnAprovar, btnIniciar, btnFinalizar;
    private Button btnNotaServico, btnNotaFiscalAcao;

    private static final String[] ETAPAS = {"Orçamento", "Aprovado", "Em Andamento", "Concluído"};
    /** Cores oficiais do fluxograma: laranja → azul → amarelo → verde */
    private static final String[] ETAPA_CORES = {"#f97316", "#0ea5e9", "#eab308", "#34d399"};

    @FXML
    private void initialize() {
        viewHome = construirHome();
        viewClientes = construirAbaClientes();
        viewLista = construirAbaLista();
        viewNotas = construirAbaNotas();
        mostrar(viewHome);
    }

    public void setCallbacks(Runnable aoCatalogo, Runnable aoRecarregar) {
        this.aoCatalogo = aoCatalogo;
        this.aoRecarregar = aoRecarregar;
    }

    public void setAoNotaFiscal(Runnable aoNotaFiscal) {
        this.aoNotaFiscal = aoNotaFiscal;
    }

    public void setAoNotaFiscalComServico(AcaoNotaFiscal acao) {
        this.aoNotaFiscalComServico = acao;
    }

    public void setAoNotaServicoComServico(AcaoNotaFiscal acao) {
        this.aoNotaServicoComServico = acao;
    }

    public void setAoClientes(Runnable aoClientes) {
        this.aoClientes = aoClientes;
    }

    public void carregarDados() {
        if (tabelaOrdens != null) preencherTabelaOrdens();
        if (tabelaCatalogo != null) preencherCatalogo();
        if (tabelaNotas != null) preencherNotas();
        atualizarDicaEBotoes();
    }

    // ===================== NAVEGAÇÃO =====================

    private void mostrar(VBox view) {
        if (raizModulo == null || view == null) return;
        raizModulo.getChildren().setAll(view);
        carregarDados();
    }

    private void voltarHome() {
        mostrar(viewHome);
    }

    // ===================== HOME (3 CARDS) =====================

    private VBox construirHome() {
        Paleta p = paletaAtual();
        Label titulo = new Label("Ordens e Serviços");
        titulo.setStyle("-fx-text-fill: " + p.texto() + "; -fx-font-size: 28px; -fx-font-weight: bold;");

        Label sub = new Label("Escolha uma área para continuar");
        sub.setStyle("-fx-text-fill: " + p.textoSec() + "; -fx-font-size: 14px;");

        HBox hubs = new HBox(24,
                hubCard("👤", "Serviços de clientes",
                        "Gerenciar ordens: aprovar, iniciar e finalizar",
                        () -> mostrar(viewClientes)),
                hubCard("📋", "Lista de serviços",
                        "Catálogo de serviços da oficina",
                        () -> mostrar(viewLista)),
                hubCard("📄", "Notas e documentos",
                        "Notas de serviço e fiscais de todos os clientes",
                        () -> mostrar(viewNotas))
        );
        hubs.setAlignment(Pos.CENTER);
        hubs.setMaxHeight(260);

        VBox root = new VBox(24, titulo, sub, hubs);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(40, 24, 24, 24));
        // NÃO esticar os cards na vertical
        return root;
    }

    private VBox hubCard(String icone, String titulo, String desc, Runnable acao) {
        Paleta p = paletaAtual();
        Label ic = new Label(icone);
        ic.setStyle("-fx-font-size: 54px; -fx-text-fill: " + p.texto() + ";");
        Label t = new Label(titulo);
        t.setWrapText(true);
        t.setTextAlignment(TextAlignment.CENTER);
        t.setMaxWidth(240);
        t.setStyle("-fx-text-fill: " + p.texto() + "; -fx-font-size: 17px; -fx-font-weight: bold;");
        Label d = new Label(desc);
        d.setWrapText(true);
        d.setTextAlignment(TextAlignment.CENTER);
        d.setMaxWidth(240);
        d.setStyle("-fx-text-fill: " + p.textoSec() + "; -fx-font-size: 13px;");

        VBox box = new VBox(10, ic, t, d);
        box.setAlignment(Pos.CENTER);
        box.setPrefSize(270, 220);
        box.setMinSize(220, 190);
        box.setMaxSize(300, 250);
        box.setStyle(
                "-fx-background-color: " + Visual.fundoCard() + ";" +
                "-fx-background-radius: 24;" +
                "-fx-border-color: " + Visual.bordaCard() + ";" +
                "-fx-border-radius: 24;" +
                "-fx-border-width: 1;" +
                "-fx-padding: 18 16;" +
                "-fx-cursor: hand;" +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.18), 14, 0.15, 0, 3);"
        );
        box.setOnMouseClicked(e -> { if (acao != null) acao.run(); });
        box.setOnMouseEntered(e -> box.setOpacity(0.88));
        box.setOnMouseExited(e -> box.setOpacity(1));
        return box;
    }

    // ===================== ABA 1: SERVIÇOS DE CLIENTES (LayoutPadrao) =====================

    private Label rodapeOrdens;

    private VBox construirAbaClientes() {
        Paleta p = paletaAtual();
        Button voltar = botaoVoltar();

        // 1. Cabeçalho: voltar + título + ↻
        Label titulo = new Label("Serviços de clientes");
        titulo.setStyle("-fx-text-fill: " + p.texto() + "; -fx-font-size: 26px; -fx-font-weight: bold;");
        Button btnRefresh = LayoutPadrao.botaoRefresh(this::carregarDados);
        HBox cabecalho = new HBox(12, voltar, titulo, btnRefresh);
        cabecalho.setAlignment(Pos.CENTER_LEFT);

        // 2. Cards de indicadores (pills)
        caixaPills = new HBox(12);
        caixaPills.setAlignment(Pos.CENTER_LEFT);

        // Fluxo visual de etapas
        caixaEtapas = new HBox(6);
        caixaEtapas.setAlignment(Pos.CENTER_LEFT);

        dicaStatus = new Label("Selecione uma ordem na tabela. Os botões e as cores mudam conforme a etapa.");
        dicaStatus.setWrapText(true);
        dicaStatus.setMaxWidth(560);
        dicaStatus.setStyle(
                "-fx-text-fill: " + p.texto() + "; -fx-font-size: 12px;" +
                "-fx-background-color: " + p.overlay() + "0.10);" +
                "-fx-background-radius: 12; -fx-padding: 8 12;"
        );

        // 3. Barra de controle: filtros (esq) | ações (dir)
        filtroStatus = LayoutPadrao.comboFiltro("Todos", "Orçamento", "Aprovado", "Em Andamento", "Concluído");
        filtroStatus.getSelectionModel().selectFirst();
        filtroStatus.setOnAction(e -> preencherTabelaOrdens());

        btnNova = LayoutPadrao.botaoPrimario("+ Novo orçamento");
        btnAprovar = LayoutPadrao.botaoEdicao("Cliente aprovou");
        btnIniciar = LayoutPadrao.botaoSucesso("Iniciando serviço");
        btnFinalizar = LayoutPadrao.botaoSucesso("Finalizar");
        btnNotaServico = LayoutPadrao.botaoPrimario("📄 Nota de serviço");
        pintar(btnNotaServico, "#2563eb", "#ffffff");
        btnNotaFiscalAcao = LayoutPadrao.botaoNeutro("🧾 Nota Fiscal");
        // Nota fiscal com toque rosa do fluxograma
        pintar(btnNotaFiscalAcao, "#fb7185", "#ffffff");

        btnNova.setOnAction(e -> onNova());
        btnAprovar.setOnAction(e -> onAprovar());
        btnIniciar.setOnAction(e -> onIniciar());
        btnFinalizar.setOnAction(e -> onFinalizar());
        btnNotaServico.setOnAction(e -> onNotaServico());
        btnNotaFiscalAcao.setOnAction(e -> onNotaFiscal());

        FlowPane filtros = new FlowPane(8, 8, filtroStatus);
        filtros.setAlignment(Pos.CENTER_LEFT);
        FlowPane acoes = new FlowPane(8, 8, btnNova, btnAprovar, btnIniciar, btnFinalizar, btnNotaServico, btnNotaFiscalAcao);
        acoes.setAlignment(Pos.CENTER_LEFT);
        for (Button botao : new Button[]{btnNova, btnAprovar, btnIniciar, btnFinalizar, btnNotaServico, btnNotaFiscalAcao}) {
            botao.setMaxWidth(Double.MAX_VALUE);
            botao.setMinWidth(135);
            botao.setAlignment(Pos.CENTER);
        }
        VBox barra = new VBox(10,
                new Label("🔎  FILTRAR ORDENS"), filtros,
                new Label("⚡  AÇÕES DA ORDEM SELECIONADA"), acoes,
                dicaStatus);
        barra.setPadding(new Insets(12));
        barra.setStyle(Visual.estiloPainel(16, 14));

        // 4. Tabela
        tabelaOrdens = novaTabela(
                "Nº", "Cliente", "Veículo", "Placa", "Serviço", "Mecânico",
                "Início", "Finalizado em", "Valor", "Situação"
        );
        LayoutPadrao.estilizarTabela(tabelaOrdens);
        tabelaOrdens.getSelectionModel().selectedItemProperty().addListener((o, a, b) -> atualizarDicaEBotoes());

        // 5. Rodapé
        rodapeOrdens = LayoutPadrao.rodapeRegistros(0);

        VBox painelResumo = new VBox(8, new Label("📊  RESUMO DOS SERVIÇOS"), caixaPills, caixaEtapas);
        painelResumo.setPadding(new Insets(12));
        painelResumo.setStyle(Visual.estiloPainel(16, 14));
        VBox painelTabela = new VBox(8, new Label("📋  ORDENS DE SERVIÇO"), tabelaOrdens);
        VBox.setVgrow(tabelaOrdens, Priority.ALWAYS);
        painelTabela.setPadding(new Insets(12));
        painelTabela.setStyle(Visual.estiloPainel(16, 14));
        VBox root = new VBox(14,
                cabecalho,
                painelResumo,
                barra,
                painelTabela,
                LayoutPadrao.barraRodape(rodapeOrdens)
        );
        VBox.setVgrow(tabelaOrdens, Priority.ALWAYS);
        root.setPadding(new Insets(8, 10, 8, 10));
        aplicarTextoBranco(root);
        montarEtapas(null);
        return root;
    }

    private void estiloComboFiltro(ComboBox<String> cb, Paleta p) {
        cb.setStyle(
                "-fx-background-color: " + p.overlay() + "0.14);" +
                "-fx-text-fill: " + p.texto() + ";" +
                "-fx-background-radius: 12;" +
                "-fx-border-color: " + p.borda() + ";" +
                "-fx-border-radius: 12;"
        );
        cb.setButtonCell(new ListCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item);
                setStyle("-fx-text-fill: " + p.texto() + ";");
            }
        });
        cb.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item);
                setStyle("-fx-text-fill: " + p.texto() + "; -fx-padding: 6 10;");
            }
        });
    }

    // ===================== ABA 2: LISTA DE SERVIÇOS (CATÁLOGO) — LayoutPadrao =====================

    private Label rodapeCatalogo;

    private VBox construirAbaLista() {
        Paleta p = paletaAtual();
        Button voltar = botaoVoltar();
        Label titulo = new Label("Lista de serviços");
        titulo.setStyle("-fx-text-fill: " + p.texto() + "; -fx-font-size: 26px; -fx-font-weight: bold;");
        Button btnRefresh = LayoutPadrao.botaoRefresh(this::preencherCatalogo);
        HBox cabecalho = new HBox(12, voltar, titulo, btnRefresh);
        cabecalho.setAlignment(Pos.CENTER_LEFT);

        Button novo = LayoutPadrao.botaoPrimario("+ Novo serviço");
        novo.setOnAction(e -> {
            if (aoCatalogo != null) aoCatalogo.run();
            else CadastroDialogos.cadastrarServico(this::preencherCatalogo);
        });

        HBox barra = LayoutPadrao.barraControle(
                new javafx.scene.Node[]{},
                new javafx.scene.Node[]{novo}
        );

        tabelaCatalogo = novaTabela("Cód.", "Nome", "Preço", "Usos");
        LayoutPadrao.estilizarTabela(tabelaCatalogo);
        rodapeCatalogo = LayoutPadrao.rodapeRegistros(0);

        VBox root = new VBox(14, cabecalho, barra, tabelaCatalogo, LayoutPadrao.barraRodape(rodapeCatalogo));
        VBox.setVgrow(tabelaCatalogo, Priority.ALWAYS);
        root.setPadding(new Insets(8, 10, 8, 10));
        return root;
    }

    // ===================== ABA 3: NOTAS — LayoutPadrao =====================

    private Label rodapeNotas;

    private VBox construirAbaNotas() {
        Paleta p = paletaAtual();
        Button voltar = botaoVoltar();
        Label titulo = new Label("Notas de serviço e fiscais");
        titulo.setStyle("-fx-text-fill: " + p.texto() + "; -fx-font-size: 26px; -fx-font-weight: bold;");
        Button btnRefresh = LayoutPadrao.botaoRefresh(this::preencherNotas);
        HBox cabecalho = new HBox(12, voltar, titulo, btnRefresh);
        cabecalho.setAlignment(Pos.CENTER_LEFT);

        Label sub = new Label("Consulta de documentos de todos os clientes. Selecione uma linha para abrir.");
        sub.setStyle("-fx-text-fill: " + p.textoSec() + "; -fx-font-size: 13px;");

        Button abrirServico = LayoutPadrao.botaoPrimario("📄 Abrir Nota de serviço");
        Button abrirFiscal = LayoutPadrao.botaoNeutro("🧾 Abrir Nota Fiscal");
        pintar(abrirFiscal, "#fb7185", "#ffffff");
        abrirServico.setOnAction(e -> abrirNotaDaTabela(false));
        abrirFiscal.setOnAction(e -> abrirNotaDaTabela(true));

        HBox barra = LayoutPadrao.barraControle(
                new javafx.scene.Node[]{},
                new javafx.scene.Node[]{abrirFiscal, abrirServico}
        );

        tabelaNotas = novaTabela("Nº", "Cliente", "Veículo", "Placa", "Serviço", "Situação", "Valor");
        LayoutPadrao.estilizarTabela(tabelaNotas);
        tabelaNotas.setRowFactory(tv -> {
            TableRow<Map<String, String>> row = new TableRow<>();
            row.setOnMouseClicked(ev -> {
                if (ev.getClickCount() == 2 && !row.isEmpty()) abrirNotaDaTabela(false);
            });
            return row;
        });
        rodapeNotas = LayoutPadrao.rodapeRegistros(0);

        VBox root = new VBox(14, cabecalho, sub, barra, tabelaNotas, LayoutPadrao.barraRodape(rodapeNotas));
        VBox.setVgrow(tabelaNotas, Priority.ALWAYS);
        root.setPadding(new Insets(8, 10, 8, 10));
        return root;
    }

    private void aplicarTextoBranco(Node no) {
        if (no instanceof Label label) {
            label.setTextFill(javafx.scene.paint.Color.WHITE);
        } else if (no instanceof TableView<?> tabela) {
            tabela.setStyle("-fx-control-inner-background: #171923; -fx-text-background-color: #ffffff; -fx-table-cell-border-color: #343746;");
        }
        if (no instanceof Parent pai) {
            for (Node filho : pai.getChildrenUnmodifiable()) aplicarTextoBranco(filho);
        }
    }

    // ===================== DADOS =====================

    private void preencherTabelaOrdens() {
        if (tabelaOrdens == null) return;
        Status filtro = statusDoFiltro();
        List<Map<String, String>> linhas = new ArrayList<>();
        int orc = 0, ag = 0, and = 0, fin = 0, n = 1;

        for (Cliente c : OficinaService.oficina().getClientes()) {
            for (Veiculo vei : c.getCarros()) {
                for (Servico s : vei.getServicos()) {
                    if (s.getStatus() == Status.ORCAMENTO) orc++;
                    else if (s.getStatus() == Status.AGENDADO) ag++;
                    else if (s.getStatus() == Status.ANDAMENTO) and++;
                    else if (s.getStatus() == Status.FINALIZADO) fin++;

                    if (filtro != null && s.getStatus() != filtro) continue;
                    linhas.add(linhaOrdem(c, vei, s, n++));
                }
            }
        }
        tabelaOrdens.setItems(FXCollections.observableArrayList(linhas));
        tabelaOrdens.setPlaceholder(new Label("Nenhuma ordem. Clique em \"+ Novo orçamento\"."));
        LayoutPadrao.estilizarTabela(tabelaOrdens);
        if (rodapeOrdens != null) LayoutPadrao.atualizarRodape(rodapeOrdens, linhas.size());

        if (caixaPills != null) {
            caixaPills.getChildren().setAll(
                    LayoutPadrao.cardIndicador("Orçamento", String.valueOf(orc)),
                    LayoutPadrao.cardIndicador("Aprovado", String.valueOf(ag)),
                    LayoutPadrao.cardIndicador("Em Andamento", String.valueOf(and)),
                    LayoutPadrao.cardIndicador("Concluído", String.valueOf(fin))
            );
        }
        atualizarDicaEBotoes();
    }

    private void preencherCatalogo() {
        if (tabelaCatalogo == null) return;
        List<Map<String, String>> linhas = new ArrayList<>();
        int i = 1;
        for (Servico s : OficinaService.oficina().getCatalogoServicos()) {
            Map<String, String> row = new LinkedHashMap<>();
            row.put("Cód.", String.valueOf(i++));
            row.put("Nome", s.getNome());
            row.put("Preço", OficinaService.formatarMoeda(s.getPreco()));
            row.put("Usos", String.valueOf(s.getQuantidadeUsos()));
            linhas.add(row);
        }
        tabelaCatalogo.setItems(FXCollections.observableArrayList(linhas));
        tabelaCatalogo.setPlaceholder(new Label("Catálogo vazio."));
        LayoutPadrao.estilizarTabela(tabelaCatalogo);
        if (rodapeCatalogo != null) LayoutPadrao.atualizarRodape(rodapeCatalogo, linhas.size());
    }

    private void preencherNotas() {
        if (tabelaNotas == null) return;
        List<Map<String, String>> linhas = new ArrayList<>();
        int n = 1;
        for (Cliente c : OficinaService.oficina().getClientes()) {
            for (Veiculo vei : c.getCarros()) {
                for (Servico s : vei.getServicos()) {
                    // Notas disponíveis a partir da aprovação
                    if (s.getStatus() == Status.ORCAMENTO) continue;
                    linhas.add(linhaOrdem(c, vei, s, n++));
                }
            }
        }
        tabelaNotas.setItems(FXCollections.observableArrayList(linhas));
        tabelaNotas.setPlaceholder(new Label("Nenhuma nota disponível. Aprove orçamentos primeiro."));
        LayoutPadrao.estilizarTabela(tabelaNotas);
        if (rodapeNotas != null) LayoutPadrao.atualizarRodape(rodapeNotas, linhas.size());
    }

    private Map<String, String> linhaOrdem(Cliente c, Veiculo vei, Servico s, int n) {
        Map<String, String> row = new LinkedHashMap<>();
        String osNum = s.getNumeroOrcamento() != null
                ? String.format("%04d", s.getNumeroOrcamento())
                : String.format("%04d", n);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        row.put("Nº", osNum);
        row.put("Cliente", c.getNome());
        row.put("Veículo", vei.getModelo());
        row.put("Placa", vei.getPlaca());
        row.put("Serviço", s.getNome());
        row.put("Mecânico", s.getMecanicos().isEmpty() ? "—" : s.getMecanicos().get(0).getNome());
        row.put("Início", s.getDataHoraInicio() == null ? "Não iniciado" : s.getDataHoraInicio().format(fmt));
        row.put("Finalizado em", s.getDataHoraConclusao() == null ? "—" : s.getDataHoraConclusao().format(fmt));
        row.put("Valor", OficinaService.formatarMoeda(s.getPreco()));
        row.put("Situação", rotuloStatus(s.getStatus()));
        row.put("_cli", c.getCpf());
        row.put("_placa", vei.getPlaca());
        row.put("_srvIdx", String.valueOf(vei.getServicos().indexOf(s)));
        row.put("_srv", s.getNome() + "|" + s.getStatus().name());
        row.put("_status", s.getStatus().name());
        return row;
    }

    // ===================== UI HELPERS =====================

    private Button botaoVoltar() {
        Button b = new Button("←  Voltar");
        estilizarNeutro(b);
        Tema.aplicarEstiloSemantico(b);
        b.setOnAction(e -> voltarHome());
        return b;
    }

    private TableView<Map<String, String>> novaTabela(String... cols) {
        TableView<Map<String, String>> tabela = new TableView<>();
        tabela.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        Tema.estilizarControleNativo(tabela);
        for (String col : cols) {
            TableColumn<Map<String, String>, String> c = new TableColumn<>(col);
            final String chave = col;
            c.setCellValueFactory(d -> new SimpleStringProperty(
                    d.getValue() != null ? d.getValue().getOrDefault(chave, "") : ""));
            tabela.getColumns().add(c);
        }
        return tabela;
    }

    private Label pill(String texto) {
        Paleta p = paletaAtual();
        Label lb = new Label(texto);
        lb.setStyle(
                "-fx-background-color: " + p.overlay() + "0.14);" +
                "-fx-text-fill: " + p.texto() + ";" +
                "-fx-font-size: 13px; -fx-font-weight: bold;" +
                "-fx-padding: 10 18; -fx-background-radius: 22;" +
                "-fx-border-color: " + p.borda() + "; -fx-border-radius: 22; -fx-border-width: 1;"
        );
        return lb;
    }

    private void montarEtapas(Status atual) {
        if (caixaEtapas == null) return;
        caixaEtapas.getChildren().clear();
        int idxAtivo = indiceEtapa(atual);
        for (int i = 0; i < ETAPAS.length; i++) {
            boolean corrente = (i == idxAtivo);
            boolean passado = (idxAtivo >= 0 && i < idxAtivo);
            Label lb = new Label(ETAPAS[i]);
            String cor = ETAPA_CORES[i];
            // Fluxograma: etapa atual forte; passadas um pouco mais claras; futuras bem esmaecidas (cinza)
            String bg;
            String fg;
            if (corrente) {
                bg = cor;
                fg = "#0f172a";
            } else if (passado) {
                bg = cor + "bb";
                fg = "#0f172a";
            } else {
                bg = "#9ca3af55";
                fg = "#64748b";
            }
            lb.setStyle(
                    "-fx-background-color: " + bg + ";" +
                    "-fx-text-fill: " + fg + ";" +
                    "-fx-font-size: 13px;" +
                    "-fx-font-weight: bold; -fx-padding: 8 16; -fx-background-radius: 18;" +
                    (corrente ? "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.25), 8, 0.2, 0, 2);" : "")
            );
            caixaEtapas.getChildren().add(lb);
            if (i < ETAPAS.length - 1) {
                Label seta = new Label("→");
                seta.setStyle("-fx-text-fill: #94a3b8; -fx-font-size: 18px; -fx-font-weight: bold;");
                caixaEtapas.getChildren().add(seta);
            }
        }
    }

    private int indiceEtapa(Status s) {
        if (s == null) return -1;
        return switch (s) {
            case ORCAMENTO -> 0;
            case AGENDADO -> 1;
            case ANDAMENTO -> 2;
            case FINALIZADO -> 3;
        };
    }

    private Status statusDoFiltro() {
        if (filtroStatus == null) return null;
        String v = filtroStatus.getSelectionModel().getSelectedItem();
        if (v == null || "Todos".equals(v)) return null;
        return switch (v) {
            case "Orçamento" -> Status.ORCAMENTO;
            case "Aprovado" -> Status.AGENDADO;
            case "Em Andamento" -> Status.ANDAMENTO;
            case "Concluído" -> Status.FINALIZADO;
            default -> null;
        };
    }

    private static String rotuloStatus(Status s) {
        if (s == null) return "—";
        return switch (s) {
            case ORCAMENTO -> "Orçamento";
            case AGENDADO -> "Aprovado";
            case ANDAMENTO -> "Em Andamento";
            case FINALIZADO -> "Concluído";
        };
    }

    private void pintar(Button b, String fundo, String texto) {
        if (b == null) return;
        b.setPrefHeight(40);
        b.setStyle(
                "-fx-background-color: " + fundo + "; -fx-text-fill: " + texto + ";" +
                "-fx-background-radius: 22; -fx-border-radius: 22; -fx-border-width: 0;" +
                "-fx-cursor: hand; -fx-font-size: 13px; -fx-font-weight: bold; -fx-padding: 0 18;"
        );
    }

    private void estilizarNeutro(Button b) {
        if (b == null) return;
        Paleta p = paletaAtual();
        b.setPrefHeight(38);
        b.setStyle(
                "-fx-background-color: " + p.overlay() + "0.12); -fx-text-fill: " + p.texto() + ";" +
                "-fx-background-radius: 16; -fx-border-color: " + p.borda() + ";" +
                "-fx-border-radius: 16; -fx-border-width: 1; -fx-cursor: hand; -fx-padding: 0 12;"
        );
    }

    private void setEnabled(Button b, boolean on) {
        if (b == null) return;
        b.setDisable(!on);
        b.setOpacity(on ? 1.0 : 0.45);
    }

    private void atualizarDicaEBotoes() {
        if (tabelaOrdens == null) return;
        Map<String, String> row = tabelaOrdens.getSelectionModel().getSelectedItem();
        Status st = null;
        if (row != null) {
            try { st = Status.valueOf(row.get("_status")); } catch (Exception ignored) {}
        }
        montarEtapas(st);
        boolean temSel = row != null;
        setEnabled(btnAprovar, temSel && st == Status.ORCAMENTO);
        setEnabled(btnIniciar, temSel && st == Status.AGENDADO);
        setEnabled(btnFinalizar, temSel && st == Status.ANDAMENTO);
        setEnabled(btnNotaServico, temSel && st != null && st != Status.ORCAMENTO);
        if (dicaStatus == null) return;
        if (!temSel) {
            dicaStatus.setText("Selecione uma ordem na tabela para ver o próximo passo.");
            return;
        }
        dicaStatus.setText(switch (st) {
            case ORCAMENTO -> "Orçamento: clique em \"Cliente aprovou\" para avançar e gerar a Nota de Serviço.";
            case AGENDADO -> "Aprovado: clique em \"Iniciando serviço\" quando for começar o trabalho.";
            case ANDAMENTO -> "Em Andamento: ao terminar, clique em \"Finalizar\".";
            case FINALIZADO -> "Concluído: Nota de serviço e Nota Fiscal disponíveis a qualquer momento.";
            default -> "Selecione uma ordem.";
        });
    }

    // ===================== AÇÕES =====================

    private void onNova() {
        CadastroDialogos.criarOrdemServico(this::carregarDados);
    }

    private void onAprovar() {
        Selecao sel = selecionar(tabelaOrdens);
        if (sel == null) return;
        try {
            OficinaService.aprovarOrcamento(sel.cli, sel.vei, sel.srv);
            carregarDados();
            mostrarMensagem("Orçamento aprovado", "Cliente aprovou. Abrindo Nota de Serviço.");
            abrirNotaServicoSel(sel);
        } catch (Exception ex) {
            mostrarMensagem("Orçamento", ex.getMessage());
        }
    }

    private void onNotaServico() {
        Selecao sel = selecionar(tabelaOrdens);
        if (sel == null) return;
        if (sel.srv.getStatus() == Status.ORCAMENTO) {
            mostrarMensagem("Nota de Serviço", "Aprove o orçamento primeiro.");
            return;
        }
        abrirNotaServicoSel(sel);
    }

    private void abrirNotaServicoSel(Selecao sel) {
        if (aoNotaServicoComServico != null) {
            aoNotaServicoComServico.abrir(sel.cli, sel.vei, sel.srv);
        } else {
            NotaServicoHelper.abrirNota(sel.cli, sel.vei, sel.srv);
        }
    }

    private void onNotaFiscal() {
        Selecao sel = selecionar(tabelaOrdens);
        if (sel == null) return;
        if (aoNotaFiscalComServico != null) {
            aoNotaFiscalComServico.abrir(sel.cli, sel.vei, sel.srv);
        } else if (aoNotaFiscal != null) {
            aoNotaFiscal.run();
        } else {
            mostrarMensagem("Nota Fiscal", "Selecione uma ordem e use o botão Nota Fiscal nesta tela.");
        }
    }

    private void onIniciar() { acaoStatus(true); }
    private void onFinalizar() { acaoStatus(false); }

    private void acaoStatus(boolean iniciar) {
        Selecao sel = selecionar(tabelaOrdens);
        if (sel == null) return;
        try {
            if (iniciar) {
                OficinaService.iniciarServico(sel.cli, sel.vei, sel.srv);
                PersistenciaOficina.salvar();
                mostrarMensagem("Serviço", "Serviço iniciado.");
            } else {
                OficinaService.finalizarServico(sel.cli, sel.vei, sel.srv);
                mostrarMensagem("Serviço", "Serviço concluído!");
            }
            carregarDados();
        } catch (Exception ex) {
            mostrarMensagem("Serviço", ex.getMessage());
        }
    }

    private void abrirNotaDaTabela(boolean fiscal) {
        Selecao sel = selecionar(tabelaNotas);
        if (sel == null) return;
        if (fiscal) {
            if (aoNotaFiscalComServico != null) {
                aoNotaFiscalComServico.abrir(sel.cli, sel.vei, sel.srv);
            } else if (aoNotaFiscal != null) {
                aoNotaFiscal.run();
            }
        } else {
            abrirNotaServicoSel(sel);
        }
    }

    private Selecao selecionar(TableView<Map<String, String>> tabela) {
        if (tabela == null) return null;
        Map<String, String> row = tabela.getSelectionModel().getSelectedItem();
        if (row == null) {
            mostrarMensagem("Ordens", "Selecione uma linha na tabela.");
            return null;
        }
        String cpf = row.get("_cli");
        String placa = row.get("_placa");
        String srvKey = row.get("_srv");
        Cliente cli = null;
        for (Cliente c : OficinaService.oficina().getClientes()) {
            if (c.getCpf().equals(cpf)) { cli = c; break; }
        }
        if (cli == null) return null;
        Veiculo vei = null;
        for (Veiculo v : cli.getCarros()) {
            if (v.getPlaca().equalsIgnoreCase(placa)) { vei = v; break; }
        }
        if (vei == null) return null;
        Servico alvo = null;
        // Prefer the exact row index so same-named services do not open the wrong invoice.
        try {
            int idxServico = Integer.parseInt(row.getOrDefault("_srvIdx", "-1"));
            if (idxServico >= 0 && idxServico < vei.getServicos().size()) {
                alvo = vei.getServicos().get(idxServico);
            }
        } catch (NumberFormatException ignored) { }
        if (alvo == null) {
            for (Servico s : vei.getServicos()) {
                if ((s.getNome() + "|" + s.getStatus().name()).equals(srvKey)) { alvo = s; break; }
            }
        }
        if (alvo == null) return null;
        return new Selecao(cli, vei, alvo);
    }

    private static final class Selecao {
        final Cliente cli;
        final Veiculo vei;
        final Servico srv;
        Selecao(Cliente c, Veiculo v, Servico s) { cli = c; vei = v; srv = s; }
    }
}
