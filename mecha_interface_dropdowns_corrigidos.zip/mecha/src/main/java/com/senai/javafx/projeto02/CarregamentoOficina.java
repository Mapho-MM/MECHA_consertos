package com.senai.javafx.projeto02;

import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.SVGPath;
import javafx.util.Duration;

/** Overlay reutilizável de carregamento com ícone vetorial de carro girando. */
public final class CarregamentoOficina {
    private final StackPane raiz;
    private final StackPane overlay;
    private final Label mensagem;
    private final RotateTransition animacao;

    /** Envolve o conteúdo existente sem removê-lo. O overlay começa oculto. */
    public CarregamentoOficina(Node conteudo) {
        raiz = new StackPane(conteudo);
        raiz.setMinSize(0, 0);

        SVGPath carro = new SVGPath();
        carro.setContent("M 8 31 L 12 19 Q 13 16 17 16 L 37 16 Q 41 16 44 21 L 49 29 L 54 31 L 56 38 L 53 41 L 7 41 L 4 38 L 5 33 Z "
                + "M 17 19 L 14 28 L 44 28 L 39 20 Z");
        carro.setFill(Color.TRANSPARENT);
        carro.setStroke(Color.web("#d62828"));
        carro.setStrokeWidth(2.7);
        carro.setStrokeLineJoin(javafx.scene.shape.StrokeLineJoin.ROUND);
        carro.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        carro.setScaleX(1.45);
        carro.setScaleY(1.45);

        Circle roda1 = new Circle(14, 41, 5, Color.web("#202938"));
        Circle roda2 = new Circle(45, 41, 5, Color.web("#202938"));
        Circle centro1 = new Circle(14, 41, 2, Color.web("#f3f4f6"));
        Circle centro2 = new Circle(45, 41, 2, Color.web("#f3f4f6"));
        StackPane carroVetorial = new StackPane(carro, roda1, roda2, centro1, centro2);
        carroVetorial.setPrefSize(92, 78);
        animacao = new RotateTransition(Duration.seconds(1.5), carroVetorial);
        animacao.setByAngle(360);
        animacao.setCycleCount(RotateTransition.INDEFINITE);
        animacao.setInterpolator(Interpolator.LINEAR);

        mensagem = new Label("Preparando a oficina...");
        mensagem.setStyle("-fx-font-size: 14px; -fx-font-weight: 600; -fx-text-fill: #263244;");
        Label detalhe = new Label("Aguarde um instante");
        detalhe.setStyle("-fx-font-size: 11px; -fx-text-fill: #697586;");

        VBox cartao = new VBox(9, carroVetorial, mensagem, detalhe);
        cartao.setAlignment(Pos.CENTER);
        cartao.setMaxWidth(260);
        cartao.setStyle("-fx-background-color: white; -fx-background-radius: 16; -fx-padding: 22 30 22 30;"
                + "-fx-border-color: #e3e7ed; -fx-border-radius: 16; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.16), 22, 0.2, 0, 5);");

        overlay = new StackPane(cartao);
        overlay.setAlignment(Pos.CENTER);
        overlay.setStyle("-fx-background-color: rgba(18, 28, 45, 0.28);");
        overlay.setVisible(false);
        overlay.setManaged(false);
        overlay.setPickOnBounds(true);
        raiz.getChildren().add(overlay);
    }

    public StackPane getRoot() {
        return raiz;
    }

    /** Exibe o loading com uma mensagem contextual. */
    public void mostrar(String texto) {
        mensagem.setText(texto == null || texto.isBlank() ? "Preparando a oficina..." : texto);
        overlay.setManaged(true);
        overlay.setVisible(true);
        animacao.playFromStart();
    }

    /** Oculta o loading e encerra a animação. */
    public void ocultar() {
        animacao.stop();
        overlay.setVisible(false);
        overlay.setManaged(false);
    }
}
