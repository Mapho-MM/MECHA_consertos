package com.senai.javafx.projeto02;

import com.senai.javafx.projeto02.entidades.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.image.ImageView;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.fxml.FXML;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.senai.javafx.projeto02.Dialogos.*;
import static com.senai.javafx.projeto02.Tema.*;

/** Painel do funcionário — consulta e tarefas atribuídas (sem gestão administrativa). */
public class DashboardFuncionarioController extends DashboardBase {

    @FXML private VBox dashboardFuncionario;
    @FXML private ImageView fundoMenuFuncionario;
    @FXML private Pane sombraFundoMenuFuncionario;
    @FXML private VBox menuFuncionario;
    @FXML private VBox areaFuncionario;

    @FXML private Button botaoMenuFuncionario;
    @FXML private Button botaoUsuarioFuncionario;
    @FXML private Label rotuloPerfilFuncionario;
    @FXML private Label usuarioFuncionarioTexto;

    @FXML
    public void initialize() {
        configurarFundoMenu();
    }

    private void configurarFundoMenu() {
        if (fundoMenuFuncionario != null && dashboardFuncionario != null) {
            if (!fundoMenuFuncionario.fitWidthProperty().isBound()) {
                fundoMenuFuncionario.fitWidthProperty().bind(dashboardFuncionario.widthProperty());
                fundoMenuFuncionario.fitHeightProperty().bind(dashboardFuncionario.heightProperty());
            }
            fundoMenuFuncionario.setMouseTransparent(true);
        }
        if (sombraFundoMenuFuncionario != null) {
            boolean temaClaro = Tema.temaEfetivo() == 1;
            sombraFundoMenuFuncionario.setStyle(temaClaro
                    ? "-fx-background-color: rgba(248,250,252,0.68);"
                    : "-fx-background-color: rgba(3,7,18,0.48);");
            if (fundoMenuFuncionario != null) {
                fundoMenuFuncionario.setOpacity(temaClaro ? 0.40 : 0.66);
            }
        }
    }

    @Override
    public void aoEntrar() {
        SingleTon.getInstancia(); // garante dados
        Usuario usuario = app.getUsuarioAtual();
        usuarioFuncionarioTexto.setText(usuario != null ? usuario.getNome() : "Funcionário");
        aoAtualizarAvatar(usuario);
        Tema.estilizarItensMenuLateral(menuFuncionario);
        if (secaoAtual == null) {
            funcionarioInicio();
        }
    }

    @Override
    public void aoMudarTema() {
        configurarFundoMenu();
        estilizarLiquidGlass(dashboardFuncionario, menuFuncionario, botaoMenuFuncionario, botaoUsuarioFuncionario);
        Tema.estilizarItensMenuLateral(menuFuncionario);
        super.aoMudarTema();
        Tema.estilizarItensMenuLateral(menuFuncionario);
    }

    @Override
    public void aoAtualizarAvatar(Usuario usuario) {
        PerfilDialogo.atualizarBotaoUsuario(botaoUsuarioFuncionario, usuario);
        if (usuarioFuncionarioTexto != null) {
            usuarioFuncionarioTexto.setText(usuario != null ? usuario.getNome() : "Funcionário");
        }
    }

    @Override
    protected void configurarMenu(boolean compacto) {
        configurarMenu(menuFuncionario, areaFuncionario, botaoMenuFuncionario,
                rotuloPerfilFuncionario, usuarioFuncionarioTexto, compacto);
    }

    @Override
    protected VBox areaConteudo() {
        return areaFuncionario;
    }

    @Override
    protected Map<String, Runnable> rotasDePesquisa() {
        Map<String, Runnable> rotas = new LinkedHashMap<>();
        rotas.put("Início", this::funcionarioInicio);
        rotas.put("Meus atendimentos", this::funcionarioAtendimentos);
        rotas.put("Serviços", this::funcionarioServicos);
        rotas.put("Veículos", this::funcionarioVeiculos);
        rotas.put("Estoque", this::funcionarioEstoque);
        rotas.put("Minhas tarefas", this::funcionarioTarefas);
        return rotas;
    }

    // =========================================================
    // MENU
    // =========================================================

    /** Funcionário pode abrir configurações de tema, mas o debug exige senha (já protegido). */
    @Override
    public void abrirConfiguracoes() {
        ConfiguracoesDialogo.abrir();
    }

    @FXML private void funcionarioInicio() {
        lembrarSecao(this::mostrarInicioFuncionario, "Início");
        mostrarInicioFuncionario();
    }

    private void mostrarInicioFuncionario() {
        VBox area = areaConteudo();
        if (area == null) return;
        area.getChildren().clear();

        Label titulo = new Label("Início");
        titulo.setStyle("-fx-text-fill: " + paletaAtual().texto() + "; -fx-font-size: 26px; -fx-font-weight: bold;");
        Label sub = new Label("Suas tarefas e status dos serviços atribuídos a você.");
        sub.setStyle("-fx-text-fill: " + paletaAtual().textoSec() + "; -fx-font-size: 13px;");

        List<TarefaRef> minhas = listarMinhasTarefas();
        int ag = 0, and = 0, fin = 0;
        for (TarefaRef t : minhas) {
            if (t.servico.getStatus() == Status.AGENDADO) ag++;
            else if (t.servico.getStatus() == Status.ANDAMENTO) and++;
            else if (t.servico.getStatus() == Status.FINALIZADO) fin++;
        }

        HBox cards = new HBox(12);
        cards.getChildren().addAll(
                cardResumo("Minhas tarefas", String.valueOf(minhas.size())),
                cardResumo("Agendados", String.valueOf(ag)),
                cardResumo("Em andamento", String.valueOf(and)),
                cardResumo("Finalizados", String.valueOf(fin))
        );

        Label sec = Visual.tituloComIcone("📋", "Tarefas recentes", 17);

        TableView<Map<String, String>> tabela = tabelaTarefas(minhas);
        VBox.setVgrow(tabela, Priority.ALWAYS);

        HBox acoes = new HBox(10);
        Button btnIniciar = botaoSecao("▶  Iniciar");
        Button btnFinalizar = botaoSecao("✓  Finalizar");
        Button btnAtualizar = botaoSecao("↺  Atualizar");
        btnIniciar.setOnAction(e -> acaoStatus(tabela, minhas, true));
        btnFinalizar.setOnAction(e -> acaoStatus(tabela, minhas, false));
        btnAtualizar.setOnAction(e -> mostrarInicioFuncionario());
        acoes.getChildren().addAll(btnIniciar, btnFinalizar, btnAtualizar);

        if (minhas.isEmpty()) {
            Label vazio = new Label("Nenhuma tarefa atribuída ao seu nome de usuário.\n"
                    + "Peça ao administrador para vincular um mecânico com o mesmo nome da sua conta\n"
                    + "ou atribuir serviços no painel admin.");
            vazio.setStyle("-fx-text-fill: " + paletaAtual().textoSec() + "; -fx-font-size: 13px;");
            vazio.setWrapText(true);
            area.getChildren().addAll(titulo, sub, cards, sec, acoes, vazio, tabela);
        } else {
            area.getChildren().addAll(titulo, sub, cards, sec, acoes, tabela);
        }

        if (Tema.layoutCompacto()) {
            menuAberto = false;
            configurarMenu(true);
        }
    }

    @FXML private void funcionarioAtendimentos() {
        lembrarSecao(this::montarTarefasFuncionario, "Atendimentos");
        montarTarefasFuncionario();
    }

    @FXML private void funcionarioServicos() {
        lembrarSecao(this::montarServicosFuncionario, "Serviços");
        montarServicosFuncionario();
    }

    private void montarServicosFuncionario() {
        List<Map<String, String>> linhas = new ArrayList<>();
        int i = 1;
        for (Servico s : OficinaService.oficina().getCatalogoServicos()) {
            Map<String, String> row = new LinkedHashMap<>();
            row.put("Cód.", String.valueOf(i++));
            row.put("Nome", s.getNome());
            row.put("Preço", OficinaService.formatarMoeda(s.getPreco()));
            row.put("Usos", String.valueOf(s.getQuantidadeUsos()));
            linhas.add(row);
        }
        abrirSecao(
                "Serviços (consulta)",
                "Catálogo da oficina — somente leitura para funcionários.",
                new String[]{"Cód.", "Nome", "Preço", "Usos"},
                linhas,
                "Nenhum serviço no catálogo.",
                new String[][]{
                        {"Serviços", String.valueOf(linhas.size())},
                        {"Consulta", "Somente leitura"},
                        {"Perfil", "Funcionário"}
                },
                null,
                this::montarServicosFuncionario
        );
    }

    @FXML private void funcionarioVeiculos() {
        lembrarSecao(this::montarVeiculosFuncionario, "Veículos");
        montarVeiculosFuncionario();
    }

    private void montarVeiculosFuncionario() {
        List<Map<String, String>> linhas = new ArrayList<>();
        int i = 1;
        for (Veiculo v : OficinaService.listarTodosVeiculos()) {
            Map<String, String> row = new LinkedHashMap<>();
            row.put("Cód.", String.valueOf(i++));
            row.put("Placa", v.getPlaca());
            row.put("Modelo", v.getModelo());
            row.put("Cliente", v.getProprietario() != null ? v.getProprietario().getNome() : "—");
            row.put("Serviços", String.valueOf(v.getServicos().size()));
            linhas.add(row);
        }
        abrirSecao(
                "Veículos (consulta)",
                "Veículos cadastrados — somente leitura.",
                new String[]{"Cód.", "Placa", "Modelo", "Cliente", "Serviços"},
                linhas,
                "Nenhum veículo.",
                new String[][]{
                        {"Total", String.valueOf(linhas.size())},
                        {"Consulta", "Somente leitura"},
                        {"Perfil", "Funcionário"}
                },
                null,
                this::montarVeiculosFuncionario
        );
    }

    @FXML private void funcionarioEstoque() {
        lembrarSecao(this::montarEstoqueFuncionario, "Estoque");
        montarEstoqueFuncionario();
    }

    private void montarEstoqueFuncionario() {
        List<Map<String, String>> linhas = new ArrayList<>();
        int i = 1;
        int un = 0;
        for (Estoque e : OficinaService.oficina().getEstoque()) {
            Map<String, String> row = new LinkedHashMap<>();
            row.put("Cód.", String.valueOf(i++));
            row.put("Produto", e.getProduto());
            row.put("Qtd.", String.valueOf(e.getQuantidade()));
            row.put("Preço unit.", OficinaService.formatarMoeda(e.getPreco()));
            un += e.getQuantidade();
            linhas.add(row);
        }
        abrirSecao(
                "Estoque (consulta)",
                "Peças disponíveis — somente leitura. Movimentação é feita pelo administrador.",
                new String[]{"Cód.", "Produto", "Qtd.", "Preço unit."},
                linhas,
                "Estoque vazio.",
                new String[][]{
                        {"Itens", String.valueOf(linhas.size())},
                        {"Unidades", String.valueOf(un)},
                        {"Valor", OficinaService.formatarMoeda(OficinaService.valorEstoque())}
                },
                null,
                this::montarEstoqueFuncionario
        );
    }

    @FXML private void funcionarioSuporte() {
        lembrarSecao(this::montarSuporteFuncionario, "Suporte");
        montarSuporteFuncionario();
    }

    private void montarSuporteFuncionario() {
        VBox area = areaConteudo();
        if (area == null) return;
        try {
            ModulosFxml.carregar(area, "modulo-suporte-view.fxml");
            if (Tema.layoutCompacto()) { menuAberto = false; configurarMenu(true); }
        } catch (Exception ex) {
            ex.printStackTrace();
            mostrarMensagem("Suporte", "Falha: " + ex.getMessage());
        }
    }

    @FXML private void funcionarioTarefas() {
        lembrarSecao(this::montarTarefasFuncionario, "Tarefas");
        montarTarefasFuncionario();
    }

    private void montarTarefasFuncionario() {
        List<TarefaRef> minhas = listarMinhasTarefas();
        VBox area = areaConteudo();
        if (area == null) return;
        area.getChildren().clear();

        Label titulo = new Label("Minhas tarefas");
        titulo.setStyle("-fx-text-fill: " + paletaAtual().texto() + "; -fx-font-size: 26px; -fx-font-weight: bold;");
        Label sub = new Label("Serviços em que você está atribuído como mecânico. Selecione e inicie ou finalize.");
        sub.setStyle("-fx-text-fill: " + paletaAtual().textoSec() + "; -fx-font-size: 13px;");

        TableView<Map<String, String>> tabela = tabelaTarefas(minhas);
        VBox.setVgrow(tabela, Priority.ALWAYS);

        HBox acoes = new HBox(10);
        Button btnIniciar = botaoSecao("▶  Iniciar serviço");
        Button btnFinalizar = botaoSecao("✓  Finalizar serviço");
        Button btnAtualizar = botaoSecao("↺  Atualizar");
        btnIniciar.setOnAction(e -> acaoStatus(tabela, minhas, true));
        btnFinalizar.setOnAction(e -> acaoStatus(tabela, minhas, false));
        btnAtualizar.setOnAction(e -> funcionarioTarefas());
        acoes.getChildren().addAll(btnIniciar, btnFinalizar, btnAtualizar);

        Label badge = new Label(minhas.size() + " tarefa(s)");
        badge.setStyle("-fx-text-fill: #8fd4a0; -fx-font-size: 11px; -fx-background-color: rgba(143,212,160,0.12); -fx-background-radius: 8; -fx-padding: 4 10;");

        area.getChildren().addAll(titulo, sub, acoes, badge, tabela);
        if (Tema.layoutCompacto()) {
            menuAberto = false;
            configurarMenu(true);
        }
    }

    // =========================================================
    // TAREFAS / MECÂNICO
    // =========================================================

    /** Tarefa = execução de serviço em que o mecânico (mesmo nome do usuário) está na lista. */
    private static final class TarefaRef {
        final Cliente cliente;
        final Veiculo veiculo;
        final Servico servico;

        TarefaRef(Cliente c, Veiculo v, Servico s) {
            this.cliente = c;
            this.veiculo = v;
            this.servico = s;
        }
    }

    private List<TarefaRef> listarMinhasTarefas() {
        List<TarefaRef> out = new ArrayList<>();
        Usuario u = app.getUsuarioAtual();
        if (u == null) return out;

        String login = u.getLogin() != null ? u.getLogin().trim().toLowerCase(Locale.ROOT) : "";
        String nomeUser = u.getNome() != null ? u.getNome().trim().toLowerCase(Locale.ROOT) : "";

        for (Cliente c : OficinaService.oficina().getClientes()) {
            for (Veiculo v : c.getCarros()) {
                for (Servico s : v.getServicos()) {
                    for (Mecanico m : s.getMecanicos()) {
                        boolean match = false;
                        // 1) vínculo oficial por login da conta
                        if (!login.isBlank() && login.equals(m.getLoginVinculado())) {
                            match = true;
                        }
                        // 2) fallback: mesmo nome
                        if (!match && !nomeUser.isBlank()) {
                            String nm = m.getNome() != null ? m.getNome().trim().toLowerCase(Locale.ROOT) : "";
                            if (nm.equals(nomeUser) || (!nm.isBlank() && (nm.contains(nomeUser) || nomeUser.contains(nm)))) {
                                match = true;
                            }
                        }
                        if (match) {
                            out.add(new TarefaRef(c, v, s));
                            break;
                        }
                    }
                }
            }
        }
        return out;
    }

    private TableView<Map<String, String>> tabelaTarefas(List<TarefaRef> tarefas) {
        TableView<Map<String, String>> tabela = new TableView<>();
        tabela.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        tabela.setPlaceholder(new Label("Nenhuma tarefa atribuída."));
        Visual.estilizarTabela(tabela, 16);

        List<Map<String, String>> linhas = new ArrayList<>();
        int i = 0;
        for (TarefaRef t : tarefas) {
            Map<String, String> row = new LinkedHashMap<>();
            row.put("#", String.valueOf(i + 1));
            row.put("Cliente", t.cliente.getNome());
            row.put("Veículo", t.veiculo.getModelo());
            row.put("Placa", t.veiculo.getPlaca());
            row.put("Serviço", t.servico.getNome());
            row.put("Valor", OficinaService.formatarMoeda(t.servico.getPreco()));
            row.put("Status", t.servico.getStatus().name());
            row.put("_i", String.valueOf(i));
            linhas.add(row);
            i++;
        }
        for (String col : new String[]{"#", "Cliente", "Veículo", "Placa", "Serviço", "Valor", "Status"}) {
            TableColumn<Map<String, String>, String> c = new TableColumn<>(col);
            final String chave = col;
            c.setCellValueFactory(d -> new SimpleStringProperty(
                    d.getValue() != null ? d.getValue().getOrDefault(chave, "") : ""));
            tabela.getColumns().add(c);
        }
        tabela.setItems(FXCollections.observableArrayList(linhas));
        return tabela;
    }

    private void acaoStatus(TableView<Map<String, String>> tabela, List<TarefaRef> tarefas, boolean iniciar) {
        Map<String, String> sel = tabela.getSelectionModel().getSelectedItem();
        if (sel == null) {
            mostrarMensagem("Tarefa", "Selecione uma tarefa na tabela.");
            return;
        }
        int idx;
        try {
            idx = Integer.parseInt(sel.getOrDefault("_i", "-1"));
        } catch (NumberFormatException e) {
            return;
        }
        if (idx < 0 || idx >= tarefas.size()) return;
        TarefaRef t = tarefas.get(idx);
        try {
            if (iniciar) {
                OficinaService.iniciarServico(t.cliente, t.veiculo, t.servico);
                mostrarMensagem("Tarefa", "Serviço iniciado com sucesso!");
            } else {
                OficinaService.finalizarServico(t.cliente, t.veiculo, t.servico);
                mostrarMensagem("Tarefa", "Serviço finalizado com sucesso!");
            }
            funcionarioTarefas();
        } catch (Exception ex) {
            mostrarMensagem("Tarefa", ex.getMessage() != null ? ex.getMessage() : "Operação não permitida.");
        }
    }
}
