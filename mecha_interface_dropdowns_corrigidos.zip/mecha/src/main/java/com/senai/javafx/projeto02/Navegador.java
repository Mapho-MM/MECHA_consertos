package com.senai.javafx.projeto02;

import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.concurrent.Task;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.concurrent.Callable;
import java.util.function.Consumer;

/**
 * Troca de telas do sistema. Cada tela é um FXML + um controller próprios;
 * o Navegador carrega a tela pedida, coloca no palco e aplica o tema.
 *
 * Uso: {@code Navegador.ir(Navegador.Tela.LOGIN);}
 * Também devolve o controller da tela aberta, para passar algum dado:
 * {@code Navegador.<AjudaController>ir(Navegador.Tela.AJUDA).mostrarSenha();}
 */
public final class Navegador {

    private Navegador() {
    }

    /** Todas as telas do sistema e o FXML de cada uma. */
    public enum Tela {
        SPLASH("splash-view.fxml"),
        LOGIN("login-view.fxml"),
        AJUDA("ajuda-view.fxml"),
        DASHBOARD_ADMIN("dashboard-admin-view.fxml"),
        DASHBOARD_FUNCIONARIO("dashboard-funcionario-view.fxml");

        private final String arquivo;

        Tela(String arquivo) {
            this.arquivo = arquivo;
        }

        public String arquivo() {
            return arquivo;
        }
    }

    private static final String PASTA_FXML = "/com/senai/javafx/projeto02/";

    // Só mostra o carregando se a tarefa demorar mais do que isso.
    private static final long ATRASO_PARA_MOSTRAR_MS = 300;

    private static StackPane raiz;
    private static StackPane palco;
    private static CarregandoController carregamento;

    private static Tela telaAtualId;
    private static Parent telaAtual;
    private static Object controladorAtual;
    private static boolean tarefaEmAndamento = false;

    /** Chamado pelo MainController quando a janela principal é montada. */
    static void registrar(StackPane raizPrincipal, StackPane palcoDasTelas, CarregandoController carregando) {
        raiz = raizPrincipal;
        palco = palcoDasTelas;
        carregamento = carregando;

        Tema.aplicarTema();

        // Interface adaptável: reage ao redimensionar / arrastar a janela.
        raiz.sceneProperty().addListener((obs, antiga, cena) -> {
            if (cena != null) {
                instalarAdaptacaoJanela(cena);
                atualizarLayout();
            }
        });
        if (raiz.getScene() != null) {
            instalarAdaptacaoJanela(raiz.getScene());
            atualizarLayout();
        }
    }

    // =========================================================
    // ACESSO AO ESTADO ATUAL
    // =========================================================

    public static StackPane raiz() {
        return raiz;
    }

    public static CarregandoController carregamento() {
        return carregamento;
    }

    public static Parent telaAtual() {
        return telaAtual;
    }

    public static Object controladorAtual() {
        return controladorAtual;
    }

    public static Tela telaAtualId() {
        return telaAtualId;
    }

    // =========================================================
    // NAVEGAÇÃO
    // =========================================================

    /** Abre a tela pedida e devolve o controller dela. */
    @SuppressWarnings("unchecked")
    public static <T> T ir(Tela tela) {
        if (palco == null) {
            throw new IllegalStateException("A janela principal ainda não foi iniciada.");
        }

        URL fxml = Navegador.class.getResource(PASTA_FXML + tela.arquivo());
        if (fxml == null) {
            throw new IllegalStateException(tela.arquivo() + " não foi encontrado em resources.");
        }

        long inicioCarregamento = System.nanoTime();
        Tema.debugLog("Navegação iniciada: " + tela + " (FXML=" + tela.arquivo() + ")");
        try {
            FXMLLoader loader = new FXMLLoader(fxml);
            Parent nova = loader.load();
            Object controlador = loader.getController();

            telaAtualId = tela;
            telaAtual = nova;
            controladorAtual = controlador;

            palco.getChildren().setAll(nova);

            Tema.aplicarNaTelaAtual();
            Animacoes.instalarMicro(nova);
            if (controlador instanceof TelaController t) {
                t.aoMudarLayout(Tema.layoutCompacto());
            }

            if (tela != Tela.SPLASH) {
                animar(nova);
            }
            if (controlador instanceof TelaController t) {
                t.aoEntrar();
            }

            long duracaoMs = (System.nanoTime() - inicioCarregamento) / 1_000_000L;
            Tema.debugLog("Tela aberta: " + tela + " | controller="
                    + (controlador == null ? "nenhum" : controlador.getClass().getSimpleName())
                    + " | duração=" + duracaoMs + "ms");
            return (T) controlador;
        } catch (IOException | RuntimeException e) {
            Tema.debugErro("Falha ao abrir tela " + tela + " (" + tela.arquivo() + ")", e);
            throw new IllegalStateException("Não foi possível abrir a tela " + tela + ": " + e.getMessage(), e);
        }
    }

    /** A autenticação disponível nesta versão é exclusiva para a conta administrativa. */
    public static void irParaPainel(Usuario usuario) {
        if (usuario == null || !"ADMINISTRADOR".equalsIgnoreCase(usuario.getPerfil())) {
            AppSingleton.getInstance().limparSessao();
            ir(Tela.LOGIN);
            return;
        }
        ir(Tela.DASHBOARD_ADMIN);
    }

    /**
     * Encerra a sessão e volta ao login. A tela de login é montada do zero,
     * então usuário e senha vêm vazios e a senha volta ao modo oculto.
     */
    public static void voltarAoLogin() {
        AppSingleton.getInstance().limparSessao();
        ir(Tela.LOGIN);
    }

    private static boolean ultimoCompacto = false;
    private static PauseTransition debounceLayout;

    private static void instalarAdaptacaoJanela(Scene cena) {
        if (cena.getProperties().containsKey("mecha.layout.instalado")) return;
        cena.getProperties().put("mecha.layout.instalado", Boolean.TRUE);

        Runnable agendar = () -> {
            if (debounceLayout == null) {
                debounceLayout = new PauseTransition(Duration.millis(80));
                debounceLayout.setOnFinished(e -> atualizarLayout());
            }
            debounceLayout.stop();
            debounceLayout.playFromStart();
        };

        cena.widthProperty().addListener((o, a, n) -> agendar.run());
        cena.heightProperty().addListener((o, a, n) -> agendar.run());

        if (cena.getWindow() != null) {
            cena.getWindow().widthProperty().addListener((o, a, n) -> agendar.run());
            cena.getWindow().heightProperty().addListener((o, a, n) -> agendar.run());
        } else {
            cena.windowProperty().addListener((o, a, w) -> {
                if (w != null) {
                    w.widthProperty().addListener((o2, a2, n2) -> agendar.run());
                    w.heightProperty().addListener((o2, a2, n2) -> agendar.run());
                }
            });
        }
    }

    /** Avisa a tela atual que a janela mudou de tamanho / modo de layout. */
    public static void atualizarLayout() {
        boolean compacto = Tema.layoutCompacto();
        if (controladorAtual instanceof TelaController t) {
            t.aoMudarLayout(compacto);
        }
        ultimoCompacto = compacto;
        try {
            Tema.atualizarAmbienteLiquidGlass();
        } catch (Exception ignored) {
        }
    }

    // =========================================================
    // CARREGANDO (carro girando)
    // =========================================================

    /**
     * Roda um trabalho demorado fora da tela e mostra o carro girando
     * apenas se ele levar mais de 300 ms. Reutilize para qualquer carregamento
     * (abrir arquivo, buscar dados, salvar...).
     */
    public static <T> void executarComCarregamento(String mensagem, Callable<T> trabalho,
                                                   Consumer<T> aoConcluir, Consumer<Throwable> aoFalhar) {
        if (tarefaEmAndamento) return; // ignora cliques repetidos
        tarefaEmAndamento = true;

        Task<T> tarefa = new Task<>() {
            @Override
            protected T call() throws Exception {
                return trabalho.call();
            }
        };

        PauseTransition atraso = new PauseTransition(Duration.millis(ATRASO_PARA_MOSTRAR_MS));
        atraso.setOnFinished(event -> {
            if (carregamento != null) carregamento.mostrar(mensagem);
        });
        atraso.play();

        tarefa.setOnSucceeded(event -> {
            atraso.stop();
            if (carregamento != null) carregamento.esconder();
            tarefaEmAndamento = false;
            aoConcluir.accept(tarefa.getValue());
        });

        tarefa.setOnFailed(event -> {
            atraso.stop();
            if (carregamento != null) carregamento.esconder();
            tarefaEmAndamento = false;
            aoFalhar.accept(tarefa.getException());
        });

        Thread fio = new Thread(tarefa, "carregamento");
        fio.setDaemon(true);
        fio.start();
    }

    // =========================================================
    // ANIMAÇÕES
    // =========================================================

    public static void animar(Node no) {
        Animacoes.entrada(no, 18, 420);
    }
}
