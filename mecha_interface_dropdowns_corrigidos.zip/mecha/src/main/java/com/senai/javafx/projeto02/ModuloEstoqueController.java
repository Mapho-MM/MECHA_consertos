package com.senai.javafx.projeto02;

import com.senai.javafx.projeto02.entidades.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static com.senai.javafx.projeto02.Dialogos.*;
import static com.senai.javafx.projeto02.Tema.*;

/** Controller FXML: modulo-estoque-view.fxml — LayoutPadrao. */
public class ModuloEstoqueController {

    @FXML private Label titulo;
    @FXML private Button btnAtualizar;
    @FXML private HBox caixaCards;
    @FXML private FlowPane caixaFiltros;
    @FXML private FlowPane caixaAcoes;
    @FXML private Button btnPecasVeiculo, btnPecaVeiculo;
    @FXML private Button btnVender, btnRemover, btnAlterar, btnRepor, btnCadastrar;
    @FXML private TableView<Map<String, String>> tabela;
    @FXML private Label rodape;

    private List<Estoque> listaAtual = List.of();

    @FXML
    private void initialize() {
        tabela.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        LayoutPadrao.estilizarTabela(tabela);
        for (String col : new String[]{"Cód.", "Produto", "Qtd.", "Preço unit.", "Subtotal"}) {
            TableColumn<Map<String, String>, String> c = new TableColumn<>(col);
            final String chave = col;
            c.setCellValueFactory(d -> new SimpleStringProperty(
                    d.getValue() != null ? d.getValue().getOrDefault(chave, "") : ""));
            tabela.getColumns().add(c);
        }

        Paleta p = paletaAtual();
        if (titulo != null) {
            titulo.setStyle("-fx-text-fill: " + p.texto() + "; -fx-font-size: 26px; -fx-font-weight: bold;");
        }
        if (btnAtualizar != null) {
            btnAtualizar.setText("↻");
            btnAtualizar.setTooltip(new Tooltip("Atualizar"));
            btnAtualizar.setStyle(
                    "-fx-background-color: " + LayoutPadrao.COR_PRIMARIO + ";" +
                    "-fx-text-fill: #ffffff;" +
                    "-fx-font-size: 16px; -fx-font-weight: bold;" +
                    "-fx-background-radius: 18; -fx-border-radius: 18;" +
                    "-fx-border-color: " + LayoutPadrao.COR_NEUTRO_BD + "; -fx-border-width: 1;" +
                    "-fx-cursor: hand; -fx-padding: 0;"
            );
        }
        aplicarEstilosAcoes();
        if (caixaAcoes != null) caixaAcoes.setPrefWrapLength(900);
        if (caixaFiltros != null) caixaFiltros.setPrefWrapLength(900);
        onListar();
    }

    private void aplicarEstilosAcoes() {
        estiloNeutro(btnPecasVeiculo);
        estiloNeutro(btnPecaVeiculo);
        estilo(btnVender, LayoutPadrao.COR_PRIMARIO, "#ffffff");
        estilo(btnRemover, LayoutPadrao.COR_DESTRUTIVO, "#ffffff");
        estilo(btnAlterar, LayoutPadrao.COR_EDICAO, "#1a1a1a");
        estilo(btnRepor, LayoutPadrao.COR_SUCESSO, "#ffffff");
        estilo(btnCadastrar, LayoutPadrao.COR_PRIMARIO, "#ffffff");
    }

    private void estiloNeutro(Button b) {
        if (b == null) return;
        Paleta p = paletaAtual();
        b.setPrefHeight(36);
        b.setMinWidth(Region.USE_PREF_SIZE);
        b.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-text-fill: " + p.texto() + "; -fx-font-size: 13px;" +
                "-fx-background-radius: 12; -fx-border-radius: 12;" +
                "-fx-border-color: rgba(255,255,255,0.12); -fx-border-width: 1;" +
                "-fx-cursor: hand; -fx-padding: 0 14;"
        );
    }

    private void estilo(Button b, String fundo, String texto) {
        if (b == null) return;
        b.setPrefHeight(36);
        b.setMinWidth(Region.USE_PREF_SIZE);
        b.setStyle(
                "-fx-background-color: " + fundo + ";" +
                "-fx-text-fill: " + texto + ";" +
                "-fx-font-size: 13px; -fx-font-weight: bold;" +
                "-fx-background-radius: 12; -fx-border-radius: 12; -fx-border-width: 0;" +
                "-fx-cursor: hand; -fx-padding: 0 14;"
        );
    }

    @FXML
    public void onListar() {
        listaAtual = OficinaService.oficina().getEstoque();
        List<Map<String, String>> linhas = new ArrayList<>();
        int i = 1;
        for (Estoque e : listaAtual) {
            Map<String, String> row = new LinkedHashMap<>();
            row.put("Cód.", String.valueOf(i++));
            row.put("Produto", e.getProduto());
            row.put("Qtd.", String.valueOf(e.getQuantidade()));
            row.put("Preço unit.", OficinaService.formatarMoeda(e.getPreco()));
            row.put("Subtotal", OficinaService.formatarMoeda(e.getPreco() * e.getQuantidade()));
            row.put("_idx", String.valueOf(listaAtual.indexOf(e)));
            linhas.add(row);
        }
        tabela.setItems(FXCollections.observableArrayList(linhas));
        tabela.setPlaceholder(new Label("Estoque vazio."));
        LayoutPadrao.estilizarTabela(tabela);
        LayoutPadrao.atualizarRodape(rodape, linhas.size());

        caixaCards.getChildren().setAll(
                LayoutPadrao.cardIndicador("Produtos", String.valueOf(listaAtual.size())),
                LayoutPadrao.cardIndicador("Unidades", String.valueOf(OficinaService.totalUnidadesEstoque())),
                LayoutPadrao.cardIndicador("Valor estoque", OficinaService.formatarMoeda(OficinaService.valorEstoque())),
                LayoutPadrao.cardIndicador("Estoque baixo (≤3)", String.valueOf(OficinaService.itensEstoqueBaixo(3)))
        );
    }

    private Estoque selecionada() {
        Map<String, String> sel = tabela.getSelectionModel().getSelectedItem();
        if (sel == null) {
            mostrarMensagem("Estoque", "Selecione uma peça na tabela.");
            return null;
        }
        try {
            int idx = Integer.parseInt(sel.getOrDefault("_idx", "-1"));
            if (idx < 0 || idx >= listaAtual.size()) return null;
            return listaAtual.get(idx);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @FXML private void onPecaVeiculo() {
        CadastroDialogos.adicionarPecaVeiculo(this::onListar);
    }

    @FXML private void onVender() {
        Estoque e = selecionada();
        if (e != null) CadastroDialogos.venderPeca(e, this::onListar);
    }

    @FXML private void onCadastrar() {
        CadastroDialogos.cadastrarPeca(this::onListar);
    }

    @FXML private void onAlterar() {
        Estoque e = selecionada();
        if (e != null) CadastroDialogos.editarPeca(e, this::onListar);
    }

    @FXML private void onRemover() {
        Estoque e = selecionada();
        if (e == null) return;
        if (!confirmar("Remover", "Remover \"" + e.getProduto() + "\" do catálogo?", "Não", "Remover")) return;
        try {
            OficinaService.removerPecaDoCatalogo(e);
            onListar();
        } catch (Exception ex) {
            mostrarMensagem("Estoque", ex.getMessage());
        }
    }

    @FXML private void onRepor() {
        Estoque e = selecionada();
        if (e != null) CadastroDialogos.reporPeca(e, this::onListar);
    }

    @FXML private void onPecasVeiculo() {
        CadastroDialogos.gerenciarPecasVeiculo(this::onListar);
    }
}
