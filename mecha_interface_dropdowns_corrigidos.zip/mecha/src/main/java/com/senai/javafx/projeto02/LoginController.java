package com.senai.javafx.projeto02;

import javafx.animation.*;
import javafx.application.Platform;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.effect.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.stage.*;
import javafx.util.Duration;
import javafx.fxml.FXML;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.senai.javafx.projeto02.Tema.Paleta;

import static com.senai.javafx.projeto02.Dialogos.*;
import static com.senai.javafx.projeto02.Tema.*;

/** Tela de login (login-view.fxml). */
public class LoginController implements TelaController {

    @FXML private VBox telaLogin;
    @FXML private ImageView fundoLogin;
    @FXML private ImageView logoLogin;
    @FXML private Button botaoDebugEntrar;

    @FXML private TextField loginCampo;
    @FXML private PasswordField senhaCampo;
    @FXML private Label loginMensagem;

    // O login comum é exclusivo para a conta administrativa.
    @FXML private TextField senhaVisivel;
    @FXML private ToggleButton botaoOlho;

    private final AppSingleton app = AppSingleton.getInstance();
    private final UsuarioService usuarioService = new UsuarioService();

    /*
     * Para PRÉ-VISUALIZAR o carro girando, troque 0 por 2000 (2 segundos):
     * o login passa a demorar de propósito e o indicador aparece.
     * Deixe 0 na versão final.
     */
    private static final long ATRASO_TESTE_LOGIN_MS = 0;

    /** RNF: 5 senhas erradas seguidas bloqueiam aquele login por 1 minuto. */
    private static final int MAX_FALHAS_SENHA = 5;
    private static final long BLOQUEIO_LOGIN_MS = 60_000L;
    private static final Map<String, Integer> falhasPorLogin = new ConcurrentHashMap<>();
    private static final Map<String, Long> bloqueadoAte = new ConcurrentHashMap<>();
    private String tentativaLogin = "";

    @FXML
    public void initialize() {
        // Fundo do login acompanha o tamanho da janela. A mesma imagem é usada na animação inicial.
        if (fundoLogin != null && fundoLogin.getParent() instanceof AnchorPane raizTela) {
            fundoLogin.fitWidthProperty().bind(raizTela.widthProperty());
            fundoLogin.fitHeightProperty().bind(raizTela.heightProperty());
        }

        // Campo de senha visível e oculto compartilham o mesmo texto.
        senhaVisivel.textProperty().bindBidirectional(senhaCampo.textProperty());

        atualizarBotaoDebug();

        senhaCampo.setOnAction(event -> realizarLogin());
        senhaVisivel.setOnAction(event -> realizarLogin());
    }

    @Override
    public void aoEntrar() {
        atualizarBotaoDebug();
        Platform.runLater(() -> {
            if (Tema.modoDebug() && botaoDebugEntrar != null) botaoDebugEntrar.requestFocus();
            else loginCampo.requestFocus();
        });
    }

    @Override
    public void aoMudarTema() {
        estilizarCartao(telaLogin);
        atualizarBotaoDebug();
    }

    /** Mantém o botão visível, mas só permite a entrada rápida no modo desenvolvedor. */
    public void atualizarBotaoDebug() {
        if (botaoDebugEntrar == null) return;
        boolean ativo = Tema.modoDebug();
        botaoDebugEntrar.setVisible(ativo);
        botaoDebugEntrar.setManaged(ativo);
        if (!ativo) return;
        botaoDebugEntrar.setTooltip(new Tooltip(ativo
                ? "Modo desenvolvedor ativo: entrar com a conta de teste"
                : "Ative o modo desenvolvedor em Configurações para usar este atalho"));
        if (ativo) {
            botaoDebugEntrar.setStyle("-fx-background-color: " + fundoDestaque() + ";" +
                    "-fx-background-radius: 22; -fx-text-fill: " + textoSobreDestaque() + ";" +
                    "-fx-font-size: 13px; -fx-font-weight: bold; -fx-cursor: hand;");
        } else {
            botaoDebugEntrar.setStyle("-fx-background-color: rgba(255,255,255,0.08);" +
                    "-fx-background-radius: 22; -fx-border-color: rgba(255,255,255,0.16);" +
                    "-fx-border-radius: 22; -fx-text-fill: white;" +
                    "-fx-font-size: 13px; -fx-font-weight: bold; -fx-cursor: hand;");
        }
    }

    /** Entrada rápida somente no modo desenvolvedor. */
    @FXML
    private void entrarDebugRapido() {
        if (!Tema.modoDebug()) {
            loginMensagem.setText("Ative o modo desenvolvedor nas Configurações.");
            atualizarBotaoDebug();
            return;
        }
        try {
            Usuario admin = usuarioService.autenticar("admin@mecha.com", "admin123");
            if (admin == null) admin = new Usuario("Administrador", "admin@mecha.com", "", "ADMINISTRADOR");
            app.registrarLogin(admin);
            loginMensagem.setText("");
            Navegador.irParaPainel(admin);
        } catch (Exception e) {
            loginMensagem.setText("Falha no login de desenvolvimento: " + e.getMessage());
            Tema.debugErro("Falha na entrada de desenvolvimento", e);
        }
    }

    @Override
    public void aoMudarLayout(boolean compacto) {
        telaLogin.setPadding(compacto ? new Insets(24, 20, 24, 20) : new Insets(34, 42, 34, 42));
    }

    // =========================================================
    // LOGIN
    // =========================================================

    @FXML
    private void realizarLogin() {
        String identificador = loginCampo.getText() == null ? "" : loginCampo.getText().trim();
        String senha = senhaCampo.getText() == null ? "" : senhaCampo.getText();
        debugLog("Tentativa de login administrativo usando nome/e-mail.");

        if (identificador.isBlank() || senha.isBlank()) {
            loginMensagem.setText("Digite seu nome ou e-mail e a senha.");
            return;
        }

        long restante = segundosBloqueio(identificador);
        if (restante > 0) {
            loginMensagem.setText("Login bloqueado por " + restante
                    + " segundo(s). Você errou a senha 5 vezes seguidas.");
            Navegador.animar(loginMensagem);
            return;
        }

        tentativaLogin = identificador;

        Navegador.executarComCarregamento(
                "Entrando...",
                () -> {
                    if (ATRASO_TESTE_LOGIN_MS > 0) {
                        Thread.sleep(ATRASO_TESTE_LOGIN_MS);
                    }
                    return usuarioService.autenticar(identificador, senha);
                },
                this::concluirLogin,
                erro -> {
                    loginMensagem.setText("Não foi possível abrir o sistema: " + erro.getMessage());
                    erro.printStackTrace();
                }
        );
    }

    private void concluirLogin(Usuario usuario) {
        try {
            if (usuario == null) {
                registrarFalhaSenha(tentativaLogin);
                long bloqueio = segundosBloqueio(tentativaLogin);
                if (bloqueio > 0) {
                    loginMensagem.setText("Senha incorreta 5 vezes. Este login fica bloqueado por "
                            + bloqueio + " segundo(s).");
                } else {
                    int feitas = falhasPorLogin.getOrDefault(chaveLogin(tentativaLogin), 0);
                    loginMensagem.setText("Nome/e-mail ou senha inválidos. Tentativa "
                            + feitas + " de " + MAX_FALHAS_SENHA + ".");
                }
                senhaCampo.clear();
                Navegador.animar(loginMensagem);
                return;
            }

            limparFalhas(tentativaLogin);

            // A área de login não oferece mais autenticação para contas de funcionário.
            if (!"ADMINISTRADOR".equalsIgnoreCase(usuario.getPerfil())) {
                loginMensagem.setText("Esta conta não tem permissão de administrador.");
                senhaCampo.clear();
                Navegador.animar(loginMensagem);
                return;
            }

            loginMensagem.setText("");
            senhaCampo.clear();
            app.registrarLogin(usuario);

            // Login concluído: abre a tela do painel do usuário.
            Navegador.irParaPainel(usuario);

        } catch (Exception e) {
            loginMensagem.setText("Não foi possível abrir o sistema: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static String chaveLogin(String identificador) {
        return identificador == null ? "" : identificador.trim().toLowerCase();
    }

    static long segundosBloqueio(String identificador) {
        Long ate = bloqueadoAte.get(chaveLogin(identificador));
        if (ate == null) return 0;
        long resta = ate - System.currentTimeMillis();
        if (resta <= 0) {
            bloqueadoAte.remove(chaveLogin(identificador));
            falhasPorLogin.remove(chaveLogin(identificador));
            return 0;
        }
        return (resta + 999) / 1000;
    }

    private static void registrarFalhaSenha(String identificador) {
        String chave = chaveLogin(identificador);
        int n = falhasPorLogin.merge(chave, 1, Integer::sum);
        if (n >= MAX_FALHAS_SENHA) {
            bloqueadoAte.put(chave, System.currentTimeMillis() + BLOQUEIO_LOGIN_MS);
            falhasPorLogin.put(chave, 0);
        }
    }

    private static void limparFalhas(String identificador) {
        String chave = chaveLogin(identificador);
        falhasPorLogin.remove(chave);
        bloqueadoAte.remove(chave);
    }

    // =========================================================
    // NAVEGAÇÃO PARA OUTRAS TELAS
    // =========================================================


    @FXML
    private void abrirRecuperacao() {
        Navegador.<AjudaController>ir(Navegador.Tela.AJUDA).mostrarSenha();
    }

    @FXML
    private void abrirProblemasLogin() {
        Navegador.<AjudaController>ir(Navegador.Tela.AJUDA).mostrarProblemasParaEntrar();
    }

    @FXML
    private void abrirConfiguracoes() {
        ConfiguracoesDialogo.abrir();
    }

    /** Interface de criação de conta de administrador. */
    @FXML
    private void abrirCriarConta() {
        Paleta p = paletaAtual();
        Stage janela = criarJanelaTematica();
        janela.setTitle("Criar conta");

        VBox cartao = criarCartaoTematico(420, p);
        cartao.setSpacing(14);
        cartao.setAlignment(Pos.TOP_CENTER);

        Label titulo = new Label("Criar conta de administrador");
        titulo.setStyle("-fx-text-fill: " + p.texto() + "; -fx-font-size: 20px; -fx-font-weight: bold;");
        Label sub = new Label("Somente perfil administrador. Depois use e-mail e senha para entrar.");
        sub.setWrapText(true);
        sub.setStyle("-fx-text-fill: " + p.textoSec() + "; -fx-font-size: 12px;");

        TextField nome = campoTexto(p, "Nome completo");
        TextField email = campoTexto(p, "E-mail (login)");
        PasswordField senha = campoSenha(p, "Senha");
        PasswordField senha2 = campoSenha(p, "Confirmar senha");
        Label msg = new Label("");
        msg.setWrapText(true);
        msg.setStyle("-fx-text-fill: #ff8a8a; -fx-font-size: 12px;");

        Button criar = botaoPrimario("Criar conta", p);
        criar.setMaxWidth(Double.MAX_VALUE);
        criar.setPrefHeight(46);
        criar.setOnAction(ev -> {
            String n = nome.getText() == null ? "" : nome.getText().trim();
            String e = email.getText() == null ? "" : email.getText().trim();
            String s = senha.getText() == null ? "" : senha.getText();
            String s2 = senha2.getText() == null ? "" : senha2.getText();
            if (n.isBlank() || e.isBlank() || s.isBlank()) {
                msg.setText("Preencha nome, e-mail e senha.");
                return;
            }
            if (!e.contains("@")) {
                msg.setText("Informe um e-mail válido.");
                return;
            }
            if (!s.equals(s2)) {
                msg.setText("As senhas não coincidem.");
                return;
            }
            if (s.length() < 4) {
                msg.setText("A senha deve ter pelo menos 4 caracteres.");
                return;
            }
            boolean ok = usuarioService.cadastrar(n, e, s, "ADMINISTRADOR");
            if (ok) {
                loginCampo.setText(e);
                senhaCampo.setText(s);
                loginMensagem.setStyle("-fx-text-fill: #6ee7a8; -fx-font-size: 12px;");
                loginMensagem.setText("Conta de administrador criada! Faça login.");
                janela.close();
            } else {
                msg.setText("Não foi possível criar (e-mail já existe ou dados inválidos).");
            }
        });

        Button cancelar = botaoSecundario("Cancelar", p);
        cancelar.setMaxWidth(Double.MAX_VALUE);
        cancelar.setOnAction(ev -> janela.close());

        cartao.getChildren().addAll(
                titulo, sub,
                rotuloCampo("Nome", p), nome,
                rotuloCampo("E-mail", p), email,
                rotuloCampo("Senha", p), senha,
                rotuloCampo("Confirmar senha", p), senha2,
                msg, criar, cancelar
        );
        exibirJanela(janela, cartao);
    }

    private static Label rotuloCampo(String txt, Paleta p) {
        Label l = new Label(txt);
        l.setStyle("-fx-text-fill: " + p.textoSec() + "; -fx-font-size: 12px;");
        l.setMaxWidth(Double.MAX_VALUE);
        return l;
    }

    private static TextField campoTexto(Paleta p, String prompt) {
        TextField t = new TextField();
        t.setPromptText(prompt);
        t.setPrefHeight(44);
        t.setMaxWidth(Double.MAX_VALUE);
        t.setStyle(
                "-fx-background-color: " + p.overlay() + "0.10);" +
                "-fx-text-fill: " + p.texto() + ";" +
                "-fx-prompt-text-fill: " + p.textoTerc() + ";" +
                "-fx-background-radius: 14;" +
                "-fx-border-color: " + p.borda() + ";" +
                "-fx-border-radius: 14; -fx-padding: 0 12;"
        );
        return t;
    }

    private static PasswordField campoSenha(Paleta p, String prompt) {
        PasswordField t = new PasswordField();
        t.setPromptText(prompt);
        t.setPrefHeight(44);
        t.setMaxWidth(Double.MAX_VALUE);
        t.setStyle(
                "-fx-background-color: " + p.overlay() + "0.10);" +
                "-fx-text-fill: " + p.texto() + ";" +
                "-fx-prompt-text-fill: " + p.textoTerc() + ";" +
                "-fx-background-radius: 14;" +
                "-fx-border-color: " + p.borda() + ";" +
                "-fx-border-radius: 14; -fx-padding: 0 12;"
        );
        return t;
    }

    @FXML
    private void alternarSenha() {
        boolean mostrar = botaoOlho.isSelected();

        senhaVisivel.setVisible(mostrar);
        senhaVisivel.setManaged(mostrar);
        senhaCampo.setVisible(!mostrar);
        senhaCampo.setManaged(!mostrar);

        TextField ativo = mostrar ? senhaVisivel : senhaCampo;
        ativo.requestFocus();
        ativo.positionCaret(ativo.getText().length());
    }

}
