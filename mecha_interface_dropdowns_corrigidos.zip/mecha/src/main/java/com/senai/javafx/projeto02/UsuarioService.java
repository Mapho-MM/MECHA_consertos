package com.senai.javafx.projeto02;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;

public class UsuarioService {

    // Passa pelo Armazenamento: com o modo desenvolvedor ativo nada vai para o disco.
    private final Armazenamento preferencias = Armazenamento.get();

    private static final String PREFIXO = "usuario.";
    private static final String LISTA = "listaUsuarios";

    public UsuarioService() {
        criarAdministradorPadrao();
    }


    /** Lista todas as contas cadastradas (admin). */
    public List<Usuario> listarTodos() {
        List<Usuario> lista = new ArrayList<>();
        String raw = preferencias.get(LISTA, "");
        if (raw == null || raw.isBlank()) {
            // garante admin mesmo se lista vazia
            Usuario admin = buscarPorLogin("admin@mecha.com");
            if (admin != null) lista.add(admin);
            return lista;
        }
        for (String login : raw.split("\\|")) {
            if (login == null || login.isBlank()) continue;
            Usuario u = buscarPorLogin(login.trim());
            if (u != null) lista.add(u);
        }
        return lista;
    }

    public boolean cadastrar(String nome, String login, String senha) {
        return cadastrar(nome, login, senha, "FUNCIONARIO");
    }

    public boolean cadastrar(String nome, String login, String senha, String perfil) {
        nome = limpar(nome);
        login = limpar(login).toLowerCase();
        perfil = limpar(perfil).isBlank() ? "FUNCIONARIO" : limpar(perfil).toUpperCase();
        if (!perfil.equals("ADMINISTRADOR") && !perfil.equals("FUNCIONARIO")) {
            perfil = "FUNCIONARIO";
        }

        if (nome.isBlank() || login.isBlank() || senha == null || senha.isBlank()) {
            return false;
        }
        if (!login.contains("@")) {
            return false;
        }
        if (buscarPorLogin(login) != null) {
            return false;
        }

        String hash = hash(senha);
        preferencias.put(PREFIXO + login + ".nome", nome);
        preferencias.put(PREFIXO + login + ".hash", hash);
        preferencias.put(PREFIXO + login + ".perfil", perfil);

        String lista = preferencias.get(LISTA, "");
        preferencias.put(LISTA, lista.isBlank() ? login : lista + "|" + login);
        return true;
    }

    /**
     * Autentica usando o login de e-mail ou o nome completo da conta.
     * Se o identificador tiver @, a busca é feita pelo e-mail; caso contrário,
     * a busca é feita pelo nome. A senha continua sendo obrigatória nos dois casos.
     */
    public Usuario autenticar(String identificador, String senha) {
        identificador = limpar(identificador);

        if (identificador.isBlank() || senha == null || senha.isBlank()) {
            return null;
        }

        Usuario usuario;
        if (identificador.contains("@")) {
            usuario = buscarPorLogin(identificador.toLowerCase());
        } else {
            usuario = buscarPorNome(identificador);
        }

        if (usuario == null) {
            return null;
        }

        return usuario.getSenhaHash().equals(hash(senha)) ? usuario : null;
    }

    /**
     * Atualiza o nome de exibição da conta. O login (e-mail) não muda.
     * Retorna o usuário atualizado ou null se falhar.
     */
    public Usuario atualizarNome(String login, String novoNome) {
        login = limpar(login).toLowerCase();
        novoNome = limpar(novoNome);
        if (login.isBlank() || novoNome.isBlank()) {
            return null;
        }
        Usuario atual = buscarPorLogin(login);
        if (atual == null) {
            return null;
        }
        preferencias.put(PREFIXO + login + ".nome", novoNome);
        return new Usuario(novoNome, atual.getLogin(), atual.getSenhaHash(), atual.getPerfil());
    }

    public Usuario buscarPorLogin(String login) {
        String nome = preferencias.get(PREFIXO + login + ".nome", null);
        String hash = preferencias.get(PREFIXO + login + ".hash", null);
        String perfil = preferencias.get(PREFIXO + login + ".perfil", null);

        if (nome == null || hash == null || perfil == null) {
            return null;
        }

        return new Usuario(nome, login, hash, perfil);
    }

    /**
     * Procura uma conta pelo nome completo, ignorando diferença entre maiúsculas
     * e minúsculas. Se houver mais de uma conta com o mesmo nome, não escolhe
     * arbitrariamente uma delas: nesse caso, o usuário deve informar o e-mail.
     */
    private Usuario buscarPorNome(String nomeInformado) {
        String nomeNormalizado = normalizarTexto(nomeInformado);
        Usuario encontrado = null;

        String lista = preferencias.get(LISTA, "");
        if (lista.isBlank()) {
            return null;
        }

        for (String login : lista.split("\\|")) {
            if (login.isBlank()) {
                continue;
            }

            Usuario usuario = buscarPorLogin(login);
            if (usuario == null) {
                continue;
            }

            if (normalizarTexto(usuario.getNome()).equals(nomeNormalizado)) {
                if (encontrado != null) {
                    return null;
                }
                encontrado = usuario;
            }
        }

        return encontrado;
    }

    private void criarAdministradorPadrao() {
        final String adminLogin = "admin@mecha.com";

        if (buscarPorLogin(adminLogin) == null) {
            preferencias.put(PREFIXO + adminLogin + ".nome", "Administrador");
            preferencias.put(PREFIXO + adminLogin + ".hash", hash("admin123"));
            preferencias.put(PREFIXO + adminLogin + ".perfil", "ADMINISTRADOR");

            String lista = preferencias.get(LISTA, "");
            if (lista.isBlank()) {
                preferencias.put(LISTA, adminLogin);
            } else if (!lista.contains(adminLogin)) {
                preferencias.put(LISTA, lista + "|" + adminLogin);
            }
        }
    }

    private String limpar(String valor) {
        return valor == null ? "" : valor.trim();
    }

    private String normalizarTexto(String valor) {
        return limpar(valor).toLowerCase(java.util.Locale.ROOT).replaceAll("\\s+", " ");
    }

    private String hash(String senha) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(senha.getBytes(StandardCharsets.UTF_8));

            StringBuilder resultado = new StringBuilder();
            for (byte b : bytes) {
                resultado.append(String.format("%02x", b));
            }
            return resultado.toString();
        } catch (Exception e) {
            throw new IllegalStateException("Não foi possível proteger a senha.", e);
        }
    }
}
