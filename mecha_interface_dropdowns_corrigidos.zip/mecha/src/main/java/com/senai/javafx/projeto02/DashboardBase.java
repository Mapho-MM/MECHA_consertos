package com.senai.javafx.projeto02;

import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.fxml.FXML;

import java.util.List;
import java.util.function.Consumer;
import java.util.Map;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.SimpleStringProperty;

import static com.senai.javafx.projeto02.Dialogos.*;
import static com.senai.javafx.projeto02.Tema.*;
import com.senai.javafx.projeto02.Tema.Paleta;

/**
 * Parte comum dos dois painéis (administrador e funcionário): cabeçalho,
 * menu lateral que vira "tela" no layout compacto, perfil, pesquisa e configurações.
 */
public abstract class DashboardBase implements TelaController {

    protected final AppSingleton app = AppSingleton.getInstance();

    protected boolean menuAberto = false;

    /** Itens que a pesquisa deste painel oferece (nome -> ação). */
    protected abstract Map<String, Runnable> rotasDePesquisa();

    /** Reaplica a visibilidade do menu/área para o layout atual. */
    protected abstract void configurarMenu(boolean compacto);

    /** Área principal onde as seções são trocadas. */
    protected abstract VBox areaConteudo();

    @Override
    public void aoMudarLayout(boolean compacto) {
        configurarMenu(compacto);
    }

    /** Seção aberta no momento (Clientes, Estoque...). Refeita inteira quando o tema muda. */
    protected Runnable secaoAtual;
    private boolean refazendoPorTema = false;

    /**
     * Cada item do menu chama isto ao abrir sua seção. Assim, ao trocar entre claro e
     * escuro, a seção é reconstruída com as cores novas em vez de ficar metade de cada tema.
     */
    protected void lembrarSecao(Runnable abrir) {
        lembrarSecao(abrir, null);
    }

    /**
     * Marca a seção atual e, se informado, destaca o item correspondente no menu lateral.
     */
    protected void lembrarSecao(Runnable abrir, String nomeSecaoMenu) {
        // Guarda só a montagem do conteúdo (sem o handler do menu), para tema/recarregar
        // não empilhar outra camada nem trocar de módulo sem querer.
        secaoAtual = abrir;
        if (nomeSecaoMenu != null && !nomeSecaoMenu.isBlank()) {
            Tema.definirSecaoMenuSelecionada(nomeSecaoMenu);
            VBox menu = menuLateral();
            if (menu != null) Tema.estilizarItensMenuLateral(menu);
        }
        VBox area = areaConteudo();
        if (area == null) return;
        // O Tema não mexe no estilo antigo desta área: quem refaz o conteúdo é a própria seção.
        area.getProperties().put("mecha.semTema", Boolean.TRUE);
        instalarAnimacaoConteudo(area);
    }

    /**
     * Única forma segura de preencher a área central: limpa tudo e coloca o novo conteúdo.
     * Evita camada em cima de camada (add sem clear).
     */
    protected void definirConteudo(Node... nos) {
        VBox area = areaConteudo();
        if (area == null) return;
        area.getChildren().clear();
        if (nos != null) {
            for (Node n : nos) {
                if (n != null) area.getChildren().add(n);
            }
        }
    }

    /** Refaz a seção aberta (tema, após CRUD, etc.) sem saltar para outro módulo. */
    protected void recarregarSecaoAtual() {
        Runnable abrir = secaoAtual;
        if (abrir != null) {
            try {
                abrir.run();
            } catch (Exception e) {
                Tema.debugErro("Falha ao recarregar seção atual", e);
            }
        }
    }

    /** Menu lateral da tela (admin ou funcionário). Subclasses com menu devem sobrescrever. */
    protected VBox menuLateral() {
        return null;
    }

    private void instalarAnimacaoConteudo(VBox area) {
        if (area.getProperties().containsKey("mecha.animConteudo")) return;
        area.getProperties().put("mecha.animConteudo", Boolean.TRUE);
        area.getChildren().addListener((javafx.collections.ListChangeListener<Node>) mudanca -> {
            boolean entrou = false;
            while (mudanca.next()) {
                if (mudanca.wasAdded()) entrou = true;
            }
            if (entrou && !refazendoPorTema) {
                Animacoes.entrada(area, 12, 300);
                Animacoes.instalarMicro(area);
            } else if (entrou) {
                Animacoes.instalarMicro(area);
            }
        });
    }

    @Override
    public void aoMudarTema() {
        boolean compacto = Tema.layoutCompacto();
        boolean menuEstavaAberto = menuAberto;
        configurarMenu(compacto);

        // Refaz a seção aberta com a paleta nova (tabelas, cartões, gráficos, textos...).
        Runnable abrir = secaoAtual;
        if (abrir != null) {
            refazendoPorTema = true;
            try {
                abrir.run();
            } catch (Exception e) {
                Tema.debugErro("Falha ao refazer a seção ao trocar de tema", e);
            } finally {
                refazendoPorTema = false;
            }
            menuAberto = menuEstavaAberto;
            configurarMenu(compacto);
        }
    }

    @FXML
    public void abrirPerfilUsuario() {
        PerfilDialogo.abrir();
    }

    @FXML
    public void abrirPesquisa() {
        PesquisaDialogo.abrir(rotasDePesquisa());
    }

    @FXML
    public void abrirConfiguracoes() {
        ConfiguracoesDialogo.abrir();
    }

    @FXML
    public void voltarSelecao() {
        try {
            Navegador.voltarAoLogin();
        } catch (Exception e) {
            e.printStackTrace();
            mostrarMensagem("Login", "Não foi possível voltar ao login.");
        }
    }

    @FXML
    public void alternarMenu() {
        menuAberto = !menuAberto;
        configurarMenu(Tema.layoutCompacto());
    }

    protected void configurarMenu(VBox menu, VBox area, Button botao, Label rotuloPerfil,
                                Label rotuloUsuario, boolean compacto) {
        if (menu == null || area == null || botao == null) return;

        botao.setVisible(compacto);
        botao.setManaged(compacto);
        botao.setText(menuAberto ? "✕" : "☰");

        setVisivel(rotuloPerfil, !compacto);
        setVisivel(rotuloUsuario, !compacto);

        if (compacto) {
            setVisivel(menu, menuAberto);
            setVisivel(area, !menuAberto);
            menu.setPrefWidth(Region.USE_COMPUTED_SIZE);
            menu.setMaxWidth(Double.MAX_VALUE);
            HBox.setHgrow(menu, Priority.ALWAYS);
        } else {
            setVisivel(menu, true);
            setVisivel(area, true);
            menu.setPrefWidth(245);
            menu.setMaxWidth(Region.USE_COMPUTED_SIZE);
            HBox.setHgrow(menu, Priority.NEVER);
        }
    }

    protected static void setVisivel(Node no, boolean visivel) {
        if (no != null) {
            no.setVisible(visivel);
            no.setManaged(visivel);
        }
    }

    protected void estilizarLiquidGlass(VBox dashboard, VBox menu, Button... controles) {
        if (!temaLiquid()) return;

        estilizarNavegacaoLiquidGlass(dashboard, menu);
        for (Button controle : controles) {
            adicionarClasse(controle, "liquid-glass-control");
        }
    }

    // =========================================================
    // TELAS DE SEÇÃO (placeholder funcional)
    // =========================================================

    /**
     * Tela de seção com tabela de dados reais.
     * @param linhas cada mapa = uma linha (chave = nome da coluna)
     * @param cards valores dos 3 cards de resumo (rótulo, valor) — até 3
     * @param aoNovo ação do botão Novo (pode ser null)
     * @param aoAtualizar ação do botão Atualizar (pode ser null)
     */
    protected void abrirSecao(String titulo, String subtitulo, String[] colunas,
                              List<Map<String, String>> linhas, String textoVazio,
                              String[][] cards, Runnable aoNovo, Runnable aoAtualizar) {
        abrirSecaoComAcoes(titulo, subtitulo, colunas, linhas, textoVazio, cards,
                aoNovo, aoAtualizar, null, null);
    }

    /**
     * Seção com dados carregada via FXML dedicado (modulo-secao-view.fxml).
     */
    protected void abrirSecaoComAcoes(String titulo, String subtitulo, String[] colunas,
                                     List<Map<String, String>> linhas, String textoVazio,
                                     String[][] cards, Runnable aoNovo, Runnable aoAtualizar,
                                     java.util.function.Consumer<Map<String, String>> aoEditar,
                                     java.util.function.Consumer<Map<String, String>> aoExcluir) {
        VBox area = areaConteudo();
        if (area == null) return;
        try {
            ModuloSecaoController ctrl = ModulosFxml.carregar(area, "modulo-secao-view.fxml");
            ctrl.configurar(titulo, subtitulo, colunas, linhas, textoVazio, cards,
                    aoNovo, aoAtualizar, aoEditar, aoExcluir);
            if (Tema.layoutCompacto()) {
                menuAberto = false;
                configurarMenu(true);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            mostrarMensagem("Erro", "Não foi possível abrir a seção:\n" +
                    (ex.getMessage() != null ? ex.getMessage() : ex.getClass().getSimpleName()));
        }
    }

    /** Compatibilidade: seção sem dados (placeholder). */
    protected void abrirSecao(String titulo, String subtitulo, String[] colunas, String textoVazio) {
        abrirSecao(titulo, subtitulo, colunas, List.of(), textoVazio,
                new String[][]{{"Total", "0"}, {"Ativos", "0"}, {"Pendentes", "0"}},
                null, null);
    }

    protected static Button botaoSecao(String texto) {
        Paleta p = paletaAtual();
        Button b = new Button(texto);
        b.setPrefHeight(40);
        b.setStyle(
                "-fx-background-color: " + p.overlay() + "0.10);" +
                "-fx-background-radius: 18;" +
                "-fx-text-fill: " + p.texto() + ";" +
                "-fx-font-size: 13px;" +
                "-fx-cursor: hand;" +
                "-fx-padding: 8 16;" +
                "-fx-border-color: " + p.borda() + ";" +
                "-fx-border-radius: 18;" +
                "-fx-border-width: 1;"
        );
        // Cores semânticas fixas (independentes do tema)
        Tema.aplicarEstiloSemantico(b);
        return b;
    }

    protected static VBox cardResumo(String rotulo, String valor) {
        return Visual.cardComIcone(rotulo, valor, 24);
    }
}
