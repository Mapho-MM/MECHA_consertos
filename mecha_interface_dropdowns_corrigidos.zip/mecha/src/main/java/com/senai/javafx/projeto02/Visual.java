package com.senai.javafx.projeto02;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

import java.text.Normalizer;

/**
 * Ajustes visuais compartilhados: superfícies quase opacas (menos fadiga visual e
 * texto mais legível sobre a imagem de fundo), ícones por assunto e o card com ícone.
 */
public final class Visual {

    private Visual() {}

    private static boolean claro() {
        return Tema.temaEfetivo() == 1;
    }

    // =========================================================================
    // SUPERFÍCIES (quase opacas)
    // =========================================================================

    /** Fundo dos cards de indicador e dos cartões de atalho. */
    public static String fundoCard() {
        return claro() ? "rgba(255,255,255,0.96)" : "rgba(24,28,42,0.95)";
    }

    /** Fundo dos painéis maiores que agrupam tabelas, filtros e gráficos. */
    public static String fundoPainel() {
        return claro() ? "rgba(246,247,250,0.97)" : "rgba(17,20,32,0.94)";
    }

    /** Fundo sólido das tabelas. */
    public static String fundoTabela() {
        return claro() ? "#f3f4f7" : "#12151f";
    }

    /** Borda dos cards e painéis (um pouco mais visível que a anterior). */
    public static String bordaCard() {
        return claro() ? "rgba(40,44,52,0.18)" : "rgba(255,255,255,0.16)";
    }

    /** Estilo inline de tabela com fundo sólido (substitui os fundos translúcidos). */
    public static String estiloTabela(int raio) {
        String bg = fundoTabela();
        return "-fx-background-color: " + bg + ";" +
               "-fx-control-inner-background: " + bg + ";" +
               "-fx-background-radius: " + raio + ";" +
               "-fx-border-color: " + bordaCard() + ";" +
               "-fx-border-radius: " + raio + "; -fx-border-width: 1;";
    }

    public static void estilizarTabela(TableView<?> tabela, int raio) {
        if (tabela != null) tabela.setStyle(estiloTabela(raio));
    }

    /** Estilo de um painel que agrupa conteúdo (padding incluído). */
    public static String estiloPainel(int raio, int padding) {
        return "-fx-background-color: " + fundoPainel() + ";" +
               "-fx-background-radius: " + raio + ";" +
               "-fx-border-color: " + bordaCard() + ";" +
               "-fx-border-radius: " + raio + "; -fx-border-width: 1;" +
               "-fx-padding: " + padding + ";" +
               "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.22), 14, 0.12, 0, 3);";
    }

    // =========================================================================
    // ÍCONES (mesmos do menu lateral, quando existe equivalente)
    // =========================================================================

    private static String semAcento(String s) {
        String n = Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD);
        return n.replaceAll("\\p{M}+", "").toLowerCase();
    }

    /** Ícone adequado ao rótulo do card. A ordem dos testes importa (mais específico primeiro). */
    public static String icone(String rotulo) {
        String r = semAcento(rotulo);
        if (r.contains("lucro")) return "📈";
        if (r.contains("ganho")) return "💵";
        if (r.contains("despesa")) return "🧾";
        if (r.contains("gasto")) return "💸";
        if (r.contains("salario")) return "💼";
        if (r.contains("mao de obra")) return "🔧";
        if (r.contains("estoque baixo")) return "📉";
        if (r.contains("valor")) return "💰";
        if (r.contains("financeiro")) return "💰";
        if (r.contains("peca") || r.contains("unidade")) return "🔩";
        if (r.contains("estoque") || r.contains("produto")) return "📦";
        if (r.contains("cliente")) return "👤";
        if (r.contains("veiculo")) return "🚗";
        if (r.contains("mecanico")) return "👥";
        if (r.contains("catalogo")) return "🔧";
        if (r.contains("orcamento")) return "📝";
        if (r.contains("agendado") || r.contains("aprovado")) return "📅";
        if (r.contains("andamento")) return "⏳";
        if (r.contains("finalizado") || r.contains("concluido")) return "✅";
        if (r.contains("tarefa") || r.contains("ordem")) return "📋";
        if (r.contains("relatorio")) return "📊";
        if (r.contains("suporte")) return "💬";
        return "📌";
    }

    private static String corDestaque(String icone) {
        return switch (icone) {
            case "✅", "📈", "💵" -> "rgba(34,197,94,0.22)";   // verde
            case "📉", "💸", "🧾" -> "rgba(245,158,11,0.22)";  // âmbar
            default -> "rgba(59,130,246,0.22)";                // azul
        };
    }

    // =========================================================================
    // CARD COM ÍCONE
    // =========================================================================

    /** Selo arredondado com o ícone (usado nos cards). */
    public static StackPane seloIcone(String icone, int lado) {
        Label ic = new Label(icone);
        ic.setStyle("-fx-font-size: " + Math.round(lado * 0.5) + "px; -fx-text-fill: " + Tema.paletaAtual().texto() + ";");
        StackPane selo = new StackPane(ic);
        selo.setMinSize(lado, lado);
        selo.setPrefSize(lado, lado);
        selo.setMaxSize(lado, lado);
        selo.setStyle("-fx-background-color: " + corDestaque(icone) + ";" +
                      "-fx-background-radius: " + (lado / 3) + ";");
        return selo;
    }

    /**
     * Card de indicador: selo com ícone à esquerda, rótulo e valor à direita.
     * Cresce na horizontal para ocupar o espaço disponível da fileira.
     */
    public static VBox cardComIcone(String rotulo, String valor, int tamanhoValor) {
        Tema.Paleta p = Tema.paletaAtual();
        String ic = icone(rotulo);

        Label lbRotulo = new Label(rotulo);
        lbRotulo.setWrapText(true);
        lbRotulo.setStyle("-fx-text-fill: " + p.textoSec() + "; -fx-font-size: 12px;");
        Label lbValor = new Label(valor);
        lbValor.setStyle("-fx-text-fill: " + p.texto() + "; -fx-font-size: " + tamanhoValor + "px; -fx-font-weight: bold;");

        VBox textos = new VBox(2, lbRotulo, lbValor);
        textos.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(textos, Priority.ALWAYS);

        HBox linha = new HBox(14, seloIcone(ic, 48), textos);
        linha.setAlignment(Pos.CENTER_LEFT);

        VBox card = new VBox(linha);
        card.setAlignment(Pos.CENTER_LEFT);
        card.setPadding(new Insets(16, 20, 16, 18));
        card.setMinWidth(190);
        card.setMinHeight(84);
        card.setMaxWidth(Double.MAX_VALUE);
        card.setStyle(
                "-fx-background-color: " + fundoCard() + ";" +
                "-fx-background-radius: 18;" +
                "-fx-border-color: " + bordaCard() + ";" +
                "-fx-border-radius: 18; -fx-border-width: 1;" +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.20), 12, 0.10, 0, 3);"
        );
        HBox.setHgrow(card, Priority.ALWAYS);
        return card;
    }

    /** Título de seção com ícone, ex.: "📦  Estoque". */
    public static Label tituloComIcone(String icone, String texto, int tamanhoFonte) {
        Label l = new Label(icone + "  " + texto);
        l.setStyle("-fx-text-fill: " + Tema.paletaAtual().texto() + "; -fx-font-size: " + tamanhoFonte + "px; -fx-font-weight: bold;");
        return l;
    }
}
