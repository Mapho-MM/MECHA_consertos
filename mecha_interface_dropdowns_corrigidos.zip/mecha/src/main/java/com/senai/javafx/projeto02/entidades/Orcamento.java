package com.senai.javafx.projeto02.entidades;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Orçamento completo: cliente + veículo + serviços + peças.
 * Após aprovação do cliente, gera a Nota de Serviço e a OS (status AGENDADO).
 */
public class Orcamento {

    public static final double TAXA_FIXA_MAO_DE_OBRA = 150.00;
    private static final AtomicInteger SEQ = new AtomicInteger(1);
    private static final DateTimeFormatter BR = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final int numero;
    private LocalDate dataCriacao = LocalDate.now();
    private LocalDate dataValidade = LocalDate.now().plusDays(7);
    private Status status = Status.ORCAMENTO;

    private Cliente cliente;
    private Veiculo veiculo;
    private String mecanicoSugerido;
    private String defeitoRelatado;
    private String diagnostico;
    private String observacoes;
    private double desconto;

    private final List<ItemOrcamento> servicos = new ArrayList<>();
    private final List<ItemOrcamento> pecas = new ArrayList<>();

    public Orcamento() {
        this.numero = SEQ.getAndIncrement();
    }

    public Orcamento(int numero) {
        this.numero = numero;
        if (numero >= SEQ.get()) SEQ.set(numero + 1);
    }

    public int getNumero() { return numero; }
    public String getNumeroFormatado() { return String.format("%04d", numero); }
    public LocalDate getDataCriacao() { return dataCriacao; }
    public LocalDate getDataValidade() { return dataValidade; }
    public String getDataCriacaoBr() { return dataCriacao != null ? dataCriacao.format(BR) : ""; }
    public String getDataValidadeBr() { return dataValidade != null ? dataValidade.format(BR) : ""; }
    public Status getStatus() { return status; }
    public Cliente getCliente() { return cliente; }
    public Veiculo getVeiculo() { return veiculo; }
    public String getMecanicoSugerido() { return mecanicoSugerido; }
    public String getDefeitoRelatado() { return defeitoRelatado; }
    public String getDiagnostico() { return diagnostico; }
    public String getObservacoes() { return observacoes; }
    public double getDesconto() { return desconto; }
    public List<ItemOrcamento> getServicos() { return servicos; }
    public List<ItemOrcamento> getPecas() { return pecas; }

    public void setDataCriacao(LocalDate d) { this.dataCriacao = d; }
    public void setDataValidade(LocalDate d) { this.dataValidade = d; }
    public void setStatus(Status status) { this.status = status; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }
    public void setVeiculo(Veiculo veiculo) { this.veiculo = veiculo; }
    public void setMecanicoSugerido(String mecanicoSugerido) { this.mecanicoSugerido = mecanicoSugerido; }
    public void setDefeitoRelatado(String defeitoRelatado) { this.defeitoRelatado = defeitoRelatado; }
    public void setDiagnostico(String diagnostico) { this.diagnostico = diagnostico; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }
    public void setDesconto(double desconto) { this.desconto = Math.max(0, desconto); }

    public double totalServicos() {
        return servicos.stream().mapToDouble(ItemOrcamento::subtotal).sum();
    }

    public double totalPecas() {
        return pecas.stream().mapToDouble(ItemOrcamento::subtotal).sum();
    }

    public double totalGeral() {
        return Math.max(0, totalServicos() + totalPecas() - desconto);
    }

    /** Cliente aprovou: muda status e prepara para virar OS. */
    public boolean aprovar() {
        if (status != Status.ORCAMENTO) return false;
        status = Status.AGENDADO;
        return true;
    }

    public static class ItemOrcamento {
        private String codigo;
        private String descricao;
        private double qtd;
        private double valorUnitario;

        public ItemOrcamento(String descricao, double qtd, double valorUnitario) {
            this.descricao = descricao;
            this.qtd = qtd <= 0 ? 1 : qtd;
            this.valorUnitario = valorUnitario;
        }

        public ItemOrcamento(String codigo, String descricao, double qtd, double valorUnitario) {
            this(descricao, qtd, valorUnitario);
            this.codigo = codigo;
        }

        public String getCodigo() { return codigo; }
        public String getDescricao() { return descricao; }
        public double getQtd() { return qtd; }
        public double getValorUnitario() { return valorUnitario; }
        public double subtotal() { return qtd * valorUnitario; }

        public void setCodigo(String codigo) { this.codigo = codigo; }
        public void setDescricao(String descricao) { this.descricao = descricao; }
        public void setQtd(double qtd) { this.qtd = qtd; }
        public void setValorUnitario(double valorUnitario) { this.valorUnitario = valorUnitario; }
    }
}
