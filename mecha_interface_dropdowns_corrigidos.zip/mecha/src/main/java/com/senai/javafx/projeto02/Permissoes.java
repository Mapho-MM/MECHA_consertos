package com.senai.javafx.projeto02;

/**
 * Controle de permissões na camada de aplicação.
 * A UI esconde botões, mas as operações sensíveis também verificam aqui.
 */
public final class Permissoes {

    private Permissoes() {
    }

    public static boolean isAdmin() {
        Usuario u = AppSingleton.getInstance().getUsuarioAtual();
        return u != null && "ADMINISTRADOR".equalsIgnoreCase(u.getPerfil());
    }

    public static boolean isFuncionario() {
        Usuario u = AppSingleton.getInstance().getUsuarioAtual();
        return u != null && "FUNCIONARIO".equalsIgnoreCase(u.getPerfil());
    }

    /** Cadastros, preços, estoque movimentação, mecânicos, exclusões. */
    public static void exigirAdmin(String operacao) {
        if (!isAdmin()) {
            throw new SecurityException("Operação restrita a administradores: " + operacao);
        }
    }

    public static boolean podeGerenciarCadastros() {
        return isAdmin();
    }

    public static boolean podeMovimentarEstoque() {
        return isAdmin();
    }

    public static boolean podeVerSalarios() {
        return isAdmin();
    }

    public static boolean podeIniciarFinalizarOs() {
        // admin e funcionário autenticado
        Usuario u = AppSingleton.getInstance().getUsuarioAtual();
        return u != null;
    }
}
