package com.senai.javafx.projeto02;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.TextAlignment;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.util.Duration;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static com.senai.javafx.projeto02.Tema.*;

/**
 * Chat suporte sincronizado + emojis coloridos (Twemoji PNG).
 */
public class ModuloSuporteController {

    @FXML private VBox painelConversas, painelChat, hostEmojis, caixaMensagens;
    @FXML private ListView<String> listaConversas;
    @FXML private Label tituloChat, subtituloChat, labelConversas;
    @FXML private ScrollPane scrollMensagens;
    @FXML private StackPane fundoMensagens;
    @FXML private TextField campoMensagem;
    @FXML private Button btnEmoji, btnEnviar, btnAtualizarLista;
    @FXML private HBox barraEnvio;

    private boolean admin;
    private String loginAtual;
    private String conversaAtiva;
    private final UsuarioService usuarioService = new UsuarioService();
    private boolean emojisVisiveis = false;
    private Timeline sincronizador;
    private int ultimoHashConversa = -1;
    private String categoriaAtual;
    private boolean atualizandoLista;

    private static final Map<String, Image> IMG_CACHE = new ConcurrentHashMap<>();

    @FXML
    private void initialize() {
        Usuario u = AppSingleton.getInstance().getUsuarioAtual();
        loginAtual = u != null ? u.getLogin() : "";
        admin = u != null && "ADMINISTRADOR".equalsIgnoreCase(u.getPerfil());

        if (painelConversas != null) {
            painelConversas.setVisible(admin);
            painelConversas.setManaged(admin);
        }

        configurarListaConversas();
        aplicarChrome();
        // Painel de emojis removido da interface

        if (admin) {
            tituloChat.setText("Suporte");
            subtituloChat.setText("Sincronizado com o funcionário · selecione uma conversa");
            onAtualizarConversas();
            listaConversas.getSelectionModel().selectedItemProperty().addListener((o, a, n) -> {
                if (atualizandoLista) return;
                if (n != null) {
                    conversaAtiva = extrairLogin(n);
                    ultimoHashConversa = -1;
                    atualizarCabecalhoChat();
                    carregarMensagens(true);
                }
            });
        } else {
            conversaAtiva = loginAtual;
            tituloChat.setText("Suporte");
            subtituloChat.setText("Conversa sincronizada com o administrador");
            carregarMensagens(true);
        }

        iniciarSincronizacao();
    }

    private void configurarListaConversas() {
        if (listaConversas == null) return;
        listaConversas.setCellFactory(lv -> new ListCell<>() {
            private final VBox box = new VBox(2);
            private final Label nome = new Label();
            private final Label login = new Label();
            {
                nome.setStyle("-fx-font-size: 13px; -fx-font-weight: bold;");
                login.setStyle("-fx-font-size: 11px;");
                box.setPadding(new Insets(8, 10, 8, 10));
                box.getChildren().addAll(nome, login);
                setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            }
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setGraphic(null);
                    setText(null);
                    setStyle("-fx-background-color: transparent;");
                    return;
                }
                String lg = extrairLogin(item);
                String nm = extrairNome(item);
                nome.setText(nm);
                login.setText(lg);
                Paleta p = paletaAtual();
                boolean sel = isSelected();
                int te = temaEfetivo();
                String corNome = sel ? p.botaoTexto() : p.texto();
                String corLogin = sel ? p.botaoTexto() : p.textoSec();
                nome.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: " + corNome + ";");
                login.setStyle("-fx-font-size: 11px; -fx-text-fill: " + corLogin + "; -fx-opacity: 0.85;");
                String fundo = sel
                        ? p.botaoFundo()
                        : (te != 1 ? "rgba(255,255,255,0.06)" : "rgba(15,20,30,0.04)");
                box.setStyle(
                        "-fx-background-color: " + fundo + ";" +
                        "-fx-background-radius: 12;"
                );
                setGraphic(box);
                setText(null);
                setStyle("-fx-background-color: transparent; -fx-padding: 2 4;");
            }
        });
    }

    private void atualizarCabecalhoChat() {
        if (!admin || conversaAtiva == null || conversaAtiva.isBlank()) {
            if (admin) {
                tituloChat.setText("Suporte");
                subtituloChat.setText("Selecione uma conversa");
                subtituloChat.setStyle("-fx-text-fill: " + paletaAtual().textoSec() + "; -fx-font-size: 12px;");
            }
            return;
        }
        Usuario u = usuarioService.buscarPorLogin(conversaAtiva);
        String nm = u != null ? u.getNome() : conversaAtiva;
        tituloChat.setText(nm);
        subtituloChat.setText("Online");
        subtituloChat.setStyle("-fx-text-fill: #34d399; -fx-font-size: 12px; -fx-font-weight: bold;");
    }

    private void aplicarChrome() {
        Paleta p = paletaAtual();
        // Sempre tema escuro / glass, alinhado ao restante do sistema

        if (tituloChat != null)
            tituloChat.setStyle("-fx-text-fill: " + p.texto() + "; -fx-font-size: 20px; -fx-font-weight: bold;");
        if (subtituloChat != null)
            subtituloChat.setStyle("-fx-text-fill: " + p.textoSec() + "; -fx-font-size: 12px;");
        if (labelConversas != null)
            labelConversas.setStyle("-fx-text-fill: " + p.texto() + "; -fx-font-size: 15px; -fx-font-weight: bold;");

        if (fundoMensagens != null) {
            fundoMensagens.setStyle(
                    "-fx-background-color: rgba(12,16,28,0.72);" +
                    "-fx-background-radius: 18;" +
                    "-fx-border-color: rgba(255,255,255,0.10);" +
                    "-fx-border-radius: 18;" +
                    "-fx-border-width: 1;"
            );
        }
        if (scrollMensagens != null) {
            scrollMensagens.setStyle(
                    "-fx-background-color: transparent; -fx-background: transparent; -fx-padding: 0;"
            );
            Platform.runLater(() -> {
                var viewport = scrollMensagens.lookup(".viewport");
                if (viewport != null) {
                    viewport.setStyle("-fx-background-color: transparent;");
                }
            });
        }
        if (painelConversas != null) {
            painelConversas.setStyle(
                    "-fx-background-color: rgba(255,255,255,0.06);" +
                    "-fx-background-radius: 18;" +
                    "-fx-border-color: rgba(255,255,255,0.10);" +
                    "-fx-border-radius: 18;" +
                    "-fx-border-width: 1;" +
                    "-fx-padding: 12;"
            );
        }
        if (listaConversas != null) {
            listaConversas.setStyle(
                    "-fx-background-color: transparent;" +
                    "-fx-control-inner-background: transparent;" +
                    "-fx-background-insets: 0;" +
                    "-fx-padding: 2;"
            );
            Platform.runLater(() -> {
                var viewport = listaConversas.lookup(".virtual-flow .clipped-container .sheet");
                if (viewport != null) viewport.setStyle("-fx-background-color: transparent;");
                var listViewport = listaConversas.lookup(".viewport");
                if (listViewport != null) listViewport.setStyle("-fx-background-color: transparent;");
            });
        }
        if (campoMensagem != null) {
            campoMensagem.setStyle(
                    "-fx-background-color: rgba(255,255,255,0.08);" +
                    "-fx-text-fill: " + p.texto() + ";" +
                    "-fx-prompt-text-fill: " + p.textoTerc() + ";" +
                    "-fx-background-radius: 22;" +
                    "-fx-border-color: rgba(255,255,255,0.12);" +
                    "-fx-border-radius: 22;" +
                    "-fx-padding: 10 16;" +
                    "-fx-font-size: 14px;"
            );
        }
        if (btnEnviar != null) {
            btnEnviar.setText("➤");
            btnEnviar.setStyle(
                    "-fx-background-color: " + LayoutPadrao.COR_PRIMARIO + ";" +
                    "-fx-text-fill: white;" +
                    "-fx-background-radius: 22;" +
                    "-fx-font-weight: bold;" +
                    "-fx-font-size: 16px;" +
                    "-fx-cursor: hand;" +
                    "-fx-min-width: 44;"
            );
        }
        if (btnEmoji != null) {
            btnEmoji.setStyle(
                    "-fx-background-color: rgba(255,255,255,0.08);" +
                    "-fx-background-radius: 22;" +
                    "-fx-border-color: transparent;" +
                    "-fx-cursor: hand;" +
                    "-fx-font-size: 20px; -fx-font-family: 'Segoe UI Emoji', 'Noto Color Emoji', sans-serif;"
            );
        }
        if (btnAtualizarLista != null) {
            btnAtualizarLista.setStyle(
                    "-fx-background-color: " + LayoutPadrao.COR_PRIMARIO + ";" +
                    "-fx-text-fill: #ffffff;" +
                    "-fx-background-radius: 12;" +
                    "-fx-cursor: hand;"
            );
        }
        if (barraEnvio != null) {
            barraEnvio.setStyle(
                    "-fx-background-color: rgba(255,255,255,0.05);" +
                    "-fx-background-radius: 24;" +
                    "-fx-border-color: rgba(255,255,255,0.08);" +
                    "-fx-border-radius: 24;" +
                    "-fx-padding: 8 10;"
            );
        }
    }

    private void montarPainelEmojis() {
        if (hostEmojis == null) return;
        hostEmojis.getChildren().clear();
        Paleta p = paletaAtual();

        // Catálogo local síncrono → emojis na hora
        Map<String, List<EmojiCatalogo.EmojiItem>> mapa = EmojiCatalogo.obterPorCategoria();
        List<String> ordem = EmojiCatalogo.ordemCategorias();
        int total = mapa.values().stream().mapToInt(List::size).sum();

        Label status = new Label(total + " emojis prontos");
        status.setStyle("-fx-text-fill: " + p.textoSec() + "; -fx-font-size: 11px;");

        ScrollPane catsScroll = new ScrollPane();
        catsScroll.setFitToHeight(true);
        catsScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        catsScroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        catsScroll.setPrefHeight(40);
        catsScroll.setStyle("-fx-background-color: transparent; -fx-background: transparent;");
        HBox cats = new HBox(6);
        cats.setAlignment(Pos.CENTER_LEFT);
        catsScroll.setContent(cats);

        ScrollPane gridScroll = new ScrollPane();
        gridScroll.setFitToWidth(true);
        gridScroll.setPrefHeight(132);
        gridScroll.setMaxHeight(150);
        gridScroll.setStyle(
                "-fx-background-color: transparent; -fx-background: transparent;" +
                "-fx-border-color: " + p.borda() + ";" +
                "-fx-border-radius: 14; -fx-background-radius: 14;"
        );
        FlowPane grid = new FlowPane(4, 4);
        grid.setPadding(new Insets(8));
        gridScroll.setContent(grid);

        hostEmojis.setStyle(
                "-fx-background-color: " + p.overlay() + "0.08);" +
                "-fx-background-radius: 16;" +
                "-fx-padding: 8;"
        );
        hostEmojis.getChildren().addAll(status, catsScroll, gridScroll);

        ToggleGroup grupo = new ToggleGroup();
        for (String cat : ordem) {
            if (!mapa.containsKey(cat) || mapa.get(cat).isEmpty()) continue;
            ToggleButton tb = new ToggleButton(rotuloCurto(cat));
            tb.setToggleGroup(grupo);
            tb.setStyle(
                    "-fx-background-radius: 12; -fx-cursor: hand; -fx-font-size: 14px; -fx-padding: 6 10;" +
                    "-fx-background-color: " + p.overlay() + "0.12);" +
                    "-fx-text-fill: " + p.texto() + ";"
            );
            tb.setOnAction(e -> {
                categoriaAtual = cat;
                preencherGridColorido(grid, mapa.get(cat));
            });
            cats.getChildren().add(tb);
            if (categoriaAtual == null) {
                tb.setSelected(true);
                categoriaAtual = cat;
                preencherGridColorido(grid, mapa.get(cat));
            }
        }
    }
    private void preencherGridColorido(FlowPane grid, List<EmojiCatalogo.EmojiItem> itens) {
        grid.getChildren().clear();
        if (itens == null) return;
        // Só Unicode local — sem baixar PNG (evita travar a UI)
        int max = Math.min(itens.size(), 120);
        for (int i = 0; i < max; i++) {
            EmojiCatalogo.EmojiItem it = itens.get(i);
            Button b = new Button(it.caractere());
            b.setTooltip(new Tooltip(it.nome() != null ? it.nome() : it.caractere()));
            b.setStyle(
                    "-fx-background-color: transparent; -fx-cursor: hand; -fx-padding: 4;" +
                    "-fx-font-size: 20px; -fx-background-radius: 8;"
            );
            b.setOnAction(e -> inserirEmoji(it.caractere()));
            grid.getChildren().add(b);
        }
    }

    private javafx.scene.Node criarIconeColorido(EmojiCatalogo.EmojiItem it, double size) {
        String hex = it.codigoHex();
        if (hex == null || hex.isBlank()) {
            Label lb = new Label(it.caractere());
            lb.setStyle("-fx-font-size: " + size + "px;");
            return lb;
        }
        Image img = IMG_CACHE.computeIfAbsent(hex, h -> {
            try {
                // background loading — não trava a UI
                return new Image(it.urlTwemoji(), size * 2, size * 2, true, true, true);
            } catch (Exception e) {
                return null;
            }
        });
        if (img == null) {
            Label lb = new Label(it.caractere());
            lb.setStyle("-fx-font-size: " + size + "px;");
            return lb;
        }
        ImageView iv = new ImageView();
        iv.setFitWidth(size);
        iv.setFitHeight(size);
        iv.setPreserveRatio(true);
        iv.setSmooth(true);
        if (img.isError()) {
            Label lb = new Label(it.caractere());
            lb.setStyle("-fx-font-size: " + size + "px;");
            return lb;
        }
        // Se ainda carregando, mostra o Unicode e troca quando o PNG chegar
        if (img.getProgress() < 1.0) {
            Label lb = new Label(it.caractere());
            lb.setStyle("-fx-font-size: " + size + "px;");
            StackPane stack = new StackPane(lb, iv);
            img.progressProperty().addListener((o, a, prog) -> {
                if (prog != null && prog.doubleValue() >= 1.0 && !img.isError()) {
                    Platform.runLater(() -> {
                        iv.setImage(img);
                        lb.setVisible(false);
                    });
                }
            });
            // também escuta error
            img.errorProperty().addListener((o, a, err) -> {
                if (Boolean.TRUE.equals(err)) Platform.runLater(() -> iv.setImage(null));
            });
            return stack;
        }
        iv.setImage(img);
        return iv;
    }

    private String rotuloCurto(String cat) {
        if (cat == null) return "•";
        if (cat.startsWith("Smileys")) return "😀";
        if (cat.startsWith("People")) return "👋";
        if (cat.startsWith("Animals")) return "🐱";
        if (cat.startsWith("Food")) return "🍔";
        if (cat.startsWith("Travel")) return "🚗";
        if (cat.startsWith("Activities")) return "⚽";
        if (cat.startsWith("Objects")) return "🔧";
        if (cat.startsWith("Symbols")) return "💯";
        if (cat.startsWith("Flags")) return "🏳️";
        return cat.length() > 8 ? cat.substring(0, 8) : cat;
    }

    private void inserirEmoji(String emoji) {
        if (campoMensagem == null || emoji == null) return;
        int pos = campoMensagem.getCaretPosition();
        String t = campoMensagem.getText() == null ? "" : campoMensagem.getText();
        if (pos < 0 || pos > t.length()) pos = t.length();
        campoMensagem.setText(t.substring(0, pos) + emoji + t.substring(pos));
        campoMensagem.positionCaret(pos + emoji.length());
        campoMensagem.requestFocus();
    }

    private void iniciarSincronizacao() {
        pararSincronizacao();
        sincronizador = new Timeline(new KeyFrame(Duration.seconds(3.0), e -> {
            if (admin) {
                onAtualizarConversas();
            }
            carregarMensagens(false);
        }));
        sincronizador.setCycleCount(Timeline.INDEFINITE);
        sincronizador.play();
        if (tituloChat != null) {
            tituloChat.sceneProperty().addListener((obs, o, n) -> {
                if (n == null) pararSincronizacao();
                else if (sincronizador != null) sincronizador.play();
            });
        }
    }

    private void pararSincronizacao() {
        if (sincronizador != null) {
            sincronizador.stop();
            sincronizador = null;
        }
    }

    @FXML
    private void onToggleEmojis() {
        emojisVisiveis = !emojisVisiveis;
        if (hostEmojis != null) {
            hostEmojis.setVisible(emojisVisiveis);
            hostEmojis.setManaged(emojisVisiveis);
        }
    }

    @FXML
    public void onAtualizarConversas() {
        if (!admin || listaConversas == null) return;
        String loginSelecionado = conversaAtiva;
        if (loginSelecionado == null || loginSelecionado.isBlank()) {
            String sel = listaConversas.getSelectionModel().getSelectedItem();
            if (sel != null) loginSelecionado = extrairLogin(sel);
        }

        atualizandoLista = true;
        try {
            listaConversas.getItems().clear();
            for (String login : ChatService.loginsComConversa()) {
                Usuario u = usuarioService.buscarPorLogin(login);
                String label = (u != null ? u.getNome() : login) + "  (" + login + ")";
                listaConversas.getItems().add(label);
            }
            for (Usuario u : usuarioService.listarTodos()) {
                if ("ADMINISTRADOR".equalsIgnoreCase(u.getPerfil())) continue;
                String label = u.getNome() + "  (" + u.getLogin() + ")";
                if (!listaConversas.getItems().contains(label)) {
                    listaConversas.getItems().add(label);
                }
            }

            if (loginSelecionado != null && !loginSelecionado.isBlank()) {
                for (String item : listaConversas.getItems()) {
                    if (loginSelecionado.equalsIgnoreCase(extrairLogin(item))) {
                        listaConversas.getSelectionModel().select(item);
                        break;
                    }
                }
            }
        } finally {
            atualizandoLista = false;
        }
    }

    private String extrairLogin(String item) {
        if (item == null) return "";
        int a = item.lastIndexOf('(');
        int b = item.lastIndexOf(')');
        if (a >= 0 && b > a) return item.substring(a + 1, b).trim();
        return item.trim();
    }

    private String extrairNome(String item) {
        if (item == null) return "";
        int a = item.lastIndexOf('(');
        if (a > 0) return item.substring(0, a).trim();
        return item.trim();
    }

    private void carregarMensagens(boolean forcar) {
        String alvo = admin ? conversaAtiva : loginAtual;
        if (alvo == null || alvo.isBlank()) {
            if (forcar) {
                caixaMensagens.getChildren().clear();
                Label vazio = new Label(admin
                        ? "Selecione uma conversa à esquerda para começar."
                        : "Nenhuma mensagem ainda.");
                vazio.setWrapText(true);
                vazio.setMaxWidth(Double.MAX_VALUE);
                vazio.setAlignment(Pos.CENTER);
                vazio.setStyle("-fx-text-fill: " + paletaAtual().textoSec()
                        + "; -fx-font-size: 13px; -fx-padding: 28 12;");
                caixaMensagens.setAlignment(Pos.CENTER);
                caixaMensagens.getChildren().add(vazio);
            }
            return;
        }
        List<ChatService.Mensagem> msgs = ChatService.conversaComUsuario(alvo);
        int hash = msgs.stream().mapToInt(m -> (m.id() + m.texto() + m.instante()).hashCode()).sum();
        if (!forcar && hash == ultimoHashConversa) return;
        ultimoHashConversa = hash;

        double scrollAntes = scrollMensagens != null ? scrollMensagens.getVvalue() : 1.0;
        boolean noFim = scrollAntes > 0.85;

        caixaMensagens.getChildren().clear();
        caixaMensagens.setAlignment(Pos.TOP_LEFT);
        if (msgs.isEmpty()) {
            Label vazio = new Label("Nenhuma mensagem ainda.\nEnvie a primeira! 👋");
            vazio.setWrapText(true);
            vazio.setAlignment(Pos.CENTER);
            vazio.setMaxWidth(Double.MAX_VALUE);
            vazio.setStyle("-fx-text-fill: " + paletaAtual().textoSec()
                    + "; -fx-font-size: 13px; -fx-padding: 28 12; -fx-text-alignment: center;");
            caixaMensagens.setAlignment(Pos.CENTER);
            caixaMensagens.getChildren().add(vazio);
        } else {
            for (ChatService.Mensagem m : msgs) {
                caixaMensagens.getChildren().add(bolha(m));
            }
        }
        if (noFim || forcar) {
            Platform.runLater(() -> {
                if (scrollMensagens != null) {
                    scrollMensagens.layout();
                    scrollMensagens.setVvalue(1.0);
                }
            });
        }
    }

    private HBox bolha(ChatService.Mensagem m) {
        boolean minha = m.de().equalsIgnoreCase(loginAtual)
                || (admin && (m.de().equals(ChatService.SUPORTE) || m.de().equals("admin@mecha.com")));
        // Estilo glass do sistema (não WhatsApp)
        String fundoBolha = minha ? "rgba(59,130,246,0.35)" : "rgba(255,255,255,0.10)";
        String corTxt = "#f3f4f6";
        String corHora = "#9ca3af";

        Label corpo = new Label(m.texto() == null ? "" : m.texto());
        corpo.setWrapText(true);
        corpo.setMaxWidth(360);
        corpo.setStyle("-fx-text-fill: " + corTxt + "; -fx-font-size: 14px;");

        Label hora = new Label(m.horaFormatada());
        hora.setStyle("-fx-text-fill: " + corHora + "; -fx-font-size: 10px;");
        HBox rodape = new HBox(hora);
        rodape.setAlignment(Pos.CENTER_RIGHT);

        VBox bolhaBox = new VBox(4, corpo, rodape);
        bolhaBox.setPadding(new Insets(8, 12, 6, 12));
        bolhaBox.setMaxWidth(380);
        bolhaBox.setStyle(
                "-fx-background-color: " + fundoBolha + ";" +
                "-fx-background-radius: " + (minha ? "14 4 14 14" : "4 14 14 14") + ";" +
                "-fx-border-color: rgba(255,255,255,0.08);" +
                "-fx-border-radius: " + (minha ? "14 4 14 14" : "4 14 14 14") + ";" +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.25), 8, 0, 0, 2);"
        );

        HBox linha = new HBox(bolhaBox);
        linha.setAlignment(minha ? Pos.CENTER_RIGHT : Pos.CENTER_LEFT);
        linha.setPadding(new Insets(3, 10, 3, 10));
        return linha;
    }

    private TextFlow criarConteudoMensagem(String mensagem, String corTexto) {
        TextFlow flow = new TextFlow();
        flow.setTextAlignment(TextAlignment.LEFT);
        flow.setStyle("-fx-font-size: 14px;");
        if (mensagem == null || mensagem.isEmpty()) return flow;

        Matcher matcher = Pattern.compile("\\X").matcher(mensagem);
        StringBuilder textoNormal = new StringBuilder();
        while (matcher.find()) {
            String grafema = matcher.group();
            if (pareceEmoji(grafema)) {
                if (textoNormal.length() > 0) {
                    Text t = new Text(textoNormal.toString());
                    t.setStyle("-fx-fill: " + corTexto + "; -fx-font-size: 14px;");
                    flow.getChildren().add(t);
                    textoNormal.setLength(0);
                }
                String hex = EmojiCatalogo.codigoHexDoCaractere(grafema);
                Image img = imagemEmoji(hex, grafema, 17);
                if (img != null && !img.isError()) {
                    ImageView iv = new ImageView(img);
                    iv.setFitWidth(17);
                    iv.setFitHeight(17);
                    iv.setPreserveRatio(true);
                    iv.setSmooth(true);
                    flow.getChildren().add(iv);
                } else {
                    Text t = new Text(grafema);
                    t.setStyle("-fx-fill: " + corTexto + "; -fx-font-size: 14px;");
                    flow.getChildren().add(t);
                }
            } else {
                textoNormal.append(grafema);
            }
        }
        if (textoNormal.length() > 0) {
            Text t = new Text(textoNormal.toString());
            t.setStyle("-fx-fill: " + corTexto + "; -fx-font-size: 14px;");
            flow.getChildren().add(t);
        }
        return flow;
    }

    private Image imagemEmoji(String hex, String caractere, double tamanho) {
        if (hex == null || hex.isBlank()) return null;
        return IMG_CACHE.computeIfAbsent(hex, h -> {
            try {
                return new Image("https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/" + h + ".png",
                        tamanho, tamanho, true, true, true);
            } catch (Exception ex) {
                return null;
            }
        });
    }

    private boolean pareceEmoji(String grafema) {
        return grafema.codePoints().anyMatch(cp ->
                (cp >= 0x1F000 && cp <= 0x1FAFF) ||
                (cp >= 0x2600 && cp <= 0x27BF) ||
                (cp >= 0x1F1E6 && cp <= 0x1F1FF));
    }

    private String nomeDe(String login) {
        if (ChatService.SUPORTE.equals(login) || "admin@mecha.com".equals(login)) return "Suporte";
        Usuario u = usuarioService.buscarPorLogin(login);
        return u != null ? u.getNome() : login;
    }

    @FXML
    private void onEnviar() {
        String texto = campoMensagem.getText();
        if (texto == null || texto.isBlank()) return;
        if (admin) {
            if (conversaAtiva == null || conversaAtiva.isBlank()) {
                Dialogos.mostrarMensagem("Suporte", "Selecione um usuário na lista.");
                return;
            }
            ChatService.enviar(ChatService.SUPORTE, conversaAtiva, texto.trim());
        } else {
            ChatService.enviar(loginAtual, ChatService.SUPORTE, texto.trim());
        }
        campoMensagem.clear();
        ultimoHashConversa = -1;
        carregarMensagens(true);
        if (admin) onAtualizarConversas();
    }
}
