package com.senai.javafx.projeto02.entidades;

/**
 * Fluxo da ordem de serviço:
 * ORCAMENTO → (cliente aprova) → AGENDADO → ANDAMENTO → FINALIZADO
 */
public enum Status {
    ORCAMENTO,   // Orçamento criado, aguardando aprovação do cliente
    AGENDADO,    // Cliente aprovou → vira OS / gera Nota de Serviço
    ANDAMENTO,   // Serviço em execução
    FINALIZADO   // Concluído → pode gerar Nota Fiscal
}
