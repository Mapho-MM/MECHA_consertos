package com.senai.javafx.projeto02;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

/**
 * Chat de suporte (admin ↔ usuário).
 * Persistência em ~/.mecha-consertos/chat-suporte.txt
 */
public final class ChatService {

    public static final String SUPORTE = "suporte";

    public record Mensagem(String id, String de, String para, String texto, long instante) {
        public String horaFormatada() {
            return DateTimeFormatter.ofPattern("dd/MM HH:mm")
                    .withZone(ZoneId.systemDefault())
                    .format(Instant.ofEpochMilli(instante));
        }
    }

    private static final Path ARQUIVO = Paths.get(
            System.getProperty("user.home"), ".mecha-consertos", "chat-suporte.txt");

    private static final List<Mensagem> CACHE = new CopyOnWriteArrayList<>();
    private static boolean carregado = false;

    private ChatService() {
    }

    private static synchronized void garantir() {
        if (carregado) return;
        carregado = true;
        try {
            Files.createDirectories(ARQUIVO.getParent());
            if (!Files.exists(ARQUIVO)) return;
            for (String linha : Files.readAllLines(ARQUIVO, StandardCharsets.UTF_8)) {
                if (linha == null || linha.isBlank()) continue;
                String[] p = linha.split("\\|", 5);
                if (p.length < 5) continue;
                CACHE.add(new Mensagem(p[0], unesc(p[1]), unesc(p[2]), unesc(p[3]), Long.parseLong(p[4])));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /** Descarta mensagens enviadas no modo de teste e relê o arquivo salvo. */
    public static synchronized void recarregarDoDisco() {
        CACHE.clear();
        carregado = false;
        garantir();
    }

    private static synchronized void persistir() {
        // Modo desenvolvedor = modo de teste: não grava nada no disco.
        if (Tema.modoDebug()) return;
        try {
            Files.createDirectories(ARQUIVO.getParent());
            List<String> linhas = new ArrayList<>();
            for (Mensagem m : CACHE) {
                linhas.add(m.id() + "|" + esc(m.de()) + "|" + esc(m.para()) + "|"
                        + esc(m.texto()) + "|" + m.instante());
            }
            Files.write(ARQUIVO, linhas, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Mensagem enviar(String de, String para, String texto) {
        garantir();
        if (de == null || para == null || texto == null || texto.isBlank()) return null;
        Mensagem m = new Mensagem(
                UUID.randomUUID().toString().substring(0, 8),
                de.trim().toLowerCase(),
                para.trim().toLowerCase(),
                texto.trim(),
                System.currentTimeMillis()
        );
        CACHE.add(m);
        persistir();
        return m;
    }

    /** Mensagens da conversa entre um usuário e o suporte (ambos os lados). */
    public static List<Mensagem> conversaComUsuario(String loginUsuario) {
        garantir();
        String u = loginUsuario == null ? "" : loginUsuario.trim().toLowerCase();
        return CACHE.stream()
                .filter(m ->
                        (m.de().equals(u) && m.para().equals(SUPORTE))
                                || (m.de().equals(SUPORTE) && m.para().equals(u))
                                || (m.de().equals("admin@mecha.com") && m.para().equals(u))
                                || (m.de().equals(u) && m.para().equals("admin@mecha.com")))
                .sorted(Comparator.comparingLong(Mensagem::instante))
                .collect(Collectors.toList());
    }

    /** Logins de usuários que já conversaram com o suporte (para o admin). */
    public static List<String> loginsComConversa() {
        garantir();
        LinkedHashSet<String> set = new LinkedHashSet<>();
        for (Mensagem m : CACHE) {
            if (m.de().equals(SUPORTE) || m.de().equals("admin@mecha.com")) {
                if (!m.para().equals(SUPORTE)) set.add(m.para());
            } else if (m.para().equals(SUPORTE) || m.para().equals("admin@mecha.com")) {
                set.add(m.de());
            }
        }
        return new ArrayList<>(set);
    }

    public static int totalMensagens() {
        garantir();
        return CACHE.size();
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("|", "\\|").replace("\n", "\\n");
    }

    private static String unesc(String s) {
        if (s == null) return "";
        return s.replace("\\n", "\n").replace("\\|", "|").replace("\\\\", "\\");
    }
}
