package com.senai.javafx.projeto02.entidades;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GerenciadorContadores {
    private final Map<Status, Integer> contadores = new HashMap<>();

    public GerenciadorContadores() {
        zerarContadores();
    }

    public void zerarContadores() {
        contadores.put(Status.ORCAMENTO, 0);
        contadores.put(Status.AGENDADO, 0);
        contadores.put(Status.ANDAMENTO, 0);
        contadores.put(Status.FINALIZADO, 0);
    }

    public void incrementar(Status status) {
        contadores.put(status, contadores.getOrDefault(status, 0) + 1);
    }

    public void atualizarContadoresDaLista(List<Cliente> listaClientes) {
        zerarContadores();
        for (Cliente cliente : listaClientes) {
            if (cliente.getStatus() != null) incrementar(cliente.getStatus());
        }
    }

    public int getQuantidade(Status status) {
        return contadores.getOrDefault(status, 0);
    }
}
