package com.senai.javafx.projeto02;

import javafx.animation.*;
import javafx.application.Platform;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.effect.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.stage.*;
import javafx.util.Duration;
import javafx.fxml.FXML;

/**
 * Tela de carregamento (carro girando em volta de uma pista).
 * É um painel que fica por cima das telas e só aparece quando uma tarefa demora;
 * quem controla isso é {@link Navegador#executarComCarregamento}.
 */
public class CarregandoController {

    @FXML private StackPane telaCarregando;
    @FXML private VBox cartaoCarregando;
    @FXML private Pane palcoCarro;
    @FXML private Label carregandoTexto;

    private RotateTransition giroCarro;

    @FXML
    public void initialize() {
        telaCarregando.setVisible(false);
        telaCarregando.setManaged(false);
    }

    public void mostrar(String mensagem) {
        if (telaCarregando == null) return;

        carregandoTexto.setText(mensagem);
        palcoCarro.getChildren().setAll(criarPista(), criarCarro());
        estilizar();

        telaCarregando.setVisible(true);
        telaCarregando.setManaged(true);
        telaCarregando.toFront();

        telaCarregando.setOpacity(0);
        FadeTransition aparecer = new FadeTransition(Duration.millis(180), telaCarregando);
        aparecer.setToValue(1);
        aparecer.play();

        if (giroCarro != null) giroCarro.stop();
        giroCarro = new RotateTransition(Duration.seconds(1.8), palcoCarro);
        giroCarro.setFromAngle(0);
        giroCarro.setByAngle(360);
        giroCarro.setCycleCount(Animation.INDEFINITE);
        giroCarro.setInterpolator(Interpolator.LINEAR);
        giroCarro.play();
    }

    public void esconder() {
        if (telaCarregando == null) return;

        if (giroCarro != null) {
            giroCarro.stop();
        }
        palcoCarro.setRotate(0);
        telaCarregando.setVisible(false);
        telaCarregando.setManaged(false);
    }

    // Pista circular tracejada (centro em 65,65 dentro do palco de 130x130).
    private Circle criarPista() {
        Circle pista = new Circle(65, 65, 46);
        pista.setFill(Color.TRANSPARENT);
        pista.setStroke(Color.web(Tema.paletaAtual().overlay() + "0.35)"));
        pista.setStrokeWidth(3);
        pista.setStrokeLineCap(StrokeLineCap.ROUND);
        pista.getStrokeDashArray().addAll(7.0, 9.0);
        return pista;
    }

    // Carro desenhado em vetor (SVG), rodando em cima da pista.
    private Group criarCarro() {
        SVGPath carroceria = new SVGPath();
        carroceria.setContent(
                "M3 19 L3 14 Q3 12 6 11 L14 9.5 L19 3.5 Q20 2.5 22 2.5 " +
                "L35 2.5 Q37 2.5 38 3.5 L43 9.5 L50 11 Q53 12 53 14.5 " +
                "L53 19 Q53 20.5 51.5 20.5 L4.5 20.5 Q3 20.5 3 19 Z");
        carroceria.setFill(Color.web("#ff3b30"));

        SVGPath vidroTras = new SVGPath();
        vidroTras.setContent("M17.5 9 L21 4.5 L26 4.5 L26 9 Z");
        vidroTras.setFill(Color.web("#dfe9ff"));

        SVGPath vidroFrente = new SVGPath();
        vidroFrente.setContent("M28.5 9 L28.5 4.5 L35 4.5 L39.5 9 Z");
        vidroFrente.setFill(Color.web("#dfe9ff"));

        Group carro = new Group(carroceria, vidroTras, vidroFrente,
                criarRoda(14), criarRoda(42));

        // Apoia o carro no topo da pista (rodas tocando o círculo).
        carro.setLayoutX(65 - 28);
        carro.setLayoutY(65 - 46 - 25.5);
        return carro;
    }

    private Group criarRoda(double centroX) {
        Circle pneu = new Circle(centroX, 20.5, 4.6);
        pneu.setFill(Color.web("#2b2b33"));
        pneu.setStroke(Color.web("#cfd3dc"));
        pneu.setStrokeWidth(1.2);

        Circle calota = new Circle(centroX, 20.5, 1.6);
        calota.setFill(Color.web("#cfd3dc"));

        return new Group(pneu, calota);
    }

    public void estilizar() {
        if (telaCarregando == null) return;

        Tema.Paleta p = Tema.paletaAtual();

        telaCarregando.setStyle("-fx-background-color: rgba(0,0,0,0.50);");
        cartaoCarregando.setStyle(
                "-fx-background-color: " + p.fundoJanela() + ";" +
                "-fx-background-radius: 28;" +
                "-fx-border-color: " + p.borda() + ";" +
                "-fx-border-radius: 28;" +
                "-fx-border-width: 1;" +
                "-fx-padding: 26 40 24 40;"
        );
        cartaoCarregando.setEffect(new DropShadow(26, Color.rgb(0, 0, 0, 0.45)));
        if (Tema.temaLiquid()) Tema.adicionarClasse(cartaoCarregando, "liquid-glass");
        else Tema.removerClasse(cartaoCarregando, "liquid-glass");
        carregandoTexto.setStyle(
                "-fx-text-fill: " + p.textoSec() + ";" +
                "-fx-font-size: 14px;" +
                "-fx-font-weight: bold;"
        );
    }
}
