package com.senai.javafx.projeto02;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import static com.senai.javafx.projeto02.Dialogos.mostrarMensagem;
import static com.senai.javafx.projeto02.Tema.*;

/**
 * Controller genérico de listagem — segue o LayoutPadrao obrigatório:
 * Cabeçalho (título + ↻) → Cards → Barra (filtros | ações) → Tabela → Rodapé.
 */
public class ModuloSecaoController {

    @FXML private VBox raiz;
    @FXML private HBox caixaCabecalho;
    @FXML private Label titulo;
    @FXML private Button btnAtualizar;
    @FXML private HBox caixaCards;
    @FXML private HBox barraControle;
    @FXML private HBox caixaFiltros;
    @FXML private HBox caixaAcoes;
    @FXML private Button btnNovo;
    @FXML private Button btnEditar;
    @FXML private Button btnExcluir;
    @FXML private Label badgeRegistros;
    @FXML private TableView<Map<String, String>> tabela;

    private Runnable aoNovo;
    private Runnable aoAtualizar;
    private Consumer<Map<String, String>> aoEditar;
    private Consumer<Map<String, String>> aoExcluir;

    @FXML
    private void initialize() {
        tabela.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        LayoutPadrao.estilizarTabela(tabela);
        tabela.setOnMouseClicked(ev -> {
            if (ev.getClickCount() == 2) onEditar();
        });
        aplicarEstilosBotoes();
    }

    public void configurar(
            String tituloTxt,
            String subtituloTxt,
            String[] colunas,
            List<Map<String, String>> linhas,
            String textoVazio,
            String[][] cards,
            Runnable aoNovo,
            Runnable aoAtualizar,
            Consumer<Map<String, String>> aoEditar,
            Consumer<Map<String, String>> aoExcluir
    ) {
        this.aoNovo = aoNovo;
        this.aoAtualizar = aoAtualizar;
        this.aoEditar = aoEditar;
        this.aoExcluir = aoExcluir;

        Paleta p = paletaAtual();
        titulo.setText(tituloTxt);
        titulo.setStyle("-fx-text-fill: " + p.texto() + "; -fx-font-size: 26px; -fx-font-weight: bold;");

        // ↻ isolado
        if (btnAtualizar != null) {
            btnAtualizar.setVisible(aoAtualizar != null);
            btnAtualizar.setManaged(aoAtualizar != null);
            btnAtualizar.setText("↻");
            btnAtualizar.setTooltip(new Tooltip("Atualizar"));
            btnAtualizar.setStyle(
                    "-fx-background-color: " + LayoutPadrao.COR_NEUTRO_BG + ";" +
                    "-fx-text-fill: " + p.textoSec() + ";" +
                    "-fx-font-size: 16px; -fx-font-weight: bold;" +
                    "-fx-background-radius: 18; -fx-border-radius: 18;" +
                    "-fx-border-color: " + LayoutPadrao.COR_NEUTRO_BD + "; -fx-border-width: 1;" +
                    "-fx-cursor: hand; -fx-padding: 0;"
            );
        }

        // Visibilidade das ações
        setVisivel(btnNovo, aoNovo != null);
        setVisivel(btnEditar, aoEditar != null);
        setVisivel(btnExcluir, aoExcluir != null);

        aplicarEstilosBotoes();
        if (caixaAcoes != null) caixaAcoes.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        if (barraControle != null) barraControle.setAlignment(javafx.geometry.Pos.CENTER_LEFT);

        // Tabela
        tabela.setPlaceholder(new Label(textoVazio != null ? textoVazio : "Sem registros."));
        tabela.getColumns().clear();
        if (colunas != null) {
            for (String col : colunas) {
                if (col == null || col.startsWith("_")) continue;
                TableColumn<Map<String, String>, String> c = new TableColumn<>(col);
                final String chave = col;
                c.setCellValueFactory(d -> new SimpleStringProperty(
                        d.getValue() != null ? d.getValue().getOrDefault(chave, "") : ""));
                c.setMinWidth(80);
                tabela.getColumns().add(c);
            }
        }
        int total = linhas != null ? linhas.size() : 0;
        tabela.setItems(FXCollections.observableArrayList(linhas != null ? linhas : List.of()));
        LayoutPadrao.estilizarTabela(tabela);

        // Rodapé
        LayoutPadrao.atualizarRodape(badgeRegistros, total);
        if (badgeRegistros != null) {
            badgeRegistros.setStyle("-fx-text-fill: " + p.textoSec() + "; -fx-font-size: 12px;");
        }

        // Cards
        caixaCards.getChildren().clear();
        if (cards != null) {
            for (String[] card : cards) {
                if (card != null && card.length >= 2) {
                    caixaCards.getChildren().add(LayoutPadrao.cardIndicador(card[0], card[1]));
                }
            }
        }
        caixaCards.setVisible(cards != null && cards.length > 0);
        caixaCards.setManaged(cards != null && cards.length > 0);
    }

    private void aplicarEstilosBotoes() {
        // Ordem visual já no FXML: Excluir → Editar → Novo
        if (btnExcluir != null) {
            btnExcluir.setText("Excluir");
            btnExcluir.setStyle(
                    "-fx-background-color: " + LayoutPadrao.COR_DESTRUTIVO + ";" +
                    "-fx-text-fill: #ffffff; -fx-font-size: 13px; -fx-font-weight: bold;" +
                    "-fx-background-radius: 12; -fx-border-radius: 12; -fx-border-width: 0;" +
                    "-fx-cursor: hand; -fx-padding: 0 14;"
            );
            btnExcluir.setPrefHeight(36);
            btnExcluir.setAlignment(javafx.geometry.Pos.CENTER);
        }
        if (btnEditar != null) {
            btnEditar.setText("Editar");
            btnEditar.setStyle(
                    "-fx-background-color: " + LayoutPadrao.COR_EDICAO + ";" +
                    "-fx-text-fill: #1a1a1a; -fx-font-size: 13px; -fx-font-weight: bold;" +
                    "-fx-background-radius: 12; -fx-border-radius: 12; -fx-border-width: 0;" +
                    "-fx-cursor: hand; -fx-padding: 0 14;"
            );
            btnEditar.setPrefHeight(36);
            btnEditar.setAlignment(javafx.geometry.Pos.CENTER);
        }
        if (btnNovo != null) {
            btnNovo.setText("+ Novo");
            btnNovo.setStyle(
                    "-fx-background-color: " + LayoutPadrao.COR_PRIMARIO + ";" +
                    "-fx-text-fill: #ffffff; -fx-font-size: 13px; -fx-font-weight: bold;" +
                    "-fx-background-radius: 12; -fx-border-radius: 12; -fx-border-width: 0;" +
                    "-fx-cursor: hand; -fx-padding: 0 14;"
            );
            btnNovo.setPrefHeight(36);
            btnNovo.setAlignment(javafx.geometry.Pos.CENTER);
        }
    }

    private static void setVisivel(Button b, boolean on) {
        if (b == null) return;
        b.setVisible(on);
        b.setManaged(on);
    }

    @FXML private void onNovo() {
        if (aoNovo != null) aoNovo.run();
    }

    @FXML private void onAtualizar() {
        if (aoAtualizar != null) aoAtualizar.run();
    }

    @FXML private void onEditar() {
        Map<String, String> sel = tabela.getSelectionModel().getSelectedItem();
        if (sel == null) {
            mostrarMensagem(titulo.getText(), "Selecione uma linha.");
            return;
        }
        if (aoEditar != null) aoEditar.accept(sel);
    }

    @FXML private void onExcluir() {
        Map<String, String> sel = tabela.getSelectionModel().getSelectedItem();
        if (sel == null) {
            mostrarMensagem(titulo.getText(), "Selecione uma linha.");
            return;
        }
        if (aoExcluir != null) aoExcluir.accept(sel);
    }
}
