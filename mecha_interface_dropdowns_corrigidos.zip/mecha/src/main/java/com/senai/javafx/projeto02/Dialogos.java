package com.senai.javafx.projeto02;

import javafx.animation.*;
import javafx.application.Platform;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.effect.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.stage.*;
import javafx.util.Duration;
import com.senai.javafx.projeto02.Tema.Paleta;

import static com.senai.javafx.projeto02.Tema.*;

/**
 * Janelas de aviso, confirmação e blocos visuais reutilizáveis,
 * sempre desenhados no tema atual.
 */
public final class Dialogos {

    private Dialogos() {
    }

    public static void mostrarMensagem(String titulo, String mensagem) {
        mostrarDialogo("i", titulo, mensagem);
    }

    public static void mostrarDialogo(String icone, String titulo, String mensagem) {
        Paleta p = paletaAtual();
        Stage janela = criarJanelaTematica();
        VBox cartao = criarCartaoTematico(380, p);

        Button ok = botaoPrimario("OK", p);
        ok.setDefaultButton(true);
        ok.setOnAction(event -> janela.close());

        cartao.getChildren().addAll(
                criarIcone(icone, p, false),
                criarTitulo(titulo, p),
                criarTexto(mensagem, p),
                ok
        );

        exibirJanela(janela, cartao);
    }

    /**
     * Confirmação no estilo do mockup ("Apagar Projeto?").
     * Retorna true se a pessoa clicar no botão de confirmar.
     */
    public static boolean confirmar(String titulo, String mensagem, String textoNao, String textoSim) {
        Paleta p = paletaAtual();
        Stage janela = criarJanelaTematica();
        VBox cartao = criarCartaoTematico(420, p);
        boolean[] resposta = {false};

        Button nao = botaoSecundario(textoNao, p);
        nao.setOnAction(event -> janela.close());

        Button sim = new Button(textoSim);
        sim.setMaxWidth(Double.MAX_VALUE);
        sim.setPrefHeight(46);
        sim.setStyle(
                "-fx-background-color: #ff2d2d;" +
                "-fx-background-radius: 23;" +
                "-fx-text-fill: white;" +
                "-fx-font-size: 14px;" +
                "-fx-font-weight: bold;" +
                "-fx-cursor: hand;"
        );
        sim.setOnAction(event -> {
            resposta[0] = true;
            janela.close();
        });

        HBox.setHgrow(nao, Priority.ALWAYS);
        HBox.setHgrow(sim, Priority.ALWAYS);
        HBox botoes = new HBox(10, nao, sim);
        botoes.setAlignment(Pos.CENTER);

        cartao.getChildren().addAll(
                criarIcone("⚠", p, true),
                criarTitulo(titulo, p),
                criarTexto(mensagem, p),
                botoes
        );

        exibirJanela(janela, cartao);
        return resposta[0];
    }

    public static Stage criarJanelaTematica() {
        Stage janela = new Stage(StageStyle.TRANSPARENT);
        janela.initModality(Modality.APPLICATION_MODAL);

        StackPane raiz = Navegador.raiz();
        if (raiz != null && raiz.getScene() != null && raiz.getScene().getWindow() != null) {
            janela.initOwner(raiz.getScene().getWindow());
        }
        return janela;
    }

    public static VBox criarCartaoTematico(double largura, Paleta p) {
        VBox cartao = new VBox(14);
        cartao.setAlignment(Pos.CENTER);
        cartao.setPadding(new Insets(28));
        cartao.setPrefWidth(largura);
        cartao.setMaxWidth(largura);
        cartao.setStyle(
                "-fx-background-color: " + p.fundoJanela() + ";" +
                "-fx-background-radius: 28;" +
                "-fx-border-color: " + p.borda() + ";" +
                "-fx-border-radius: 28;" +
                "-fx-border-width: 1;"
        );
        cartao.setEffect(new DropShadow(26, Color.rgb(0, 0, 0, 0.45)));
        if (temaLiquid()) adicionarClasse(cartao, "liquid-glass");
        return cartao;
    }

    public static void exibirJanela(Stage janela, VBox cartao) {
        StackPane base = new StackPane(cartao);
        base.setPadding(new Insets(28)); // espaço para a sombra
        base.setStyle("-fx-background-color: transparent;");

        Scene cena = new Scene(base);
        cena.setFill(Color.TRANSPARENT);

        janela.setScene(cena);
        Animacoes.instalarMicro(cartao);
        janela.setOnShown(e -> Animacoes.abrirDialogo(cartao));
        janela.showAndWait();
    }

    public static Label criarIcone(String simbolo, Paleta p, boolean perigo) {
        Label icone = new Label(simbolo);
        icone.setAlignment(Pos.CENTER);
        icone.setMinSize(60, 60);
        icone.setPrefSize(60, 60);
        icone.setMaxSize(60, 60);
        icone.setStyle(
                "-fx-background-color: " + (perigo ? "#ffe0e3" : p.overlay() + "0.15)") + ";" +
                "-fx-background-radius: 30;" +
                "-fx-text-fill: " + (perigo ? "#ff2d2d" : p.texto()) + ";" +
                "-fx-font-size: 26px;" +
                "-fx-font-weight: bold;"
        );
        return icone;
    }

    public static Label criarTitulo(String texto, Paleta p) {
        Label titulo = new Label(texto);
        titulo.setWrapText(true);
        titulo.setTextAlignment(TextAlignment.CENTER);
        titulo.setStyle("-fx-text-fill: " + p.texto() + "; -fx-font-size: 22px; -fx-font-weight: bold;");
        titulo.setMinHeight(Region.USE_PREF_SIZE);
        return titulo;
    }

    public static Label criarTexto(String texto, Paleta p) {
        Label mensagem = new Label(texto);
        mensagem.setWrapText(true);
        mensagem.setTextAlignment(TextAlignment.CENTER);
        mensagem.setStyle("-fx-text-fill: " + p.textoSec() + "; -fx-font-size: 14px;");
        mensagem.setMinHeight(Region.USE_PREF_SIZE);
        return mensagem;
    }

    public static Button botaoPrimario(String texto, Paleta p) {
        Button botao = new Button(texto);
        botao.setMaxWidth(Double.MAX_VALUE);
        botao.setPrefHeight(46);
        botao.setStyle(
                "-fx-background-color: " + fundoDestaque() + ";" +
                "-fx-background-radius: 23;" +
                "-fx-text-fill: " + p.botaoTexto() + ";" +
                "-fx-font-size: 14px;" +
                "-fx-font-weight: bold;" +
                "-fx-cursor: hand;"
        );
        return botao;
    }

    public static Button botaoSecundario(String texto, Paleta p) {
        Button botao = new Button(texto);
        botao.setMaxWidth(Double.MAX_VALUE);
        botao.setPrefHeight(46);
        botao.setStyle(
                "-fx-background-color: " + p.overlay() + "0.12);" +
                "-fx-background-radius: 23;" +
                "-fx-text-fill: " + p.texto() + ";" +
                "-fx-font-size: 14px;" +
                "-fx-font-weight: bold;" +
                "-fx-cursor: hand;"
        );
        return botao;
    }

    public static Label criarTituloPequeno(String texto, Paleta p) {
        Label label = new Label(texto);
        label.setStyle(
                "-fx-text-fill: " + p.texto() + ";" +
                "-fx-font-size: 12px;" +
                "-fx-font-weight: bold;"
        );
        return label;
    }

    public static Region criarSeparador(Paleta p) {
        Region separador = new Region();
        separador.setPrefHeight(1);
        separador.setMaxWidth(Double.MAX_VALUE);
        separador.setStyle("-fx-background-color: " + p.borda() + ";");
        VBox.setMargin(separador, new Insets(4, 24, 4, 24));
        return separador;
    }
}
