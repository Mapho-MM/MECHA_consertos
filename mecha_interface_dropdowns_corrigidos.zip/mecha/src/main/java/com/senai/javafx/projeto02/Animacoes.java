package com.senai.javafx.projeto02;

import javafx.animation.*;
import javafx.scene.Node;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.ButtonBase;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.Parent;
import javafx.util.Duration;

/**
 * Animações do sistema num lugar só, para todas as telas terem o mesmo "jeito":
 * entradas suaves (fade + deslize), janelas que "abrem" com leve zoom, botões
 * que reagem ao mouse e troca de tema com transição em vez de piscar.
 */
public final class Animacoes {

    private Animacoes() {
    }

    /** Desacelera no final (sensação de "pousar"), usada na maioria das entradas. */
    private static final Interpolator SUAVE = Interpolator.SPLINE(0.22, 1.0, 0.36, 1.0);

    private static final String CHAVE_ENTRADA = "mecha.anim.entrada";
    private static final String CHAVE_MICRO = "mecha.anim.micro";

    /** Fade + deslize de baixo para cima. */
    public static void entrada(Node no) {
        entrada(no, 16, 360);
    }

    public static void entrada(Node no, double deslocamento, double ms) {
        if (no == null) return;

        Object anterior = no.getProperties().get(CHAVE_ENTRADA);
        if (anterior instanceof Animation a) a.stop();

        no.setOpacity(0);
        no.setTranslateY(deslocamento);

        FadeTransition fade = new FadeTransition(Duration.millis(ms), no);
        fade.setToValue(1);
        fade.setInterpolator(Interpolator.EASE_OUT);

        TranslateTransition desliza = new TranslateTransition(Duration.millis(ms), no);
        desliza.setToY(0);
        desliza.setInterpolator(SUAVE);

        ParallelTransition conjunto = new ParallelTransition(fade, desliza);
        conjunto.setOnFinished(e -> {
            no.setOpacity(1);
            no.setTranslateY(0);
            no.getProperties().remove(CHAVE_ENTRADA);
        });
        no.getProperties().put(CHAVE_ENTRADA, conjunto);
        conjunto.play();
    }

    /** Janelas (diálogos) abrem com um leve zoom + fade. */
    public static void abrirDialogo(Node cartao) {
        if (cartao == null) return;
        try {
            abrirDialogoInterno(cartao);
        } catch (Exception e) {
            cartao.setOpacity(1);
            cartao.setScaleX(1);
            cartao.setScaleY(1);
            Tema.debugErro("Falha na animação de abrir janela", e);
        }
    }

    private static void abrirDialogoInterno(Node cartao) {
        cartao.setOpacity(0);
        cartao.setScaleX(0.93);
        cartao.setScaleY(0.93);

        FadeTransition fade = new FadeTransition(Duration.millis(200), cartao);
        fade.setToValue(1);

        ScaleTransition zoom = new ScaleTransition(Duration.millis(280), cartao);
        zoom.setToX(1);
        zoom.setToY(1);
        zoom.setInterpolator(SUAVE); // SPLINE só aceita valores entre 0 e 1

        new ParallelTransition(fade, zoom).play();
    }

    /**
     * Botões reagem ao mouse: crescem um pouco ao passar o mouse e "afundam"
     * ao clicar. Botões largos (itens de menu) só deslizam de leve para a direita.
     */
    public static void instalarMicro(Node raiz) {
        if (raiz == null) return;
        if (raiz instanceof ButtonBase botao) {
            instalarMicroBotao(botao);
        }
        if (raiz instanceof Parent pai) {
            for (Node filho : pai.getChildrenUnmodifiable()) {
                instalarMicro(filho);
            }
        }
    }

    private static void instalarMicroBotao(ButtonBase botao) {
        if (botao.getProperties().containsKey(CHAVE_MICRO)) return;
        botao.getProperties().put(CHAVE_MICRO, Boolean.TRUE);

        // addEventHandler (e não setOn...) para não ser sobrescrito por outros estilos.
        botao.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
            if (botao.isDisabled()) return;
            if (botao.getWidth() > 220) mover(botao, 4);
            else escalar(botao, 1.035, 140);
        });
        botao.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
            if (botao.getWidth() > 220) mover(botao, 0);
            else escalar(botao, 1.0, 160);
        });
        botao.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
            if (botao.isDisabled() || botao.getWidth() > 220) return;
            escalar(botao, 0.965, 80);
        });
        botao.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {
            if (botao.getWidth() > 220) return;
            escalar(botao, botao.isHover() ? 1.035 : 1.0, 120);
        });
    }

    private static void escalar(Node no, double alvo, double ms) {
        ScaleTransition t = new ScaleTransition(Duration.millis(ms), no);
        t.setToX(alvo);
        t.setToY(alvo);
        t.setInterpolator(Interpolator.EASE_OUT);
        t.play();
    }

    private static void mover(Node no, double alvoX) {
        TranslateTransition t = new TranslateTransition(Duration.millis(150), no);
        t.setToX(alvoX);
        t.setInterpolator(Interpolator.EASE_OUT);
        t.play();
    }

    /**
     * Troca de tema sem "piscar": tira uma foto da tela, aplica o tema novo por
     * baixo e some com a foto num fade rápido.
     */
    public static void transicaoDeTema(StackPane raiz, Runnable aplicar) {
        if (raiz == null || raiz.getScene() == null || raiz.getWidth() < 10 || raiz.getHeight() < 10) {
            aplicar.run();
            return;
        }

        ImageView foto = null;
        try {
            WritableImage imagem = raiz.snapshot(new SnapshotParameters(), null);
            foto = new ImageView(imagem);
            foto.setFitWidth(raiz.getWidth());
            foto.setFitHeight(raiz.getHeight());
            foto.setPreserveRatio(false);
            foto.setMouseTransparent(true);
            foto.setManaged(false);
            raiz.getChildren().add(foto);
        } catch (Exception e) {
            foto = null;
        }

        try {
            aplicar.run();
        } finally {
            if (foto != null) {
                final ImageView sobra = foto;
                sobra.toFront();
                FadeTransition sumir = new FadeTransition(Duration.millis(340), sobra);
                sumir.setFromValue(1);
                sumir.setToValue(0);
                sumir.setInterpolator(Interpolator.EASE_BOTH);
                sumir.setOnFinished(e -> raiz.getChildren().remove(sobra));
                sumir.play();
            }
        }
    }
}
