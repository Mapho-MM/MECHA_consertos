package com.senai.javafx.projeto02;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.prefs.Preferences;

/**
 * Preferências do sistema (tema, contas, foto de perfil, último acesso...).
 *
 * Com o modo desenvolvedor ativo nada é gravado no disco: as alterações ficam
 * só numa "sombra" em memória, que vale durante o teste e é descartada ao
 * desativar o modo. Com o modo desligado, grava normalmente.
 *
 * Tem a mesma assinatura básica de {@link Preferences}, então AppSingleton e
 * UsuarioService usam esta classe sem mudar o resto do código.
 */
public final class Armazenamento {

    private static final Armazenamento INSTANCIA = new Armazenamento();
    private static final String REMOVIDO = "\u0000removido";

    private final Preferences disco = Preferences.userNodeForPackage(AppSingleton.class);
    private final Map<String, String> sombra = new ConcurrentHashMap<>();

    private Armazenamento() {
    }

    public static Armazenamento get() {
        return INSTANCIA;
    }

    /** Preferências reais (disco). Não use para gravar: ignora o modo de teste. */
    public Preferences bruto() {
        return disco;
    }

    /** Joga fora tudo o que foi alterado durante o modo desenvolvedor. */
    public void descartarSombra() {
        sombra.clear();
    }

    private String lerSombra(String chave) {
        return Tema.modoDebug() ? sombra.get(chave) : null;
    }

    public String get(String chave, String padrao) {
        String s = lerSombra(chave);
        if (s != null) return REMOVIDO.equals(s) ? padrao : s;
        return disco.get(chave, padrao);
    }

    public int getInt(String chave, int padrao) {
        String s = lerSombra(chave);
        if (s != null) {
            if (REMOVIDO.equals(s)) return padrao;
            try {
                return Integer.parseInt(s);
            } catch (NumberFormatException e) {
                return padrao;
            }
        }
        return disco.getInt(chave, padrao);
    }

    public long getLong(String chave, long padrao) {
        String s = lerSombra(chave);
        if (s != null) {
            if (REMOVIDO.equals(s)) return padrao;
            try {
                return Long.parseLong(s);
            } catch (NumberFormatException e) {
                return padrao;
            }
        }
        return disco.getLong(chave, padrao);
    }

    public boolean getBoolean(String chave, boolean padrao) {
        String s = lerSombra(chave);
        if (s != null) return REMOVIDO.equals(s) ? padrao : Boolean.parseBoolean(s);
        return disco.getBoolean(chave, padrao);
    }

    public void put(String chave, String valor) {
        if (Tema.modoDebug()) sombra.put(chave, valor);
        else disco.put(chave, valor);
    }

    public void putInt(String chave, int valor) {
        if (Tema.modoDebug()) sombra.put(chave, String.valueOf(valor));
        else disco.putInt(chave, valor);
    }

    public void putLong(String chave, long valor) {
        if (Tema.modoDebug()) sombra.put(chave, String.valueOf(valor));
        else disco.putLong(chave, valor);
    }

    public void putBoolean(String chave, boolean valor) {
        if (Tema.modoDebug()) sombra.put(chave, String.valueOf(valor));
        else disco.putBoolean(chave, valor);
    }

    public void remove(String chave) {
        if (Tema.modoDebug()) sombra.put(chave, REMOVIDO);
        else disco.remove(chave);
    }
}
