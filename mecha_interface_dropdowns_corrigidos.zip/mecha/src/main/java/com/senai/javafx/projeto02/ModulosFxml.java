package com.senai.javafx.projeto02;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.VBox;

import java.net.URL;

/** Carrega FXML de módulos na área central do dashboard. */
public final class ModulosFxml {

    private static final String PASTA = "/com/senai/javafx/projeto02/";

    private ModulosFxml() {
    }

    public static <T> T carregar(VBox area, String arquivoFxml) {
        if (area == null) throw new IllegalStateException("Área de conteúdo nula.");
        try {
            URL url = ModulosFxml.class.getResource(PASTA + arquivoFxml);
            if (url == null) throw new IllegalStateException(arquivoFxml + " não encontrado.");
            FXMLLoader loader = new FXMLLoader(url);
            Parent root = loader.load();
            area.getChildren().setAll(root);
            VBox.setVgrow(root, javafx.scene.layout.Priority.ALWAYS);
            // Reaplica tema (tabelas/combos) no módulo recém-carregado
            try {
                Tema.guardarEstilosBase(root);
                Tema.aplicarEstiloAdaptado(root);
            } catch (Exception ignored) {
            }
            return loader.getController();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Falha ao carregar módulo FXML: " + arquivoFxml, e);
        }
    }
}
