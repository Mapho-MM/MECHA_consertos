package com.senai.javafx.projeto02;

import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Window;
import javafx.util.Duration;

import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Easter egg: digitar "abobrinha" em qualquer tela exibe a imagem em tela cheia.
 * Usa KEY_PRESSED + KEY_TYPED (filtro na Scene) para funcionar mesmo com foco em campos.
 */
public final class EasterEggAbobrinha {

    private static final String ALVO = "abobrinha";
    private static final String URL_IMAGEM =
            "https://images.pexels.com/photos/13656392/pexels-photo-13656392.jpeg?auto=compress&cs=tinysrgb&w=1200";

    private static final StringBuilder buffer = new StringBuilder();
    private static final AtomicBoolean instalado = new AtomicBoolean(false);
    private static volatile boolean exibindo;
    private static volatile Image imagemCache;
    private static Scene cenaInstalada;

    private EasterEggAbobrinha() {
    }

    public static void instalar(Scene cena) {
        if (cena == null) return;
        if (instalado.get() && cenaInstalada == cena) return;
        instalado.set(true);
        cenaInstalada = cena;

        // Captura em qualquer lugar (inclusive TextField/PasswordField)
        cena.addEventFilter(KeyEvent.KEY_TYPED, EasterEggAbobrinha::aoDigitar);
        cena.addEventFilter(KeyEvent.KEY_PRESSED, EasterEggAbobrinha::aoPressionar);

        // Reinstala se a scene da raiz mudar
        StackPane raiz = Navegador.raiz();
        if (raiz != null) {
            raiz.sceneProperty().addListener((obs, oldS, newS) -> {
                if (newS != null && newS != cenaInstalada) {
                    instalado.set(false);
                    instalar(newS);
                }
            });
        }

        // Baixa a imagem em background (HTTP) para não depender só do loader JavaFX
        Thread t = new Thread(EasterEggAbobrinha::baixarImagem, "abobrinha-loader");
        t.setDaemon(true);
        t.start();
    }

    private static void baixarImagem() {
        try {
            HttpClient client = HttpClient.newBuilder()
                    .followRedirects(HttpClient.Redirect.NORMAL)
                    .connectTimeout(java.time.Duration.ofSeconds(8))
                    .build();
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(URL_IMAGEM))
                    .header("User-Agent", "MechaConsertos/1.0")
                    .timeout(java.time.Duration.ofSeconds(15))
                    .GET()
                    .build();
            HttpResponse<byte[]> resp = client.send(req, HttpResponse.BodyHandlers.ofByteArray());
            if (resp.statusCode() >= 200 && resp.statusCode() < 300 && resp.body() != null && resp.body().length > 100) {
                Image img = new Image(new ByteArrayInputStream(resp.body()));
                if (!img.isError()) {
                    imagemCache = img;
                    return;
                }
            }
        } catch (Exception ignored) {
        }
        // Fallback: loader JavaFX assíncrono
        Platform.runLater(() -> {
            try {
                Image img = new Image(URL_IMAGEM, true);
                img.progressProperty().addListener((o, a, b) -> {
                    if (b != null && b.doubleValue() >= 1.0 && !img.isError()) {
                        imagemCache = img;
                    }
                });
            } catch (Exception ignored) {
            }
        });
    }

    private static void aoPressionar(KeyEvent ev) {
        if (ev.getCode() == KeyCode.BACK_SPACE) {
            if (buffer.length() > 0) buffer.deleteCharAt(buffer.length() - 1);
            return;
        }
        if (ev.getCode() == KeyCode.ESCAPE && exibindo) {
            // deixar o overlay tratar
            return;
        }
        String txt = ev.getText();
        if (txt != null && txt.length() == 1) {
            processarChar(txt.charAt(0));
        }
    }

    private static void aoDigitar(KeyEvent ev) {
        String ch = ev.getCharacter();
        if (ch == null || ch.isEmpty()) return;
        processarChar(ch.charAt(0));
    }

    private static void processarChar(char c) {
        if (Character.isISOControl(c)) return;
        char lower = Character.toLowerCase(c);
        // aceita letras sem acento; se digitar algo fora, não zera se for espaço
        if (lower < 'a' || lower > 'z') {
            if (!Character.isLetter(lower)) buffer.setLength(0);
            return;
        }
        buffer.append(lower);
        if (buffer.length() > ALVO.length()) {
            buffer.delete(0, buffer.length() - ALVO.length());
        }
        if (buffer.toString().endsWith(ALVO)) {
            buffer.setLength(0);
            Platform.runLater(EasterEggAbobrinha::mostrar);
        }
    }

    private static void mostrar() {
        if (exibindo) return;

        StackPane raiz = Navegador.raiz();
        Scene cena = cenaInstalada;
        if (raiz == null && cena != null && cena.getRoot() instanceof StackPane sp) {
            raiz = sp;
        }
        if (raiz == null && cena != null && cena.getWindow() != null) {
            // fallback: cria overlay no root da scene
            if (cena.getRoot() instanceof StackPane sp2) raiz = sp2;
        }
        if (raiz == null) return;

        exibindo = true;
        final StackPane alvo = raiz;

        Rectangle fundo = new Rectangle();
        fundo.widthProperty().bind(alvo.widthProperty());
        fundo.heightProperty().bind(alvo.heightProperty());
        fundo.setFill(Color.rgb(0, 0, 0, 0.85));

        Image img = imagemCache;
        ImageView view = new ImageView();
        view.setPreserveRatio(true);
        view.setSmooth(true);
        view.fitWidthProperty().bind(alvo.widthProperty().multiply(0.9));
        view.fitHeightProperty().bind(alvo.heightProperty().multiply(0.85));

        Label status = new Label();
        status.setStyle("-fx-text-fill: #bbf7d0; -fx-font-size: 16px; -fx-font-weight: bold;");
        StackPane.setAlignment(status, Pos.BOTTOM_CENTER);
        status.setTranslateY(-18);

        if (img != null && !img.isError()) {
            view.setImage(img);
            status.setText("🌱 ABOBRINHA 🌱  — clique ou ESC para fechar");
        } else {
            status.setText("🌱 Carregando abobrinha… (precisa de internet)");
            Thread t = new Thread(() -> {
                baixarImagem();
                Platform.runLater(() -> {
                    if (imagemCache != null && !imagemCache.isError()) {
                        view.setImage(imagemCache);
                        status.setText("🌱 ABOBRINHA 🌱  — clique ou ESC para fechar");
                    } else {
                        status.setText("Não foi possível carregar a imagem. Verifique a internet.");
                    }
                });
            }, "abobrinha-retry");
            t.setDaemon(true);
            t.start();
        }

        StackPane overlay = new StackPane(fundo, view, status);
        overlay.setStyle("-fx-cursor: hand;");
        overlay.setOpacity(0);
        overlay.setFocusTraversable(true);

        Runnable fechar = () -> {
            FadeTransition out = new FadeTransition(Duration.millis(250), overlay);
            out.setToValue(0);
            out.setOnFinished(e -> {
                alvo.getChildren().remove(overlay);
                exibindo = false;
            });
            out.play();
        };

        overlay.setOnMouseClicked(e -> fechar.run());
        overlay.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (e.getCode() == KeyCode.ESCAPE || e.getCode() == KeyCode.ENTER || e.getCode() == KeyCode.SPACE) {
                fechar.run();
                e.consume();
            }
        });

        alvo.getChildren().add(overlay);
        Platform.runLater(overlay::requestFocus);

        FadeTransition fade = new FadeTransition(Duration.millis(320), overlay);
        fade.setFromValue(0);
        fade.setToValue(1);
        fade.play();

        PauseTransition auto = new PauseTransition(Duration.seconds(15));
        auto.setOnFinished(e -> {
            if (exibindo && alvo.getChildren().contains(overlay)) fechar.run();
        });
        auto.play();
    }
}
