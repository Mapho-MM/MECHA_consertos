package com.senai.javafx.projeto02;

import javafx.fxml.FXML;
import javafx.scene.layout.StackPane;

/**
 * Janela principal: só guarda o palco onde as telas aparecem e o painel de
 * carregamento (por cima de tudo). Nenhuma regra de tela fica aqui.
 */
public class MainController {

    @FXML private StackPane raiz;
    @FXML private StackPane palco;

    // fx:include com fx:id="carregando" injeta o controller como "carregandoController".
    @FXML private CarregandoController carregandoController;

    @FXML
    public void initialize() {
        Navegador.registrar(raiz, palco, carregandoController);
    }
}
