package com.senai.javafx.projeto02;

import javafx.animation.*;
import javafx.application.Platform;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.effect.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.stage.*;
import javafx.util.Duration;
import javafx.fxml.FXML;

import com.senai.javafx.projeto02.Tema.Paleta;

import static com.senai.javafx.projeto02.Dialogos.*;
import static com.senai.javafx.projeto02.Tema.*;

/** Tela de ajuda: esqueci a senha / problemas com login (ajuda-view.fxml). */
public class AjudaController implements TelaController {

    @FXML private VBox telaRecuperacao;

    // Um assunto por vez
    @FXML private ToggleGroup grupoAjuda;
    @FXML private ToggleButton topicoSenha;
    @FXML private ToggleButton topicoEntrar;
    @FXML private ToggleButton topicoRegras;
    @FXML private ToggleButton topicoPerfil;
    @FXML private Label ajudaTitulo;
    @FXML private Label ajudaTexto;

    @FXML
    public void initialize() {
        // Ajuda: sempre um assunto selecionado.
        grupoAjuda.selectedToggleProperty().addListener((obs, antigo, novo) -> {
            if (novo == null && antigo != null) {
                antigo.setSelected(true);
                return;
            }
            atualizarAjuda();
        });
        atualizarAjuda();
    }

    @Override
    public void aoMudarTema() {
        estilizarCartao(telaRecuperacao);
        atualizarAjuda();
    }

    @Override
    public void aoMudarLayout(boolean compacto) {
        telaRecuperacao.setPadding(compacto ? new Insets(24, 20, 24, 20) : new Insets(34, 42, 34, 42));
    }

    /** Abre já no assunto "Esqueci a senha". */
    public void mostrarSenha() {
        topicoSenha.setSelected(true);
    }

    /** Abre já no assunto "Não consigo entrar". */
    public void mostrarProblemasParaEntrar() {
        topicoEntrar.setSelected(true);
    }

    @FXML
    private void voltarLogin() {
        try {
            Navegador.voltarAoLogin();
        } catch (Exception e) {
            e.printStackTrace();
            mostrarMensagem("Login", "Não foi possível voltar ao login.");
        }
    }

    // Mostra apenas a explicação do assunto escolhido.
    private void atualizarAjuda() {
        if (grupoAjuda == null || ajudaTitulo == null || ajudaTexto == null) return;

        Paleta p = paletaAtual();
        for (ToggleButton topico : new ToggleButton[]{topicoSenha, topicoEntrar, topicoRegras, topicoPerfil}) {
            topico.setStyle(estiloPerfil(topico.isSelected(), p));
        }

        Toggle escolhido = grupoAjuda.getSelectedToggle();

        if (escolhido == topicoEntrar) {
            ajudaTitulo.setText("Não consigo entrar");
            ajudaTexto.setText(
                    "1. Digite o nome de usuário ou e-mail completo, sem espaços no início ou no fim.\n\n" +
                    "2. A senha diferencia maiúsculas e minúsculas. Confira o Caps Lock e o idioma do teclado.\n\n" +
                    "3. Use o ícone de olho para revisar a senha digitada.\n\n" +
                    "4. Se o acesso falhar, confirme se as credenciais administrativas estão corretas.\n\n" +
                    "5. O botão Debug só fica disponível quando o modo desenvolvedor está ativado nas Configurações."
            );
        } else if (escolhido == topicoRegras) {
            ajudaTitulo.setText("Dados da conta administrativa");
            ajudaTexto.setText(
                    "• Use o nome de usuário ou o e-mail cadastrado para a conta administrativa.\n" +
                    "• Digite a senha exatamente como foi definida, respeitando maiúsculas e minúsculas.\n" +
                    "• O cadastro público de novas contas foi desativado."
            );
        } else if (escolhido == topicoPerfil) {
            ajudaTitulo.setText("Acesso administrativo");
            ajudaTexto.setText(
                    "• A tela de login aceita apenas uma conta com permissão de administrador.\n" +
                    "• O acesso ao painel exige credenciais válidas.\n" +
                    "• O atalho Debug é uma ferramenta de desenvolvimento e só aparece quando esse modo está ativado."
            );
        } else {
            ajudaTitulo.setText("Esqueci a senha");
            ajudaTexto.setText(
                    "• Se esqueceu a senha administrativa, procure o responsável técnico pelo sistema para redefini-la.\n\n" +
                    "• Não envie sua senha por mensagem.\n\n" +
                    "• Antes de pedir ajuda, confira o usuário/e-mail, o Caps Lock e o idioma do teclado."
            );
        }
    }
}
