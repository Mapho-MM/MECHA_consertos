package com.senai.javafx.projeto02;

import javafx.application.Application;

/**
 * Ponto de entrada recomendado para rodar com JavaFX modular.
 * Use esta classe como Main Class na IDE / Maven:
 *   com.senai.javafx.projeto02.Launcher
 *
 * Motivo: em módulos JavaFX, chamar Application.launch a partir de uma
 * classe que NÃO estende Application evita erros de "missing JavaFX runtime".
 */
public final class Launcher {

    private Launcher() {
    }

    public static void main(String[] args) {
        Application.launch(HelloApplication.class, args);
    }
}
