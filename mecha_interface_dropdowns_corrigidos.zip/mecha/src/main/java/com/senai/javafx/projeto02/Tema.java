package com.senai.javafx.projeto02;

import javafx.animation.*;
import javafx.application.Platform;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.effect.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.stage.*;
import javafx.util.Duration;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * Motor de temas do sistema: paletas, cores de destaque, Liquid Glass,
 * tamanho da janela e modo desenvolvedor. É compartilhado por todas as telas.
 *
 * Cada tela só precisa implementar {@link TelaController#aoMudarTema()} para
 * ajustar detalhes próprios; o resto (cores de fundo, textos, campos) é
 * traduzido automaticamente a partir do estilo escrito no FXML.
 */
public final class Tema {

    private Tema() {
    }

    private static final AppSingleton app = AppSingleton.getInstance();

    /** Largura abaixo da qual a interface usa o layout compacto. */
    public static final double LARGURA_COMPACTA = 760;

    /*
     * 1 = Claro | 2 = Escuro; opções antigas são migradas para Escuro
     */
    private static int modoTema = 2;

    /*
     * 1 = Azul | 2 = Rosa | 3 = Roxo | 4 = Aurora | 5 = Amarelo | 6 = Padrão
     */
    private static int modoCor = 6;

    /*
     * 0 = Automático (pelo tamanho da janela) | 1 = Computador | 2 = Celular / compacto
     */
    private static int modoLayout = 0;

    /*
     * 0 = Tela cheia | 1 = 1280x720 | 2 = 1440x900 | 3 = 1920x1080
     */
    private static int modoJanela = 0;

    private static boolean modoDebug = false;

    private static Pane liquidAmbient;
    private static Circle liquidGlowBlue;
    private static Circle liquidGlowPurple;
    private static Circle liquidGlowPink;

    // =========================================================
    // PREFERÊNCIAS
    // =========================================================

    /** Lê as preferências salvas. Deve ser chamado uma vez, antes da primeira tela. */
    public static void iniciar() {
        // Sistema usa somente tema escuro. Modo claro e outros foram removidos.
        modoTema = 2;
        app.setModoTema(modoTema);

        // Paleta de cores removida da interface: sempre usa o destaque "Padrão"
        // (botões brancos no escuro e pretos no claro).
        modoCor = 6;
        app.setModoCor(6);

        modoLayout = app.getModoLayout();
        if (modoLayout < 0 || modoLayout > 2) {
            modoLayout = 0;
            app.setModoLayout(modoLayout);
        }

        modoJanela = app.getModoJanela();
        if (modoJanela < 0 || modoJanela > 3) {
            modoJanela = 0;
            app.setModoJanela(modoJanela);
        }

        // O modo desenvolvedor nunca fica salvo: o programa sempre abre com ele desligado.
        modoDebug = false;
        debugLog("Aplicação iniciada. Tema=" + modoTema + ", janela=" + modoJanela);
    }

    public static int modoTema() { return modoTema; }
    public static int modoCor() { return modoCor; }
    public static int modoLayout() { return modoLayout; }
    public static int modoJanela() { return modoJanela; }
    public static boolean modoDebug() { return modoDebug; }

    public static void definirTema(int tema) {
        // Apenas tema escuro é permitido
        modoTema = 2;
        app.setModoTema(modoTema);
        debugLog("Tema fixo em escuro (pedido modo=" + tema + " ignorado se diferente de 2)");
        aplicarTemaSuave();
    }

    /** Mantido por compatibilidade; a UI de paleta foi removida e a cor fica fixa. */
    public static void definirCor(int cor) {
        modoCor = 6;
        app.setModoCor(6);
        debugLog("Paleta de cores desativada; mantendo destaque padrão.");
        aplicarTemaSuave();
    }

    public static void definirLayout(int modo) {
        modoLayout = modo;
        app.setModoLayout(modoLayout);
        Navegador.atualizarLayout();
    }

    /**
     * Liga/desliga o modo desenvolvedor. Enquanto ativo, NADA é gravado no disco
     * (preferências, contas, foto, cadastros da oficina, chat). Ao desligar, tudo
     * o que foi mexido durante o teste é descartado e os dados salvos voltam.
     */
    public static void definirDebug(boolean ativo) {
        boolean antes = modoDebug;
        modoDebug = ativo;
        if (antes && !ativo) {
            descartarAlteracoesDeTeste();
        }
        debugLog(ativo ? "Modo desenvolvedor ATIVADO (nada será salvo)." : "Modo desenvolvedor DESATIVADO.");
    }

    private static void descartarAlteracoesDeTeste() {
        try {
            Armazenamento.get().descartarSombra();
            com.senai.javafx.projeto02.entidades.PersistenciaOficina.recarregarDoDisco();
            ChatService.recarregarDoDisco();
            // Volta tema/layout/janela para o que estava salvo.
            // Tema permanece sempre escuro
            modoTema = 2;
            app.setModoTema(2);
            modoLayout = app.getModoLayout();
            modoJanela = app.getModoJanela();
            aplicarTema();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void definirTamanhoJanela(int modo) {
        modoJanela = modo;
        app.setModoJanela(modoJanela);
        debugLog("Tamanho da janela alterado para modo=" + modo);

        try {
            StackPane raiz = Navegador.raiz();
            if (raiz != null && raiz.getScene() != null && raiz.getScene().getWindow() instanceof Stage principal) {
                aplicarTamanhoJanela(principal);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static final DateTimeFormatter DEBUG_FORMATO = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    /** Registro centralizado para que todas as telas usem o mesmo padrão de diagnóstico. */
    public static void debugLog(String mensagem) {
        if (modoDebug) {
            System.out.println("[DEBUG " + DEBUG_FORMATO.format(LocalDateTime.now()) + "]"
                    + " [" + Thread.currentThread().getName() + "] " + mensagem);
        }
    }

    /** Registra exceções com contexto sem depender de printStackTrace espalhado pelas telas. */
    public static void debugErro(String contexto, Throwable erro) {
        if (!modoDebug || erro == null) return;
        System.err.println("[DEBUG-ERRO " + DEBUG_FORMATO.format(LocalDateTime.now()) + "] "
                + "[" + Thread.currentThread().getName() + "] " + contexto + ": "
                + erro.getClass().getSimpleName() + " - " + erro.getMessage());
        erro.printStackTrace(System.err);
    }

    // =========================================================
    // TELA CHEIA (F11)
    // =========================================================

    private static final String TEXTO_SAIR_TELA_CHEIA = "Pressione F11 ou ESC para sair da tela cheia";

    /** Liga/desliga a tela cheia da janela principal (atalho F11). Não altera a preferência salva. */
    public static void alternarTelaCheia() {
        StackPane raiz = Navegador.raiz();
        if (raiz == null || raiz.getScene() == null) return;
        if (raiz.getScene().getWindow() instanceof Stage principal) {
            principal.setFullScreenExitHint(TEXTO_SAIR_TELA_CHEIA);
            principal.setFullScreen(!principal.isFullScreen());
        }
    }

    /** F11 alterna a tela cheia em qualquer tela do sistema. */
    public static void instalarAtalhoTelaCheia(Scene cena) {
        if (cena == null || cena.getProperties().containsKey("mecha.f11")) return;
        cena.getProperties().put("mecha.f11", Boolean.TRUE);
        cena.addEventFilter(javafx.scene.input.KeyEvent.KEY_PRESSED, evento -> {
            if (evento.getCode() == javafx.scene.input.KeyCode.F11) {
                alternarTelaCheia();
                evento.consume();
            }
        });
    }

    /** Ao sair da tela cheia, garante uma janela de tamanho confortável (e não minúscula). */
    public static void instalarRetornoDaTelaCheia(Stage stage) {
        stage.fullScreenProperty().addListener((obs, estava, esta) -> {
            if (esta) return;
            Platform.runLater(() -> {
                try {
                    Rectangle2D area = areaUtilDoMonitor(stage);
                    double largura = Math.min(1280, area.getWidth());
                    double altura = Math.min(760, area.getHeight());
                    if (stage.getWidth() < 1200 || stage.getHeight() < 700) {
                        stage.setWidth(largura);
                        stage.setHeight(altura);
                        stage.setX(area.getMinX() + (area.getWidth() - largura) / 2.0);
                        stage.setY(area.getMinY() + (area.getHeight() - altura) / 2.0);
                    }
                } catch (Exception ignorado) {
                }
            });
        });
    }

    public static void aplicarPreferenciaDeJanela(Stage stage) {
        aplicarTamanhoJanela(stage);
    }

    public static void aplicarTamanhoJanela(Stage stage) {
        if (stage == null) return;

        try {
            stage.setFullScreenExitHint(TEXTO_SAIR_TELA_CHEIA);
            stage.setMaximized(false);

            if (modoJanela == 0) {
                // Centraliza primeiro e deixa o sistema operacional escolher
                // automaticamente o monitor/resolução para o fullscreen.
                stage.setFullScreen(false);
                stage.centerOnScreen();

                Platform.runLater(() -> {
                    try {
                        stage.setFullScreen(true);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        // Fallback: maximizado ocupa toda a área útil do monitor.
                        maximizarNoMonitorAtual(stage);
                    }
                });
                return;
            }

            stage.setFullScreen(false);

            Rectangle2D area = areaUtilDoMonitor(stage);
            double largura;
            double altura;

            switch (modoJanela) {
                case 1 -> { largura = 1280; altura = 720; }
                case 2 -> { largura = 1440; altura = 900; }
                case 3 -> { largura = 1920; altura = 1080; }
                default -> { largura = area.getWidth(); altura = area.getHeight(); }
            }

            // Nunca deixa uma configuração fixa ficar maior que o monitor atual.
            largura = Math.min(largura, area.getWidth());
            altura = Math.min(altura, area.getHeight());

            stage.setWidth(largura);
            stage.setHeight(altura);
            stage.setX(area.getMinX() + (area.getWidth() - largura) / 2.0);
            stage.setY(area.getMinY() + (area.getHeight() - altura) / 2.0);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Rectangle2D areaUtilDoMonitor(Stage stage) {
        try {
            double x = stage.isShowing() ? stage.getX() : 0;
            double y = stage.isShowing() ? stage.getY() : 0;
            double w = Math.max(stage.getWidth(), 1);
            double h = Math.max(stage.getHeight(), 1);

            return Screen.getScreensForRectangle(x, y, w, h).stream()
                    .findFirst()
                    .map(Screen::getVisualBounds)
                    .orElseGet(() -> Screen.getPrimary().getVisualBounds());
        } catch (Exception e) {
            e.printStackTrace();
            return Screen.getPrimary().getVisualBounds();
        }
    }

    public static void maximizarNoMonitorAtual(Stage stage) {
        try {
            Rectangle2D area = areaUtilDoMonitor(stage);
            stage.setFullScreen(false);
            stage.setMaximized(false);
            stage.setX(area.getMinX());
            stage.setY(area.getMinY());
            stage.setWidth(area.getWidth());
            stage.setHeight(area.getHeight());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // =========================================================
    // LAYOUT ADAPTÁVEL (computador / celular)
    // =========================================================

    public static boolean layoutCompacto() {
        if (modoLayout == 1) return false;
        if (modoLayout == 2) return true;

        StackPane raiz = Navegador.raiz();
        Scene cena = raiz == null ? null : raiz.getScene();
        return cena != null && cena.getWidth() < LARGURA_COMPACTA;
    }

    // =========================================================
    // APLICAÇÃO DO TEMA
    // =========================================================

    /** Aplica o tema de imediato (sem snapshot — evita travar a interface). */
    public static void aplicarTemaSuave() {
        aplicarTema();
    }

    /** Reaplica o tema em toda a interface: fundo, ambiente Liquid Glass, tela atual e carregamento. */
    public static void aplicarTema() {
        StackPane raiz = Navegador.raiz();
        if (raiz == null) return;

        Paleta p = paletaAtual();
        raiz.setStyle("-fx-background-color: " + p.fundoApp() + ";");

        // Classe global para CSS de tabela/combo no tema atual
        raiz.getStyleClass().removeAll("tema-escuro", "tema-claro", "tema-dinamico");
        int te = temaEfetivo();
        String classeTema = te == 1 ? "tema-claro" : "tema-escuro";
        raiz.getStyleClass().add(classeTema);
        if (raiz.getScene() != null) {
            raiz.getScene().getRoot().getStyleClass().removeAll("tema-escuro", "tema-claro", "tema-dinamico");
            raiz.getScene().getRoot().getStyleClass().add(classeTema);
        }

        // Liquid Glass removido — não cria camada ambiente (evita custo extra)
        if (liquidAmbient != null) {
            liquidAmbient.setVisible(false);
        }

        aplicarNaTelaAtual();

        CarregandoController carregando = Navegador.carregamento();
        if (carregando != null) carregando.estilizar();
    }

    /**
     * Traduz o estilo do FXML da tela atual para a paleta escolhida e depois
     * deixa a própria tela fazer seus ajustes ({@link TelaController#aoMudarTema()}).
     */
    public static void aplicarNaTelaAtual() {
        Parent tela = Navegador.telaAtual();
        if (tela == null) return;

        guardarEstilosBase(tela);
        removerClassesLiquidGlass(tela);
        aplicarEstiloAdaptado(tela);

        if (Navegador.controladorAtual() instanceof TelaController controlador) {
            controlador.aoMudarTema();
        }

        // O botão principal de cada tela recebe a cor de destaque escolhida.
        aplicarCorAcentoNosBotoes(tela);
    }

    /** Estilo padrão dos cartões de login / cadastro / ajuda. */
    public static void estilizarCartao(Node cartaoNo) {
        if (cartaoNo == null) return;
        Paleta p = paletaAtual();
        String cartao = temaLiquid()
                ? "-fx-background-color: linear-gradient(to bottom, rgba(255,255,255,0.62), rgba(250,252,255,0.34));" +
                  "-fx-background-radius: 30;" +
                  "-fx-border-color: rgba(255,255,255,0.82);" +
                  "-fx-border-radius: 30;" +
                  "-fx-border-width: 1;" +
                  "-fx-effect: dropshadow(gaussian, rgba(24,34,52,0.20), 32, 0.18, 0, 14);"
                : "-fx-background-color: " + p.fundoCartao() + ";" +
                  "-fx-background-radius: 28;" +
                  "-fx-border-color: " + p.borda() + ";" +
                  "-fx-border-radius: 28;" +
                  "-fx-border-width: 1;";
        cartaoNo.setStyle(cartao);
    }

    // =========================================================
    // PALETAS
    // =========================================================

    public record Paleta(
            String fundoApp,      // fundo da janela principal
            String fundoJanela,   // fundo dos pop-ups (configurações, avisos)
            String fundoCartao,   // cartões de login / cadastro / recuperação
            String borda,
            String overlay,       // prefixo rgba usado em campos e botões translúcidos
            String texto,
            String textoSec,
            String textoTerc,
            String botaoFundo,    // botão primário
            String botaoTexto,
            String link,
            String erro
    ) {}

    public record CoresTema(
            String primario,
            String secundario,
            String fundoClaro,
            String janelaClaro,
            String cartaoClaro,
            String bordaClaro,
            String fundoEscuro,
            String janelaEscuro,
            String cartaoEscuro,
            String bordaEscuro
    ) {}

    public static CoresTema coresDaPaleta() {
        return switch (modoCor) {
            case 2 -> new CoresTema(
                    "#ff4f9a", "#ff87bc",
                    "linear-gradient(to bottom right, #fbf3f7, #f7edf3, #f2e8ef)",
                    "#fcf7fa", "#f9f1f6", "rgba(182,72,125,0.16)",
                    "linear-gradient(to bottom right, #160d14, #24121d, #100b10)",
                    "#1b1119", "#1d111b", "rgba(255,110,174,0.20)"
            );
            case 3 -> new CoresTema(
                    "#8b5cf6", "#b78cff",
                    "linear-gradient(to bottom right, #f8f5fc, #f2edf9, #ece7f5)",
                    "#faf8fd", "#f5f0fa", "rgba(110,82,174,0.16)",
                    "linear-gradient(to bottom right, #110d18, #1c1229, #0d0a12)",
                    "#17101f", "#1b1224", "rgba(164,126,255,0.20)"
            );
            case 4 -> new CoresTema(
                    "#7c5cff", "#ff4f9a",
                    "linear-gradient(to bottom right, #edf4ff 0%, #f2efff 45%, #fff0f8 100%)",
                    "#fbf9ff", "#f7f3ff", "rgba(116,96,190,0.18)",
                    "linear-gradient(to bottom right, #0c1220 0%, #171126 48%, #220f1e 100%)",
                    "#141326", "#18132a", "rgba(164,126,255,0.24)"
            );
            case 5 -> new CoresTema(
                    "#e0a500", "#ffd45a",
                    "linear-gradient(to bottom right, #fffaf0 0%, #fff7df 48%, #fff2c2 100%)",
                    "#fffaf0", "#fff6df", "rgba(194,142,0,0.18)",
                    "linear-gradient(to bottom right, #201a0b 0%, #2b2410 48%, #17130a 100%)",
                    "#28200d", "#2c2410", "rgba(255,210,70,0.20)"
            );
            case 6 -> new CoresTema(
                    "#f5f5f7", "#ffffff",
                    // Claro suave: cinza-pérola
                    "linear-gradient(to bottom right, #e7e8ec, #e1e3e8, #dcdde3)",
                    "#eceef2", "#e9ebef", "rgba(32,38,52,0.13)",
                    // Escuro clássico: preto/grafite
                    "linear-gradient(to bottom right, #0d0d0f, #151517, #09090a)",
                    "#161618", "#18181a", "rgba(255,255,255,0.18)"
            );
            default -> new CoresTema(
                    "#1473e6", "#63a4ff",
                    "linear-gradient(to bottom right, #f4f5f7, #eef0f3, #e8eaee)",
                    "#fafbfc", "#f5f6f8", "rgba(40,44,52,0.12)",
                    // Escuro verdadeiro (preto/grafite), sem tom azul
                    "linear-gradient(to bottom right, #0a0a0a, #121212, #0d0d0d)",
                    "#141414", "#1a1a1a", "rgba(255,255,255,0.12)"
            );
        };
    }

    public static Paleta criarPaletaAtual(int tema) {
        CoresTema c = coresDaPaleta();

        if (tema == 1) {
            // Claro moderno
            String prim = (modoCor == 6) ? "#20242b" : c.primario();
            return new Paleta(
                    c.fundoClaro(), c.janelaClaro(), c.cartaoClaro(),
                    c.bordaClaro(), "rgba(30,36,50,",
                    "#232830", "#4b5362", "#6b7382",
                    prim, "#f6f7f9", prim, "#c9362b"
            );
        }

        // Escuro com cartões em vidro (transparente)
        String prim = (modoCor == 6) ? "#f5f5f7" : c.primario();
        String btnTxt = (modoCor == 6) ? "#111111" : "#f6f7f9";
        return new Paleta(
                c.fundoEscuro(),
                "rgba(12,16,28,0.72)",          // janela/pop-ups em vidro
                "rgba(18,22,36,0.55)",          // cartões transparentes
                "rgba(255,255,255,0.12)",
                "rgba(255,255,255,",
                "#f5f5f5", "#d0d0d0", "#a8a8a8",
                prim, btnTxt, (modoCor == 6 ? prim : c.secundario()), "#ff7385"
        );
    }

    public static int temaEfetivo() {
        // Sistema usa somente tema escuro
        return 2;
    }

    public static Paleta paletaAtual() {
        return criarPaletaAtual(temaEfetivo());
    }

    /** Liquid Glass foi removido; mantido só por compatibilidade (sempre false). */
    public static boolean temaLiquid() {
        return false;
    }

    // Cor neutra da paleta "Padrão": acompanha o tema claro/escuro.
    public static String destaqueNeutro() {
        return temaEfetivo() == 2 ? "#f5f5f7" : "#20242b";
    }

    // Cor do texto/ícone sobre fundos de destaque (preto sobre branco, branco nos demais).
    public static String textoSobreDestaque() {
        return (modoCor == 6 && temaEfetivo() == 2) ? "#111111" : "#f6f7f9";
    }

    public static String corDestaque() {
        return switch (modoCor) {
            case 6 -> destaqueNeutro();
            case 2 -> "#ff4f9a";
            case 3 -> "#8b5cf6";
            case 4 -> "#7c5cff";
            case 5 -> "#e0a500";
            default -> "#1473e6";
        };
    }

    public static String fundoDestaque() {
        return switch (modoCor) {
            case 6 -> destaqueNeutro();
            case 2 -> "#ff4f9a";
            case 3 -> "#8b5cf6";
            case 4 -> "linear-gradient(to right, #3b82f6 0%, #7c5cff 50%, #ff4f9a 100%)";
            case 5 -> "#e0a500";
            default -> "#1473e6";
        };
    }

    public static String degradeDestaque() {
        return switch (modoCor) {
            case 6 -> temaEfetivo() == 2
                    ? "linear-gradient(to right, #ffffff, #c9ccd3)"
                    : "linear-gradient(to right, #000000, #3a3d44)";
            case 2 -> "linear-gradient(to right, #ff6aa9, #ff4f9a)";
            case 3 -> "linear-gradient(to right, #7c5cff, #a855f7)";
            case 4 -> "linear-gradient(to right, #3b82f6 0%, #7c5cff 50%, #ff4f9a 100%)";
            case 5 -> "linear-gradient(to right, #e0a500, #ffd45a)";
            default -> "linear-gradient(to right, #1473e6, #4f9cff)";
        };
    }

    public static String nomeTemaAtual() {
        return switch (modoTema) {
            case 1 -> "Claro";
            case 2 -> "Escuro";
                        default -> "Padrão";
        };
    }

    public static String nomePaletaAtual() {
        return switch (modoCor) {
            case 2 -> "Rosa";
            case 3 -> "Roxo";
            case 4 -> "Aurora — azul, roxo e rosa";
            case 5 -> "Amarelo";
            case 6 -> "Padrão — branco no escuro, preto no claro";
            default -> "Azul";
        };
    }

    public static String nomeTamanhoJanelaAtual() {
        return switch (modoJanela) {
            case 1 -> "1280 × 720";
            case 2 -> "1440 × 900";
            case 3 -> "1920 × 1080";
            default -> "Tela cheia — monitor detectado automaticamente";
        };
    }

    // =========================================================
    // LIQUID GLASS
    // =========================================================

    /**
     * Liquid Glass: material reservado à navegação e controles importantes.
     * Em JavaFX, a sensação é simulada com translucidez, brilho, sombra e
     * uma camada de luz ambiente desfocada atrás dos elementos.
     */
    public static void estilizarNavegacaoLiquidGlass(VBox dashboard, VBox menu) {
        if (dashboard == null) return;

        if (!dashboard.getChildren().isEmpty() && dashboard.getChildren().get(0) instanceof HBox header) {
            header.setStyle(
                    "-fx-background-color: transparent;" +
                    "-fx-border-color: transparent;" +
                    "-fx-background-radius: 0;" +
                    "-fx-padding: 12 18 10 18;"
            );
            aplicarEstiloBotoesHeader(header);
        }

        if (menu != null) {
            menu.setStyle(
                    "-fx-background-color: linear-gradient(to bottom, rgba(255,255,255,0.72), rgba(248,250,255,0.30));" +
                    "-fx-background-radius: 30;" +
                    "-fx-border-color: rgba(255,255,255,0.84);" +
                    "-fx-border-radius: 30;" +
                    "-fx-border-width: 1;" +
                    "-fx-padding: 18;" +
                    "-fx-effect: dropshadow(gaussian, rgba(20,30,48,0.24), 34, 0.20, 0, 14);"
            );
            estilizarItensMenuLiquidGlass(menu);
        }
    }

    public static void aplicarEstiloBotoesHeader(HBox header) {
        for (Node filho : header.getChildren()) {
            if (filho instanceof Button botao) {
                // Ícones de busca/perfil/voltar ficam em pequenos platters separados.
                String texto = botao.getText() == null ? "" : botao.getText();
                boolean ferramenta = texto.contains("🔍") || texto.contains("👤") || texto.equals("←") || texto.equals("☰");
                if (ferramenta) {
                    botao.setStyle(
                            "-fx-background-color: linear-gradient(to bottom, rgba(255,255,255,0.72), rgba(255,255,255,0.28));" +
                            "-fx-background-radius: 16;" +
                            "-fx-border-color: rgba(255,255,255,0.82);" +
                            "-fx-border-radius: 16;" +
                            "-fx-border-width: 1;" +
                            "-fx-text-fill: #172033;" +
                            "-fx-effect: dropshadow(gaussian, rgba(25,35,52,0.10), 12, 0.14, 0, 4);" +
                            "-fx-cursor: hand;"
                    );
                }
            }
        }
    }

    public static void estilizarItensMenuLiquidGlass(VBox menu) {
        for (Node filho : menu.getChildren()) {
            if (filho instanceof Button botao) {
                String texto = botao.getText() == null ? "" : botao.getText();
                boolean configuracao = texto.contains("Configurações");
                botao.setStyle(
                        "-fx-background-color: " + (configuracao ? "rgba(255,255,255,0.34)" : "transparent") + ";" +
                        "-fx-background-radius: 15;" +
                        "-fx-border-color: " + (configuracao ? "rgba(255,255,255,0.56)" : "transparent") + ";" +
                        "-fx-border-radius: 15;" +
                        "-fx-border-width: 1;" +
                        "-fx-text-fill: #182236;" +
                        "-fx-alignment: CENTER_LEFT;" +
                        "-fx-font-size: 14px;" +
                        "-fx-cursor: hand;"
                );
                botao.setOnMouseEntered(e -> botao.setStyle(
                        "-fx-background-color: rgba(255,255,255,0.28);" +
                        "-fx-background-radius: 15;" +
                        "-fx-border-color: rgba(255,255,255,0.52);" +
                        "-fx-border-radius: 15;" +
                        "-fx-border-width: 1;" +
                        "-fx-text-fill: #182236;" +
                        "-fx-alignment: CENTER_LEFT;" +
                        "-fx-font-size: 14px;" +
                        "-fx-cursor: hand;"
                ));
                botao.setOnMouseExited(e -> botao.setStyle(
                        "-fx-background-color: " + (configuracao ? "rgba(255,255,255,0.34)" : "transparent") + ";" +
                        "-fx-background-radius: 15;" +
                        "-fx-border-color: " + (configuracao ? "rgba(255,255,255,0.56)" : "transparent") + ";" +
                        "-fx-border-radius: 15;" +
                        "-fx-border-width: 1;" +
                        "-fx-text-fill: #182236;" +
                        "-fx-alignment: CENTER_LEFT;" +
                        "-fx-font-size: 14px;" +
                        "-fx-cursor: hand;"
                ));
            }
        }
    }

    public static void criarAmbienteLiquidGlass() {
        StackPane root = Navegador.raiz();
        if (root == null || liquidAmbient != null) return;

        liquidAmbient = new Pane();
        liquidAmbient.setMouseTransparent(true);
        liquidAmbient.setManaged(false);
        liquidAmbient.setVisible(false);
        liquidAmbient.setPickOnBounds(false);

        liquidGlowBlue = criarGlow("#4f8cff", 220);
        liquidGlowPurple = criarGlow("#8d7bff", 190);
        liquidGlowPink = criarGlow("#ff78bc", 190);
        liquidAmbient.getChildren().addAll(liquidGlowBlue, liquidGlowPurple, liquidGlowPink);
        root.getChildren().add(0, liquidAmbient);

        root.widthProperty().addListener((obs, oldVal, newVal) -> posicionarAmbienteLiquidGlass());
        root.heightProperty().addListener((obs, oldVal, newVal) -> posicionarAmbienteLiquidGlass());
        posicionarAmbienteLiquidGlass();
    }

    public static Circle criarGlow(String cor, double raio) {
        Circle c = new Circle(raio);
        c.setFill(new RadialGradient(
                0, 0, 0.5, 0.5, 1, true, CycleMethod.NO_CYCLE,
                new Stop(0.0, Color.web(cor, 0.36)),
                new Stop(0.48, Color.web(cor, 0.14)),
                new Stop(1.0, Color.TRANSPARENT)
        ));
        c.setEffect(new GaussianBlur(50));
        return c;
    }

    public static void posicionarAmbienteLiquidGlass() {
        StackPane root = Navegador.raiz();
        if (liquidAmbient == null || root == null) return;
        double w = Math.max(root.getWidth(), 1200);
        double h = Math.max(root.getHeight(), 700);
        liquidAmbient.resizeRelocate(0, 0, w, h);

        liquidGlowBlue.setLayoutX(w * 0.78);
        liquidGlowBlue.setLayoutY(h * 0.22);
        liquidGlowPurple.setLayoutX(w * 0.34);
        liquidGlowPurple.setLayoutY(h * 0.76);
        liquidGlowPink.setLayoutX(w * 0.60);
        liquidGlowPink.setLayoutY(h * 0.60);
    }

    public static void atualizarAmbienteLiquidGlass() {
        if (liquidAmbient == null) return;
        liquidAmbient.setVisible(temaLiquid());
        liquidAmbient.toBack();
        posicionarAmbienteLiquidGlass();
    }

    public static void removerClassesLiquidGlass(Node no) {
        if (no == null) return;
        removerClasse(no, "liquid-glass-control");
        removerClasse(no, "liquid-glass-button");
        removerClasse(no, "liquid-glass-navigation");
        if (no instanceof Parent pai) {
            for (Node filho : pai.getChildrenUnmodifiable()) {
                removerClassesLiquidGlass(filho);
            }
        }
    }

    public static void adicionarClasse(Node no, String classe) {
        if (no != null && !no.getStyleClass().contains(classe)) {
            no.getStyleClass().add(classe);
        }
    }

    public static void removerClasse(Node no, String classe) {
        if (no != null) {
            no.getStyleClass().remove(classe);
        }
    }

    // Guarda o estilo escrito no FXML de cada componente (ponto de partida dos temas).
    public static void guardarEstilosBase(Node no) {
        if (ignoradoPeloTema(no)) return;
        no.getProperties().putIfAbsent("estiloBase", no.getStyle() == null ? "" : no.getStyle());

        if (no instanceof Parent pai) {
            for (Node filho : pai.getChildrenUnmodifiable()) {
                guardarEstilosBase(filho);
            }
        }
    }

    /**
     * Áreas marcadas com "mecha.semTema" (conteúdo dos painéis) são refeitas do zero
     * pelo controller ao trocar de tema; traduzir o estilo antigo delas só misturava cores.
     */
    public static boolean ignoradoPeloTema(Node no) {
        return no != null && no.getProperties().containsKey("mecha.semTema");
    }

    public static void aplicarEstiloAdaptado(Node no) {
        if (ignoradoPeloTema(no)) return;
        Object base = no.getProperties().get("estiloBase");

        if (base instanceof String estilo && !estilo.isBlank()) {
            no.setStyle(adaptarEstilo(estilo));
        }

        // Controles que o FXML não estiliza por completo (TableView, ComboBox)
        estilizarControleNativo(no);

        if (no instanceof Parent pai) {
            for (Node filho : pai.getChildrenUnmodifiable()) {
                aplicarEstiloAdaptado(filho);
            }
        }
    }

    /** Estilo inline de fallback para TableView/Combo quando o CSS da Scene ainda não pegou. */
    public static void estilizarControleNativo(Node no) {
        if (no == null) return;
        Paleta p = paletaAtual();
        int te = temaEfetivo();
        if (no instanceof javafx.scene.control.TableView<?> tv) {
            if (te == 1) {
                tv.setStyle(
                        "-fx-background-color: #f3f4f7;" +
                        "-fx-control-inner-background: #f3f4f7;" +
                        "-fx-table-cell-border-color: #dfe1e7;" +
                        "-fx-text-background-color: #232830;" +
                        "-fx-background-radius: 12;"
                );
            } else {
                tv.setStyle(
                        "-fx-background-color: #141414;" +
                        "-fx-control-inner-background: #141414;" +
                        "-fx-table-cell-border-color: #2a2a2a;" +
                        "-fx-text-background-color: #f0f0f0;" +
                        "-fx-background-radius: 12;"
                );
            }
        } else if (no instanceof javafx.scene.control.ComboBox<?> cb) {
            String txt = te == 1 ? "#232830" : "#f0f0f0";
            String bg = te == 1 ? "#f3f4f7" : "#1c1c1c";
            cb.setStyle("-fx-background-color: " + bg + "; -fx-text-fill: " + txt + "; -fx-background-radius: 10;");
            final String corTxt = txt;
            @SuppressWarnings({"unchecked", "rawtypes"})
            javafx.scene.control.ListCell cell = new javafx.scene.control.ListCell() {
                @Override protected void updateItem(Object item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.toString());
                    setTextFill(javafx.scene.paint.Color.web(corTxt));
                    setStyle("-fx-text-fill: " + corTxt + ";");
                }
            };
            // Só aplica se ainda não houver button cell customizado legível
            if (cb.getButtonCell() == null) {
                cb.setButtonCell(cell);
            }
        }
    }

    // Traduz as cores do FXML (feito no tema escuro) para a paleta atual.
    public static String adaptarEstilo(String base) {
        Paleta p = paletaAtual();
        StringBuilder resultado = new StringBuilder();

        for (String declaracao : base.split(";")) {
            int separador = declaracao.indexOf(':');
            if (separador < 0) continue;

            String nome = declaracao.substring(0, separador).trim();
            String valor = declaracao.substring(separador + 1).trim().replaceAll("\\s+", " ");

            switch (nome) {
                case "-fx-text-fill" -> valor = traduzirCorTexto(valor, p);
                case "-fx-prompt-text-fill" -> valor = p.textoTerc();
                case "-fx-background-color" -> {
                    if (valor.equals("#0b0b0f") || valor.equals("#000000") || valor.equals("black")) {
                        valor = p.fundoApp();
                    } else if (valor.equals("white") || valor.equals("#ffffff") || valor.equals("#fff")) {
                        valor = p.botaoFundo();
                    } else if (valor.startsWith("rgba(255,255,255,")) {
                        // Superfícies translúcidas seguem o overlay do tema atual
                        valor = valor.replace("rgba(255,255,255,", p.overlay());
                    }
                }
                default -> { }
            }

            valor = valor.replace("rgba(255,255,255,", p.overlay());
            resultado.append(nome).append(": ").append(valor).append(";");
        }

        return resultado.toString();
    }

    public static String traduzirCorTexto(String cor, Paleta p) {
        return switch (cor) {
            case "white", "#f2f2f2", "#f6f8fb", "#ffffff" -> p.texto();
            case "#111111" -> p.botaoTexto();
            // Itens de menu: contraste alto nos dois temas
            case "#cccccc", "#bbbbbb", "#aaaaaa", "#999999", "#dddddd", "#d8d8d8" -> p.textoSec();
            case "#888888", "#777777", "#666666", "#555555", "#a0a0a0" -> p.textoTerc();
            case "#ff7070" -> p.erro();
            case "#4aa8ff" -> corDestaque();
            default -> cor;
        };
    }

    public static void aplicarCorAcentoNosBotoes(Node no) {
        if (ignoradoPeloTema(no)) return;
        if (no instanceof Button botao) {
            String estiloBase = (String) botao.getProperties().get("estiloBase");
            if (estiloBase != null && estiloBase.contains("-fx-background-color: white")) {
                Paleta p = paletaAtual();
                botao.setStyle(
                        "-fx-background-color: " + fundoDestaque() + ";" +
                        "-fx-background-radius: 25;" +
                        "-fx-text-fill: " + p.botaoTexto() + ";" +
                        "-fx-font-size: 15px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-cursor: hand;"
                );
            }
        }
        if (no instanceof Parent pai) {
            for (Node filho : pai.getChildrenUnmodifiable()) {
                aplicarCorAcentoNosBotoes(filho);
            }
        }
    }


    /**
     * Chave da seção atualmente selecionada no menu lateral (ex.: "Financeiro").
     * Usada para destacar o item ativo com contraste azul-escuro / azul-claro.
     */
    private static String menuSecaoSelecionada = "";

    public static void definirSecaoMenuSelecionada(String secao) {
        menuSecaoSelecionada = secao == null ? "" : secao.trim();
    }

    public static String secaoMenuSelecionada() {
        return menuSecaoSelecionada == null ? "" : menuSecaoSelecionada;
    }

    /**
     * Itens do menu lateral com "bolinha" de fundo (pílula),
     * no mesmo espírito do botão Configurações e dos cards de tema.
     * O item cuja legenda contém a seção selecionada recebe destaque azul vibrante.
     */
    public static void estilizarItensMenuLateral(VBox menu) {
        if (menu == null) return;
        Paleta p = paletaAtual();
        boolean claro = temaEfetivo() == 1;
        String fundoPainel = claro ? "rgba(255,255,255,0.92)" : "rgba(255,255,255,0.045)";
        String bordaPainel = p.borda();
        menu.setStyle(
                "-fx-background-color: " + fundoPainel + ";" +
                "-fx-background-radius: 24;" +
                "-fx-border-color: " + bordaPainel + ";" +
                "-fx-border-radius: 24;" +
                "-fx-border-width: 1;" +
                "-fx-padding: 18;"
        );

        String sel = secaoMenuSelecionada().toLowerCase(Locale.ROOT);
        for (Node filho : menu.getChildren()) {
            if (!(filho instanceof Button botao)) continue;
            String texto = botao.getText() == null ? "" : botao.getText();
            boolean config = texto.contains("Configurações");
            boolean selecionado = !sel.isEmpty() && texto.toLowerCase(Locale.ROOT).contains(sel);
            String fundoNormal;
            String fundoHover;
            String corTexto;
            String peso;

            if (selecionado) {
                fundoNormal = claro ? "#1e3a8a" : "#2563eb";
                fundoHover = claro ? "#1e40af" : "#3b82f6";
                corTexto = claro ? "#dbeafe" : "#ffffff";
                peso = "bold";
            } else {
                fundoNormal = claro
                        ? (config ? "rgba(30,36,50,0.10)" : "rgba(30,36,50,0.05)")
                        : (config ? "rgba(255,255,255,0.12)" : "rgba(255,255,255,0.07)");
                fundoHover = claro ? "rgba(30,36,50,0.12)" : "rgba(255,255,255,0.14)";
                corTexto = p.texto();
                peso = "normal";
            }

            // O botão Configurações usa uma única regra semântica; não instale
            // handlers de hover concorrentes que sobrescrevam seu estilo.
            if (config) {
                aplicarEstiloSemantico(botao);
                continue;
            }

            final String fn = fundoNormal;
            final String fh = fundoHover;
            String base =
                    "-fx-background-radius: 14;" +
                    "-fx-border-radius: 14;" +
                    "-fx-border-width: 0;" +
                    "-fx-text-fill: " + corTexto + ";" +
                    "-fx-font-weight: " + peso + ";" +
                    "-fx-alignment: CENTER_LEFT;" +
                    "-fx-font-size: " + (config ? "13px" : "14px") + ";" +
                    "-fx-cursor: hand;" +
                    "-fx-padding: 0 14 0 14;";
            botao.setStyle("-fx-background-color: " + fn + ";" + base);
            botao.setOnMouseEntered(e -> botao.setStyle("-fx-background-color: " + fh + ";" + base));
            botao.setOnMouseExited(e -> botao.setStyle("-fx-background-color: " + fn + ";" + base));
        }
    }

    public static String estiloPerfil(boolean selecionado, Paleta p) {
        String fundo = selecionado ? fundoDestaque() : p.overlay() + "0.10)";
        String texto = selecionado ? p.botaoTexto() : p.textoSec();

        return "-fx-background-color: " + fundo + ";" +
               "-fx-background-radius: 20;" +
               "-fx-text-fill: " + texto + ";" +
               "-fx-font-size: 13px;" +
               "-fx-font-weight: bold;" +
               "-fx-cursor: hand;";
    }

    /**
     * Cores semânticas de botões — independentes do tema escolhido.
     * Verde=sucesso, Azul=primário, Laranja=edição, Vermelho=perigo, Cinza=navegação.
     */
    public static void aplicarEstiloSemantico(Button b) {
        if (b == null) return;
        String texto = b.getText() == null ? "" : b.getText().toLowerCase(Locale.ROOT);
        String fundo;
        String textoCor;
        String borda;

        if (contemPalavra(texto, "iniciar") || contemPalavra(texto, "finalizar")) {
            // Verde — sucesso / avanço
            fundo = "linear-gradient(to bottom, #22c55e, #16a34a)";
            textoCor = "#ffffff";
            borda = "#15803d";
        } else if (contemPalavra(texto, "novo") || contemPalavra(texto, "nova") || contemPalavra(texto, "atualizar")) {
            // Azul — ação primária
            fundo = "linear-gradient(to bottom, #3b82f6, #2563eb)";
            textoCor = "#ffffff";
            borda = "#1d4ed8";
        } else if (contemPalavra(texto, "editar") || contemPalavra(texto, "recarregar")) {
            // Laranja / amarelo queimado — atenção / modificação
            fundo = "linear-gradient(to bottom, #f59e0b, #d97706)";
            textoCor = "#1a1a1a";
            borda = "#b45309";
        } else if (contemPalavra(texto, "excluir") || contemPalavra(texto, "remover") || contemPalavra(texto, "apagar")) {
            // Vermelho — destrutivo
            fundo = "linear-gradient(to bottom, #ef4444, #dc2626)";
            textoCor = "#ffffff";
            borda = "#b91c1c";
        } else if (contemPalavra(texto, "ver catálogo") || contemPalavra(texto, "ver catalogo")
                || contemPalavra(texto, "voltar") || contemPalavra(texto, "relatórios detalhados")
                || contemPalavra(texto, "relatorios detalhados") || contemPalavra(texto, "configurações")
                || contemPalavra(texto, "configuracoes")) {
            // Cinza grafite — navegação / suporte
            fundo = "linear-gradient(to bottom, #3f3f46, #27272a)";
            textoCor = "#f4f4f5";
            borda = "#52525b";
        } else {
            return; // mantém estilo atual
        }

        String base =
                "-fx-background-color: " + fundo + ";" +
                "-fx-text-fill: " + textoCor + ";" +
                "-fx-background-radius: 18;" +
                "-fx-border-radius: 18;" +
                "-fx-border-color: " + borda + ";" +
                "-fx-border-width: 1;" +
                "-fx-cursor: hand;" +
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-padding: 8 16;";
        b.setStyle(base);
    }

    private static boolean contemPalavra(String textoLower, String palavra) {
        return textoLower != null && textoLower.contains(palavra);
    }

    /** Aplica estilo semântico em todos os botões de uma árvore de nós. */
    public static void aplicarEstiloSemanticoRecursivo(Node raiz) {
        if (raiz == null) return;
        if (raiz instanceof Button btn) aplicarEstiloSemantico(btn);
        if (raiz instanceof Parent parent) {
            for (Node filho : parent.getChildrenUnmodifiable()) {
                aplicarEstiloSemanticoRecursivo(filho);
            }
        }
    }
}
