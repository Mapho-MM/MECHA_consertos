package com.senai.javafx.projeto02;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.net.URL;

public class HelloApplication extends Application {

    @Override
    public void start(Stage stage) {
        // Captura erros não tratados para o console quando o modo debug estiver ativo.
        Thread.setDefaultUncaughtExceptionHandler((thread, erro) ->
                Tema.debugErro("Exceção não tratada na thread " + thread.getName(), erro));
        try {
            URL fxml = HelloApplication.class.getResource(
                    "/com/senai/javafx/projeto02/main-view.fxml"
            );

            if (fxml == null) {
                throw new IllegalStateException(
                        "main-view.fxml não foi encontrado em resources."
                );
            }

            // Preferências (tema, cor, janela...) precisam estar lidas antes da primeira tela.
            Tema.iniciar();

            // Carrega cadastros da oficina (clientes, estoque, serviços...)
            com.senai.javafx.projeto02.entidades.SingleTon.getInstancia();

            FXMLLoader loader = new FXMLLoader(fxml);
            Scene scene = new Scene(loader.<StackPane>load());

            URL css = HelloApplication.class.getResource(
                    "/com/senai/javafx/projeto02/style.css"
            );

            if (css != null) {
                scene.getStylesheets().add(css.toExternalForm());
            }

            stage.setTitle("Sistema de Gestão da Oficina");
            stage.setScene(scene);
            stage.setMinWidth(820);
            stage.setMinHeight(560);
            stage.setFullScreenExitHint(
                    "Pressione F11 ou ESC para sair da tela cheia"
            );

            // F11 liga/desliga a tela cheia em qualquer tela.
            Tema.instalarAtalhoTelaCheia(scene);
            Tema.instalarRetornoDaTelaCheia(stage);

            // A primeira tela é a abertura animada; ela mesma abre o login quando termina.
            Navegador.ir(Navegador.Tela.SPLASH);

            stage.show();

            // Agora o Stage existe de verdade. A preferência de tamanho/tela cheia
            // é aplicada neste momento para que o fullscreen funcione corretamente.
            Platform.runLater(() -> Tema.aplicarPreferenciaDeJanela(stage));

        } catch (Exception e) {
            Tema.debugErro("Falha durante a inicialização da aplicação", e);
            if (!Tema.modoDebug()) e.printStackTrace();
            throw new RuntimeException(
                    "Não foi possível iniciar o sistema da oficina: " + e.getMessage(), e
            );
        }
    }

    public static void main(String[] args) {
        // Preferível: rodar Launcher.main — este main existe só por compatibilidade.
        Launcher.main(args);
    }
}
