package com.senai.javafx.projeto02.entidades;

import java.util.ArrayList;
import java.util.List;

public class Cliente {
    private String nome;
    private String cpf;
    private String telefone;
    private Status status = Status.ORCAMENTO;
    private final ArrayList<Veiculo> carros = new ArrayList<>();

    public Cliente(String nome, String cpf, String telefone) {
        this.nome = nome;
        this.cpf = cpf;
        this.telefone = telefone;
    }

    public String getNome() { return nome; }
    public String getCpf() { return cpf; }
    public String getTelefone() { return telefone; }
    public Status getStatus() { return status; }
    public List<Veiculo> getCarros() { return carros; }

    public void setNome(String nome) { this.nome = nome; }
    public void setCpf(String cpf) { this.cpf = cpf; }
    public void setTelefone(String telefone) { this.telefone = telefone; }
    public void setStatus(Status status) { this.status = status; }

    public void adicionarVeiculo(Veiculo veiculo) {
        if (veiculo != null && !carros.contains(veiculo)) {
            veiculo.setProprietario(this);
            carros.add(veiculo);
        }
    }

    public void removerVeiculo(Veiculo veiculo) {
        if (carros.remove(veiculo) && veiculo != null) {
            veiculo.setProprietario(null);
        }
    }

    public double calcularTotal() {
        double total = 0.0;
        boolean temItens = false;
        for (Veiculo veiculo : carros) {
            for (Servico servico : veiculo.getServicos()) {
                total += servico.getPreco();
                temItens = true;
            }
            for (PecaUtilizada peca : veiculo.getPecasUtilizadas()) {
                total += peca.getSubtotal();
                temItens = true;
            }
        }
        return total + (temItens ? Orcamento.TAXA_FIXA_MAO_DE_OBRA : 0.0);
    }
}
