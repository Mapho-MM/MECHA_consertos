package com.senai.javafx.projeto02;

import com.senai.javafx.projeto02.entidades.*;
import javafx.animation.PauseTransition;
import javafx.concurrent.Worker;
import javafx.embed.swing.SwingFXUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Locale;

/**
 * Abre a Nota de Serviço (HTML) com as mesmas funções práticas da Nota Fiscal:
 * edição, zoom, salvar alterações e exportar PDF.
 */
public final class NotaServicoHelper {

    private NotaServicoHelper() {}

    public static void abrirNota(Cliente cliente, Veiculo veiculo, Servico servico) {
        if (cliente == null || veiculo == null || servico == null) {
            Dialogos.mostrarMensagem("Nota de Serviço", "Selecione uma ordem válida.");
            return;
        }

        Stage stage = new Stage();
        stage.setTitle("Nota de Serviço");
        stage.initModality(Modality.WINDOW_MODAL);

        WebView web = new WebView();
        web.setPrefSize(900, 1000);
        WebEngine engine = web.getEngine();

        String htmlTemplate = carregarHtmlComLogo();
        if (htmlTemplate == null) {
            Dialogos.mostrarMensagem("Nota de Serviço", "Template nota_servico.html não encontrado.");
            return;
        }

        final double[] zoomAtual = {1.0};
        Label rotuloZoom = new Label("100%");
        rotuloZoom.setStyle("-fx-min-width: 48px; -fx-alignment: center;");

        Runnable aplicarZoom = () -> {
            web.setZoom(zoomAtual[0]);
            rotuloZoom.setText(Math.round(zoomAtual[0] * 100) + "%");
        };

        Runnable preencher = () -> {
            try {
                String json = montarJson(cliente, veiculo, servico);
                engine.executeScript("preencherNota(" + json + ")");
            } catch (Exception ex) {
                Dialogos.mostrarMensagem("Nota de Serviço", "Erro ao preencher: " + ex.getMessage());
            }
        };

        engine.getLoadWorker().stateProperty().addListener((obs, old, state) -> {
            if (state == Worker.State.SUCCEEDED) {
                preencher.run();
            }
        });
        engine.loadContent(htmlTemplate, "text/html");

        Button btnRecarregar = new Button("↺ Recarregar");
        btnRecarregar.setOnAction(e -> {
            zoomAtual[0] = 1.0;
            aplicarZoom.run();
            engine.loadContent(carregarHtmlComLogo(), "text/html");
        });

        Button btnPdf = new Button("💾 Salvar PDF...");
        btnPdf.setOnAction(e -> salvarPdf(stage, web, engine));

        Button btnSalvar = new Button("💾 Salvar nota / alterações");
        btnSalvar.setOnAction(e -> {
            try {
                Object html = engine.executeScript("document.documentElement.outerHTML");
                if (html == null) throw new IllegalStateException("A nota ainda não foi carregada.");
                String htmlSalvo = html.toString();
                try (var logoStream = NotaServicoHelper.class.getResourceAsStream("/com/senai/javafx/projeto02/logo-oficina.png")) {
                    if (logoStream != null) {
                        String logoBase64 = Base64.getEncoder().encodeToString(logoStream.readAllBytes());
                        htmlSalvo = htmlSalvo.replace("src=\"logo-oficina.png\"",
                                        "src=\"data:image/png;base64," + logoBase64 + "\"")
                                .replace("src='logo-oficina.png'",
                                        "src='data:image/png;base64," + logoBase64 + "'");
                    }
                }
                String os = servico.getNumeroOrcamento() == null ? "----" : String.format("%04d", servico.getNumeroOrcamento());
                NotaFiscalRepositorio.salvar(null, htmlSalvo, cliente.getNome(), cliente.getCpf(),
                        veiculo.getModelo() + " / " + veiculo.getPlaca(), os, "NOTA DE SERVIÇO - " + servico.getNome());
                Dialogos.mostrarMensagem("Nota salva",
                        "A nota de serviço e suas edições foram salvas.\n\nO salvamento é interno e não representa autorização fiscal.");
            } catch (Exception ex) {
                Dialogos.mostrarMensagem("Erro ao salvar", "Não foi possível salvar a nota: " + ex.getMessage());
            }
        });

        Button btnZoomMenos = new Button("−");
        btnZoomMenos.setMinWidth(36);
        btnZoomMenos.setOnAction(e -> {
            zoomAtual[0] = Math.max(0.5, Math.round((zoomAtual[0] - 0.1) * 10) / 10.0);
            aplicarZoom.run();
        });
        Button btnZoomMais = new Button("+");
        btnZoomMais.setMinWidth(36);
        btnZoomMais.setOnAction(e -> {
            zoomAtual[0] = Math.min(2.0, Math.round((zoomAtual[0] + 0.1) * 10) / 10.0);
            aplicarZoom.run();
        });
        Button btnZoomReset = new Button("100%");
        btnZoomReset.setOnAction(e -> {
            zoomAtual[0] = 1.0;
            aplicarZoom.run();
        });

        HBox barra = new HBox(10,
                btnRecarregar, btnPdf, btnSalvar,
                new Separator(),
                btnZoomMenos, rotuloZoom, btnZoomMais, btnZoomReset);
        barra.setAlignment(Pos.CENTER_LEFT);
        barra.setPadding(new Insets(10));

        Label dica = new Label("Edite os campos no documento. Use as mesmas ações da nota fiscal: PDF, salvar e zoom.");
        dica.setStyle("-fx-text-fill: #888; -fx-font-size: 12px;");
        dica.setPadding(new Insets(0, 10, 8, 10));

        VBox topo = new VBox(4, barra, dica);
        BorderPane raiz = new BorderPane(web);
        raiz.setTop(topo);
        BorderPane.setMargin(web, new Insets(0, 4, 4, 4));
        VBox.setVgrow(web, Priority.ALWAYS);

        stage.setScene(new Scene(raiz, 960, 1060));
        stage.show();
    }

    private static void salvarPdf(Stage stage, WebView web, WebEngine engine) {
        if (engine.getDocument() == null || engine.getLoadWorker().getState() != Worker.State.SUCCEEDED) {
            Dialogos.mostrarMensagem("Salvar", "Aguarde o carregamento completo da nota antes de exportar o PDF.");
            return;
        }
        FileChooser seletor = new FileChooser();
        seletor.setTitle("Salvar nota de serviço em PDF");
        seletor.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF", "*.pdf"));
        String dataHora = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        seletor.setInitialFileName("Nota_Servico_" + dataHora + ".pdf");
        File pastaDocs = new File(System.getProperty("user.home"), "Documents");
        if (!pastaDocs.isDirectory()) pastaDocs = new File(System.getProperty("user.home"));
        seletor.setInitialDirectory(pastaDocs);
        File arquivo = seletor.showSaveDialog(stage);
        if (arquivo == null) return;
        if (!arquivo.getName().toLowerCase(Locale.ROOT).endsWith(".pdf")) {
            arquivo = new File(arquivo.getAbsolutePath() + ".pdf");
        }
        final File destino = arquivo;
        final double zoomAntes = web.getZoom();
        final double alturaPrefAntes = web.getPrefHeight();
        final double alturaMinAntes = web.getMinHeight();
        try {
            Object hObj = engine.executeScript(
                    "Math.max(document.body.scrollHeight, document.documentElement.scrollHeight, document.body.offsetHeight)");
            double conteudoH = hObj instanceof Number n ? n.doubleValue() + 48 : 1100;
            conteudoH = Math.max(800, Math.min(12000, conteudoH));
            double largura = Math.max(web.getWidth(), 880);
            web.setZoom(1.0);
            web.setMinHeight(0);
            web.setPrefHeight(conteudoH);
            web.resize(largura, conteudoH);
            web.applyCss();
            web.layout();

            PauseTransition aguardar = new PauseTransition(Duration.millis(250));
            aguardar.setOnFinished(ev -> {
                try {
                    web.applyCss();
                    web.layout();
                    SnapshotParameters params = new SnapshotParameters();
                    params.setFill(Color.WHITE);
                    WritableImage imagem = web.snapshot(params, null);
                    if (imagem == null || imagem.getWidth() < 2 || imagem.getHeight() < 2) {
                        throw new IllegalStateException("A captura da nota ficou vazia.");
                    }
                    BufferedImage buffered = SwingFXUtils.fromFXImage(imagem, null);
                    try (FileOutputStream fos = new FileOutputStream(destino)) {
                        NotaFiscalPdf.escrever(buffered, fos);
                    }
                    Dialogos.mostrarMensagem("PDF salvo", "Nota de serviço exportada para:\n\n" + destino.getAbsolutePath());
                } catch (Exception ex) {
                    ex.printStackTrace();
                    Dialogos.mostrarMensagem("Erro ao salvar", "Não foi possível gerar o PDF:\n" + ex.getMessage());
                } finally {
                    web.setMinHeight(alturaMinAntes);
                    web.setPrefHeight(alturaPrefAntes);
                    web.setZoom(zoomAntes);
                    web.requestLayout();
                }
            });
            aguardar.play();
        } catch (Exception ex) {
            web.setMinHeight(alturaMinAntes);
            web.setPrefHeight(alturaPrefAntes);
            web.setZoom(zoomAntes);
            Dialogos.mostrarMensagem("Erro ao salvar", "Não foi possível preparar o PDF:\n" + ex.getMessage());
        }
    }

    private static String carregarHtmlComLogo() {
        try (var is = NotaServicoHelper.class.getResourceAsStream("/com/senai/javafx/projeto02/nota_servico.html")) {
            if (is == null) return null;
            String html = new String(is.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
            try (var logoStream = NotaServicoHelper.class.getResourceAsStream("/com/senai/javafx/projeto02/logo-oficina.png")) {
                if (logoStream != null) {
                    String b64 = Base64.getEncoder().encodeToString(logoStream.readAllBytes());
                    String dataUri = "data:image/png;base64," + b64;
                    html = html.replace("src=\"logo-oficina.png\"", "src=\"" + dataUri + "\"")
                            .replace("src='logo-oficina.png'", "src='" + dataUri + "'");
                }
            }
            return html;
        } catch (Exception e) {
            return null;
        }
    }

    private static String montarJson(Cliente c, Veiculo v, Servico s) {
        String statusTxt = switch (s.getStatus()) {
            case ORCAMENTO -> "Orçamento";
            case AGENDADO -> "Aberto";
            case ANDAMENTO -> "Em andamento";
            case FINALIZADO -> "Concluído";
        };
        String num = s.getNumeroOrcamento() != null
                ? String.format("%04d", s.getNumeroOrcamento())
                : "0000";
        String mec = s.getMecanicos().isEmpty() ? "" : s.getMecanicos().get(0).getNome();

        StringBuilder servicosJson = new StringBuilder("[");
        servicosJson.append(String.format(Locale.US,
                "{\"descricao\":%s,\"qtd\":1,\"valor\":%.2f}",
                jsStr(s.getNome()), s.getPreco()));
        servicosJson.append("]");

        StringBuilder pecasJson = new StringBuilder("[");
        boolean first = true;
        for (PecaUtilizada p : v.getPecasUtilizadas()) {
            if (!first) pecasJson.append(',');
            first = false;
            pecasJson.append(String.format(Locale.US,
                    "{\"codigo\":%s,\"descricao\":%s,\"qtd\":%.2f,\"valor\":%.2f}",
                    jsStr(""),
                    jsStr(p.getNome() != null ? p.getNome() : ""),
                    p.getQuantidade(),
                    p.getPrecoUnitario()));
        }
        pecasJson.append("]");

        return "{"
                + "\"numero\":" + jsStr(num) + ","
                + "\"status\":" + jsStr(statusTxt) + ","
                + "\"dataEntrada\":" + jsStr(s.getDataHoraInicio() == null ? "" : s.getDataHoraInicio().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))) + ","
                + "\"dataSaida\":" + jsStr(s.getDataHoraConclusao() == null ? "" : s.getDataHoraConclusao().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))) + ","
                + "\"mecanico\":" + jsStr(mec) + ","
                + "\"cliente\":{"
                + "\"nome\":" + jsStr(c.getNome()) + ","
                + "\"doc\":" + jsStr(c.getCpf()) + ","
                + "\"tel\":" + jsStr(c.getTelefone()) + ","
                + "\"email\":" + jsStr("") + ","
                + "\"endereco\":" + jsStr("")
                + "},"
                + "\"veiculo\":{"
                + "\"placa\":" + jsStr(v.getPlaca()) + ","
                + "\"marca\":" + jsStr("") + ","
                + "\"modelo\":" + jsStr(v.getModelo()) + ","
                + "\"ano\":" + jsStr("") + ","
                + "\"cor\":" + jsStr("") + ","
                + "\"km\":" + jsStr("") + ","
                + "\"combustivel\":" + jsStr("") + ","
                + "\"chassi\":" + jsStr("")
                + "},"
                + "\"defeito\":" + jsStr(nullToEmpty(s.getDefeito())) + ","
                + "\"diagnostico\":" + jsStr(nullToEmpty(s.getDiagnostico())) + ","
                + "\"pagamento\":" + jsStr("") + ","
                + "\"observacoes\":" + jsStr(nullToEmpty(s.getObservacoes())) + ","
                + "\"desconto\":0,"
                + "\"servicos\":" + servicosJson + ","
                + "\"pecas\":" + pecasJson
                + "}";
    }

    private static String nullToEmpty(String s) {
        return s == null ? "" : s;
    }

    private static String jsStr(String s) {
        if (s == null) return "\"\"";
        return "\"" + s
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "")
                + "\"";
    }
}
