package com.senai.javafx.projeto02;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.*;

import static com.senai.javafx.projeto02.Tema.*;

/** Admin: lista de contas — LayoutPadrao. */
public class ModuloContasController {

    @FXML private Label titulo, subtitulo, badge;
    @FXML private TableView<Map<String, String>> tabela;
    @FXML private Button btnAtualizar;

    private final UsuarioService usuarioService = new UsuarioService();

    @FXML
    private void initialize() {
        tabela.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        for (String col : new String[]{"#", "Nome", "Login / e-mail", "Perfil"}) {
            TableColumn<Map<String, String>, String> c = new TableColumn<>(col);
            final String k = col;
            c.setCellValueFactory(d -> new SimpleStringProperty(
                    d.getValue() != null ? d.getValue().getOrDefault(k, "") : ""));
            tabela.getColumns().add(c);
        }
        LayoutPadrao.estilizarTabela(tabela);

        Paleta p = paletaAtual();
        if (titulo != null) {
            titulo.setStyle("-fx-text-fill: " + p.texto() + "; -fx-font-size: 26px; -fx-font-weight: bold;");
        }
        if (subtitulo != null) {
            subtitulo.setStyle("-fx-text-fill: " + p.textoSec() + "; -fx-font-size: 13px;");
        }
        if (btnAtualizar != null) {
            btnAtualizar.setText("↻");
            btnAtualizar.setTooltip(new Tooltip("Atualizar"));
            btnAtualizar.setStyle(
                    "-fx-background-color: " + LayoutPadrao.COR_PRIMARIO + ";" +
                    "-fx-text-fill: #ffffff;" +
                    "-fx-font-size: 16px; -fx-font-weight: bold;" +
                    "-fx-background-radius: 18; -fx-border-radius: 18;" +
                    "-fx-border-color: " + LayoutPadrao.COR_NEUTRO_BD + "; -fx-border-width: 1;" +
                    "-fx-cursor: hand; -fx-padding: 0;"
            );
        }
        onAtualizar();
    }

    @FXML
    public void onAtualizar() {
        List<Map<String, String>> linhas = new ArrayList<>();
        int i = 1;
        for (Usuario u : usuarioService.listarTodos()) {
            Map<String, String> row = new LinkedHashMap<>();
            row.put("#", String.valueOf(i++));
            row.put("Nome", u.getNome());
            row.put("Login / e-mail", u.getLogin());
            row.put("Perfil", u.getPerfil() != null ? u.getPerfil() : "—");
            linhas.add(row);
        }
        tabela.setItems(FXCollections.observableArrayList(linhas));
        LayoutPadrao.estilizarTabela(tabela);
        LayoutPadrao.atualizarRodape(badge, linhas.size());
        if (badge != null) {
            badge.setStyle("-fx-text-fill: " + paletaAtual().textoSec() + "; -fx-font-size: 12px;");
        }
    }
}
