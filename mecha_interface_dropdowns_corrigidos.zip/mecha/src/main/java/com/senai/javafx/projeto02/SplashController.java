package com.senai.javafx.projeto02;

import javafx.animation.*;
import javafx.application.Platform;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.effect.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.stage.*;
import javafx.util.Duration;
import javafx.fxml.FXML;

/** Tela animada de abertura. Ao terminar (ou ao clicar), abre o login. */
public class SplashController implements TelaController {

    @FXML private StackPane telaSplash;
    @FXML private ImageView fundoSplash;
    @FXML private ImageView splashLogo;
    @FXML private Region splashBarra;

    private SequentialTransition animacaoSplash;
    private boolean finalizado = false;

    @FXML
    public void initialize() {
        prepararSplash();
    }

    @Override
    public void aoMudarTema() {
        estilizarSplash();
    }

    @Override
    public void aoMudarLayout(boolean compacto) {
        estilizarSplash();
    }

    private void prepararSplash() {
        if (telaSplash == null) return;

        telaSplash.setVisible(true);
        telaSplash.setManaged(true);
        telaSplash.toFront();
        if (fundoSplash != null) {
            fundoSplash.fitWidthProperty().bind(telaSplash.widthProperty());
            fundoSplash.fitHeightProperty().bind(telaSplash.heightProperty());
        }

        if (splashLogo != null) {
            splashLogo.setOpacity(0);
            splashLogo.setTranslateY(24);
        }
        splashBarra.setOpacity(0);
        splashBarra.setScaleX(0);

        // Toque na tela pula a animação.
        telaSplash.setOnMouseClicked(event -> {
            if (animacaoSplash != null) animacaoSplash.stop();
            finalizarSplash();
        });

        // Começa depois que a janela aparece.
        Platform.runLater(this::tocarSplash);
    }

    private void tocarSplash() {
        FadeTransition entraLogo = new FadeTransition(Duration.millis(900), splashLogo);
        entraLogo.setToValue(1);
        TranslateTransition moveLogo = new TranslateTransition(Duration.millis(900), splashLogo);
        moveLogo.setToY(0);
        moveLogo.setInterpolator(Interpolator.EASE_OUT);
        ParallelTransition logo = new ParallelTransition(entraLogo, moveLogo);

        FadeTransition entraBarra = new FadeTransition(Duration.millis(200), splashBarra);
        entraBarra.setToValue(1);
        ScaleTransition cresceBarra = new ScaleTransition(Duration.millis(900), splashBarra);
        cresceBarra.setToX(1);
        cresceBarra.setInterpolator(Interpolator.EASE_BOTH);
        ParallelTransition barra = new ParallelTransition(entraBarra, cresceBarra);
        barra.setDelay(Duration.millis(500));

        ParallelTransition entrada = new ParallelTransition(logo, barra);

        FadeTransition saida = new FadeTransition(Duration.millis(500), telaSplash);
        saida.setToValue(0);

        animacaoSplash = new SequentialTransition(entrada, new PauseTransition(Duration.millis(400)), saida);
        animacaoSplash.setOnFinished(event -> finalizarSplash());
        animacaoSplash.play();
    }

    private void finalizarSplash() {
        if (telaSplash == null) return;

        if (finalizado) return;
        finalizado = true;

        // Mesmo em modo desenvolvedor, mostra o login para que o botão Debug possa ser usado.
        Navegador.ir(Navegador.Tela.LOGIN);
    }

    private void estilizarSplash() {
        if (telaSplash == null) return;

        Tema.Paleta p = Tema.paletaAtual();
        boolean compacto = Tema.layoutCompacto();
        String degradeMarca = Tema.degradeDestaque();
        String fundo = (Tema.temaEfetivo() == 1)
                ? "linear-gradient(to bottom, #f8f4ec, #ece6dc)"
                : p.fundoApp();

        telaSplash.setStyle("-fx-background-color: " + fundo + ";");
        if (splashLogo != null) {
            splashLogo.setFitWidth(compacto ? 300 : 390);
            splashLogo.setFitHeight(compacto ? 125 : 150);
            splashLogo.setEffect(new javafx.scene.effect.DropShadow(24, javafx.scene.paint.Color.rgb(95, 130, 255, 0.60)));
        }
        splashBarra.setStyle(
                "-fx-background-radius: 2;" +
                "-fx-background-color: " + degradeMarca + ";"
        );
    }
}
