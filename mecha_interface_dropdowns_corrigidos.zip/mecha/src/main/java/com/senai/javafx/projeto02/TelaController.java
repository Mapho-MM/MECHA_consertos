package com.senai.javafx.projeto02;

/**
 * Contrato opcional de cada tela. O {@link Navegador} chama estes métodos
 * nos momentos certos, então cada controller só cuida da própria tela.
 */
public interface TelaController {

    /** A tela acabou de aparecer (bom lugar para focar um campo ou carregar dados). */
    default void aoEntrar() {
    }

    /** O tema/paleta mudou (ou a tela acabou de ser montada): ajuste estilos próprios aqui. */
    default void aoMudarTema() {
    }

    /** A janela mudou entre layout de computador e compacto. */
    default void aoMudarLayout(boolean compacto) {
    }

    /** A foto de perfil do usuário foi alterada. */
    default void aoAtualizarAvatar(Usuario usuario) {
    }
}
