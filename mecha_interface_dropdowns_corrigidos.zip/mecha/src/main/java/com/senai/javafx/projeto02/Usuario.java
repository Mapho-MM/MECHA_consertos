package com.senai.javafx.projeto02;

public class Usuario {
    private final String nome;
    private final String login;
    private final String senhaHash;
    private final String perfil;

    public Usuario(String nome, String login, String senhaHash, String perfil) {
        this.nome = nome;
        this.login = login;
        this.senhaHash = senhaHash;
        this.perfil = perfil;
    }

    public String getNome() {
        return nome;
    }

    public String getLogin() {
        return login;
    }

    public String getSenhaHash() {
        return senhaHash;
    }

    public String getPerfil() {
        return perfil;
    }
}
