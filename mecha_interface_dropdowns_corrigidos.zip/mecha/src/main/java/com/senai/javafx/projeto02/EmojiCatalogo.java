package com.senai.javafx.projeto02;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Catálogo de emojis Unicode + URL Twemoji (emoji colorido oficial do Twitter/X,
 * mesma ideia dos packs Google/Noto em PNG colorido).
 */
public final class EmojiCatalogo {

    public record EmojiItem(String caractere, String nome, String categoria, String codigoHex) {
        /** PNG colorido 72×72 (Twemoji CDN). */
        public String urlTwemoji() {
            return "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/" + codigoHex + ".png";
        }
    }

    private static final Map<String, List<EmojiItem>> CACHE = new ConcurrentHashMap<>();
    private static volatile boolean tentouRede = false;

    private EmojiCatalogo() {
    }

    public static Map<String, List<EmojiItem>> obterPorCategoria() {
        if (!CACHE.isEmpty()) return CACHE;
        synchronized (EmojiCatalogo.class) {
            if (!CACHE.isEmpty()) return CACHE;
            // Catálogo local imediato (sem esperar rede — emojis aparecem na hora)
            carregarLocal();
            return CACHE;
        }
    }

    public static String deCodigoUnificado(String unified) {
        if (unified == null || unified.isBlank()) return "";
        StringBuilder sb = new StringBuilder();
        for (String part : unified.split("-")) {
            try {
                sb.appendCodePoint(Integer.parseInt(part.trim(), 16));
            } catch (Exception ignored) {
            }
        }
        return sb.toString();
    }

    /** Twemoji usa hex em minúsculas, codepoints separados por hífen, sem FE0F. */
    public static String paraTwemojiHex(String unified) {
        if (unified == null) return "";
        StringBuilder sb = new StringBuilder();
        for (String part : unified.split("-")) {
            String p = part.trim().toLowerCase(Locale.ROOT);
            if (p.isEmpty() || p.equals("fe0f")) continue; // variation selector omitido no path twemoji
            if (sb.length() > 0) sb.append('-');
            // remove leading zeros? twemoji keeps them as needed e.g. 1f600
            try {
                int cp = Integer.parseInt(p, 16);
                sb.append(Integer.toHexString(cp));
            } catch (Exception e) {
                sb.append(p);
            }
        }
        return sb.toString();
    }

    public static String codigoHexDoCaractere(String emoji) {
        if (emoji == null || emoji.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        emoji.codePoints().forEach(cp -> {
            if (cp == 0xFE0F) return;
            if (sb.length() > 0) sb.append('-');
            sb.append(Integer.toHexString(cp));
        });
        return sb.toString();
    }

    private static boolean carregarDaRede() {
        try {
            HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(4)).build();
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create("https://cdn.jsdelivr.net/npm/emoji-datasource-google@15.1.2/emoji.json"))
                    .timeout(Duration.ofSeconds(10))
                    .GET()
                    .build();
            HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (res.statusCode() != 200 || res.body() == null) return false;

            String body = res.body();
            int count = 0;
            // Captura blocos com unified + category + name (ordem variável)
            Matcher m = Pattern.compile(
                    "\\{[^{}]*?\"unified\"\\s*:\\s*\"([0-9A-Fa-f-]+)\"[^{}]*?\"category\"\\s*:\\s*\"([^\"]+)\"[^{}]*?\"name\"\\s*:\\s*\"([^\"]*)\"[^{}]*?\\}"
            ).matcher(body);
            if (!m.find()) {
                m = Pattern.compile(
                        "\"unified\"\\s*:\\s*\"([0-9A-Fa-f-]+)\"[\\s\\S]{0,400}?\"category\"\\s*:\\s*\"([^\"]+)\"[\\s\\S]{0,200}?\"name\"\\s*:\\s*\"([^\"]*)\""
                ).matcher(body);
            } else {
                m.reset();
            }
            while (m.find() && count < 3000) {
                String uni = m.group(1);
                String cat = m.group(2);
                String nome = m.group(3);
                String ch = deCodigoUnificado(uni);
                if (ch.isBlank()) continue;
                String hex = paraTwemojiHex(uni);
                CACHE.computeIfAbsent(cat, k -> new ArrayList<>())
                        .add(new EmojiItem(ch, nome, cat, hex));
                count++;
            }
            return count > 50;
        } catch (Exception e) {
            System.err.println("[Emoji] Rede: " + e.getMessage());
            CACHE.clear();
            return false;
        }
    }

    private static void carregarLocal() {
        put("Smileys & Emotion",
                "😀 😁 😂 🤣 😃 😄 😅 😆 😉 😊 😋 😎 😍 😘 🥰 😗 😙 😚 🙂 🤗 🤩 🤔 🤨 😐 😑 😶 🙄 😏 😣 😥 😮 🤐 😯 😪 😫 🥱 😴 😌 😛 😜 😝 🤤 😒 😓 😔 😕 🙃 🤑 😲 ☹️ 🙁 😖 😞 😟 😤 😢 😭 😦 😧 😨 😩 🤯 😬 😰 😱 🥵 🥶 😳 🤪 😵 🥴 😠 😡 🤬 😷 🤒 🤕 🤢 🤮 🤧 😇 🥳 🥺 🤠 🤡 🤥 🤫 🤭 🧐 🤓 😈 👿 👹 👺 💀 👻 👽 👾 🤖 💩 😺 😸 😹 😻 😼 😽 🙀 😿 😾");
        put("People & Body",
                "👋 🤚 🖐️ ✋ 🖖 👌 🤌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 💪 🦾 🦿 🦵 🦶 👂 🦻 👃 🧠 👀 👁️ 👅 👄 💋 👶 🧒 👦 👧 🧑 👨 👩 🧓 👴 👵");
        put("Animals & Nature",
                "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐒 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐜 🐢 🐍 🦎 🦖 🦕 🐙 🦑 🦐 🦞 🦀 🐡 🐠 🐟 🐬 🐳 🐋 🦈");
        put("Food & Drink",
                "🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🫐 🍈 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🍆 🥑 🥦 🥬 🥒 🌶️ 🫑 🌽 🥕 🫒 🧄 🧅 🥔 🍠 🥐 🥯 🍞 🥖 🥨 🧀 🥚 🍳 🧈 🥞 🧇 🥓 🥩 🍗 🍖 🌭 🍔 🍟 🍕 🫓 🥪 🥙 🧆 🌮 🌯 🥗 🥘 🫕 🍝 🍜 🍲 🍛 🍣 🍱 🥟 🍤 🍙 🍚 🍘 🍥 🥠 🥮 🍢 🍡 🍧 🍨 🍦 🥧 🧁 🍰 🎂 🍮 🍭 🍬 🍫 🍿 🍩 🍪 🌰 🥜 🍯 🥛 🍼 ☕ 🍵 🧃 🥤 🧋 🍶 🍺 🍻 🥂 🍷 🥃 🍸 🍹 🧉 🍾 🧊");
        put("Travel & Places",
                "🚗 🚕 🚙 🚌 🚎 🏎️ 🚓 🚑 🚒 🚐 🛻 🚚 🚛 🚜 🦯 🦽 🦼 🛴 🚲 🛵 🏍️ 🛺 🚨 🚔 🚍 🚘 🚖 🚡 🚠 🚟 🚃 🚋 🚞 🚝 🚄 🚅 🚈 🚂 🚆 🚇 🚊 🚉 ✈️ 🛫 🛬 🛩️ 💺 🛰️ 🚀 🛸 🚁 🛶 ⛵ 🚤 🛥️ 🛳️ ⛴️ 🚢");
        put("Activities",
                "⚽ 🏀 🏈 ⚾ 🥎 🎾 🏐 🏉 🥏 🎱 🪀 🏓 🏸 🥅 🏒 🏑 🥍 🏏 🪃 🎯 🎮 🕹️ 🎰 🎲 🧩 ♟️ 🎭 🎨 🧵 🪡 🧶 🎹 🥁 🎷 🎺 🪗 🎸 🪕 🎻 🎬 🎤 🎧 🎼");
        put("Objects",
                "⌚ 📱 💻 ⌨️ 🖥️ 🖨️ 🖱️ 🖲️ 💾 💿 📀 📷 📸 📹 🎥 📞 ☎️ 📺 📻 🧭 ⏱️ ⏰ 🕰️ ⌛ ⏳ 📡 🔋 🔌 💡 🔦 🕯️ 🧯 🧯 🛢️ 💸 💰 💳 💎 ⚖️ 🧰 🪛 🔧 🔨 ⚒️ 🛠️ ⛏️ 🔩 ⚙️ 🧱 ⛓️ 🧲 🔫 💣 🪓 🔪 🗡️ ⚔️ 🛡️ 🚬 🔮 🧿 🔭 🔬 🩹 🩺 💊 💉 🩸 🧬 🦠 🧫 🧪 🌡️ 🧹 🧺 🧻 🚽 🚰 🚿 🛁 🧼 🪥 🪒 🧽 🪣 🧴 🛎️ 🔑 🗝️ 🚪 🪑 🛋️ 🛏️ 🧸 🖼️ 🛍️ 🛒 🎁 🎈 🎏 🎀 🎊 🎉");
        put("Symbols",
                "✅ ❌ ❗ ❓ ❕ ❔ ‼️ ⁉️ 💤 💢 💬 🗯️ 💭 ♠️ ♥️ ♦️ ♣️ 🃏 🀄 🎴 🔇 🔈 🔉 🔊 🔔 🔕 🎵 🎶 💹 ✔️ ✖️ ➕ ➖ ➗ ♾️ 💱 💲 ⚕️ ♻️ ⚜️ 🔱 ⭕ 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 🟤 🔺 🔻 💠 🔘 🔳 🔲");
        put("Flags",
                "🏳️ 🏴 🏁 🚩 🏳️‍🌈 🇧🇷 🇺🇸 🇬🇧 🇵🇹 🇪🇸 🇫🇷 🇩🇪 🇮🇹 🇯🇵 🇨🇳 🇰🇷 🇦🇷 🇨🇱 🇲🇽 🇨🇦");
    }

    private static void put(String cat, String spaceSeparated) {
        List<EmojiItem> list = CACHE.computeIfAbsent(cat, k -> new ArrayList<>());
        for (String token : spaceSeparated.trim().split("\\s+")) {
            if (token.isBlank()) continue;
            String hex = codigoHexDoCaractere(token);
            list.add(new EmojiItem(token, token, cat, hex));
        }
    }

    public static List<String> ordemCategorias() {
        Map<String, List<EmojiItem>> m = obterPorCategoria();
        List<String> preferidas = List.of(
                "Smileys & Emotion", "People & Body", "Animals & Nature", "Food & Drink",
                "Travel & Places", "Activities", "Objects", "Symbols", "Flags",
                "Smileys", "Gestos", "Corações", "Pessoas", "Animais", "Comida",
                "Atividades", "Viagem", "Objetos", "Símbolos", "Bandeiras"
        );
        LinkedHashSet<String> out = new LinkedHashSet<>();
        for (String p : preferidas) if (m.containsKey(p)) out.add(p);
        out.addAll(m.keySet());
        return new ArrayList<>(out);
    }
}
