package com.senai.javafx.projeto02;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import static com.senai.javafx.projeto02.Tema.paletaAtual;

/**
 * Layout padrão obrigatório de listagens do MECHA (Dark Mode).
 *
 * Anatomia de cima para baixo:
 *  1. Cabeçalho  — título à esquerda + ícone ↻ isolado (atualizar)
 *  2. Cards      — indicadores / resumos
 *  3. Barra      — filtros (esquerda, neutros) | ações (direita: excluir → editar → criar)
 *  4. Tabela     — largura total, estilo dark
 *  5. Rodapé     — contador de registros no canto inferior direito
 */
public final class LayoutPadrao {

    private LayoutPadrao() {}

    // ── Cores semânticas (psicologia das cores) ──────────────────────────────
    public static final String COR_DESTRUTIVO = "#ef4444";   // vermelho  — excluir
    public static final String COR_EDICAO     = "#f59e0b";   // âmbar     — editar
    public static final String COR_PRIMARIO   = "#3b82f6";   // azul      — criar
    public static final String COR_SUCESSO    = "#22c55e";   // verde     — alternativa criar
    public static final String COR_NEUTRO_BG  = "rgba(255,255,255,0.08)";
    public static final String COR_NEUTRO_BD  = "rgba(255,255,255,0.14)";

    // =========================================================================
    // 1. CABEÇALHO
    // =========================================================================

    /**
     * Título à esquerda + botão circular ↻ isolado ao lado.
     * @return HBox com título e botão de atualizar
     */
    public static HBox cabecalho(String tituloTexto, Runnable aoAtualizar) {
        Tema.Paleta p = paletaAtual();

        Label titulo = new Label(tituloTexto);
        titulo.setStyle(
                "-fx-text-fill: " + p.texto() + ";" +
                "-fx-font-size: 26px; -fx-font-weight: bold;"
        );

        Button btnRefresh = botaoRefresh(aoAtualizar);

        HBox header = new HBox(12, titulo, btnRefresh);
        header.setAlignment(Pos.CENTER_LEFT);
        return header;
    }

    /** Ícone ↻ discreto, circular, sem texto longo. */
    public static Button botaoRefresh(Runnable acao) {
        Tema.Paleta p = paletaAtual();
        Button b = new Button("↻");
        b.setPrefSize(36, 36);
        b.setMinSize(36, 36);
        b.setMaxSize(36, 36);
        b.setTooltip(new Tooltip("Atualizar"));
        b.setStyle(
                "-fx-background-color: " + COR_NEUTRO_BG + ";" +
                "-fx-text-fill: " + p.textoSec() + ";" +
                "-fx-font-size: 16px; -fx-font-weight: bold;" +
                "-fx-background-radius: 18; -fx-border-radius: 18;" +
                "-fx-border-color: " + COR_NEUTRO_BD + "; -fx-border-width: 1;" +
                "-fx-cursor: hand; -fx-padding: 0;"
        );
        b.setOnMouseEntered(e -> b.setOpacity(0.75));
        b.setOnMouseExited(e -> b.setOpacity(1.0));
        if (acao != null) b.setOnAction(ev -> acao.run());
        return b;
    }

    // =========================================================================
    // 2. CARDS DE INDICADORES
    // =========================================================================

    /** Card de indicador com ícone; ocupa a largura disponível da fileira. */
    public static VBox cardIndicador(String rotulo, String valor) {
        return Visual.cardComIcone(rotulo, valor, 22);
    }

    /** Fileira horizontal de cards. Aceita pares [rótulo, valor]. */
    public static HBox fileiraCards(String[]... pares) {
        HBox row = new HBox(12);
        row.setAlignment(Pos.CENTER_LEFT);
        if (pares != null) {
            for (String[] par : pares) {
                if (par != null && par.length >= 2) {
                    row.getChildren().add(cardIndicador(par[0], par[1]));
                }
            }
        }
        return row;
    }

    // =========================================================================
    // 3. BARRA DE CONTROLE (filtros esquerda | ações direita)
    // =========================================================================

    /**
     * @param filtros  nós à esquerda (ComboBox, botões neutros de visualização)
     * @param acoes    botões de manipulação à direita, já na ordem: excluir → editar → criar
     */
    public static HBox barraControle(Node[] filtros, Node[] acoes) {
        HBox esquerda = new HBox(8);
        esquerda.setAlignment(Pos.CENTER_LEFT);
        if (filtros != null) {
            for (Node n : filtros) {
                if (n != null) esquerda.getChildren().add(n);
            }
        }

        HBox direita = new HBox(8);
        direita.setAlignment(Pos.CENTER_RIGHT);
        if (acoes != null) {
            for (Node n : acoes) {
                if (n != null) direita.getChildren().add(n);
            }
        }

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox barra = new HBox(12, esquerda, spacer, direita);
        barra.setAlignment(Pos.CENTER_LEFT);
        return barra;
    }

    // ── Botões semânticos ────────────────────────────────────────────────────

    /** Neutro / filtro — cinza grafite. */
    public static Button botaoNeutro(String texto) {
        Tema.Paleta p = paletaAtual();
        Button b = new Button(texto);
        b.setPrefHeight(36);
        b.setStyle(
                "-fx-background-color: " + COR_NEUTRO_BG + ";" +
                "-fx-text-fill: " + p.texto() + ";" +
                "-fx-font-size: 13px;" +
                "-fx-background-radius: 12; -fx-border-radius: 12;" +
                "-fx-border-color: " + COR_NEUTRO_BD + "; -fx-border-width: 1;" +
                "-fx-cursor: hand; -fx-padding: 0 14;"
        );
        return b;
    }

    /** Destrutivo — vermelho. Ordem: primeiro entre as ações. */
    public static Button botaoDestrutivo(String texto) {
        Button b = new Button(texto);
        b.setPrefHeight(36);
        b.setStyle(
                "-fx-background-color: " + COR_DESTRUTIVO + ";" +
                "-fx-text-fill: #ffffff;" +
                "-fx-font-size: 13px; -fx-font-weight: bold;" +
                "-fx-background-radius: 12; -fx-border-radius: 12; -fx-border-width: 0;" +
                "-fx-cursor: hand; -fx-padding: 0 14;"
        );
        return b;
    }

    /** Edição — âmbar / laranja queimado. */
    public static Button botaoEdicao(String texto) {
        Button b = new Button(texto);
        b.setPrefHeight(36);
        b.setStyle(
                "-fx-background-color: " + COR_EDICAO + ";" +
                "-fx-text-fill: #1a1a1a;" +
                "-fx-font-size: 13px; -fx-font-weight: bold;" +
                "-fx-background-radius: 12; -fx-border-radius: 12; -fx-border-width: 0;" +
                "-fx-cursor: hand; -fx-padding: 0 14;"
        );
        return b;
    }

    /** Primário / criação — azul (ou verde se preferir). */
    public static Button botaoPrimario(String texto) {
        Button b = new Button(texto);
        b.setPrefHeight(36);
        b.setStyle(
                "-fx-background-color: " + COR_PRIMARIO + ";" +
                "-fx-text-fill: #ffffff;" +
                "-fx-font-size: 13px; -fx-font-weight: bold;" +
                "-fx-background-radius: 12; -fx-border-radius: 12; -fx-border-width: 0;" +
                "-fx-cursor: hand; -fx-padding: 0 14;"
        );
        return b;
    }

    /** Primário verde (alternativa para “+ Novo” quando o contexto for positivo). */
    public static Button botaoSucesso(String texto) {
        Button b = new Button(texto);
        b.setPrefHeight(36);
        b.setStyle(
                "-fx-background-color: " + COR_SUCESSO + ";" +
                "-fx-text-fill: #ffffff;" +
                "-fx-font-size: 13px; -fx-font-weight: bold;" +
                "-fx-background-radius: 12; -fx-border-radius: 12; -fx-border-width: 0;" +
                "-fx-cursor: hand; -fx-padding: 0 14;"
        );
        return b;
    }

    /** ComboBox de filtro com estilo neutro dark. */
    public static <T> ComboBox<T> comboFiltro(T... itens) {
        Tema.Paleta p = paletaAtual();
        ComboBox<T> cb = new ComboBox<>();
        if (itens != null) cb.getItems().addAll(itens);
        cb.setPrefHeight(36);
        cb.setStyle(
                "-fx-background-color: " + COR_NEUTRO_BG + ";" +
                "-fx-text-fill: " + p.texto() + ";" +
                "-fx-background-radius: 12; -fx-border-radius: 12;" +
                "-fx-border-color: " + COR_NEUTRO_BD + "; -fx-border-width: 1;"
        );
        cb.setButtonCell(new ListCell<>() {
            @Override protected void updateItem(T item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.toString());
                setStyle("-fx-text-fill: " + p.texto() + ";");
            }
        });
        cb.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(T item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.toString());
                setStyle("-fx-text-fill: " + p.texto() + "; -fx-padding: 6 10;");
            }
        });
        return cb;
    }

    // =========================================================================
    // 4. TABELA
    // =========================================================================

    public static void estilizarTabela(TableView<?> tabela) {
        if (tabela == null) return;
        tabela.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        Tema.estilizarControleNativo(tabela);
        // Fundo sólido: o texto da tabela não "briga" com a imagem de fundo.
        tabela.setStyle(Visual.estiloTabela(16));
    }

    // =========================================================================
    // 5. RODAPÉ
    // =========================================================================

    public static Label rodapeRegistros(int total) {
        Tema.Paleta p = paletaAtual();
        String txt = total + (total == 1 ? " registro" : " registros");
        Label lb = new Label(txt);
        lb.setStyle(
                "-fx-text-fill: " + p.textoSec() + ";" +
                "-fx-font-size: 12px;" +
                "-fx-padding: 4 2 0 0;"
        );
        return lb;
    }

    public static void atualizarRodape(Label rodape, int total) {
        if (rodape == null) return;
        rodape.setText(total + (total == 1 ? " registro" : " registros"));
    }

    /** HBox com spacer + contador alinhado à direita. */
    public static HBox barraRodape(Label rodape) {
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox bar = new HBox(spacer, rodape);
        bar.setAlignment(Pos.CENTER_RIGHT);
        return bar;
    }

    // =========================================================================
    // MONTAGEM COMPLETA
    // =========================================================================

    /**
     * Monta a VBox completa na ordem padrão.
     *
     * @param tituloTexto   título da tela
     * @param aoAtualizar   callback do ↻
     * @param cards         fileira de cards (pode ser null)
     * @param barra         barra de controle filtros|ações (pode ser null)
     * @param tabela        TableView principal
     * @param rodape        label de contagem (pode ser null)
     */
    public static VBox montar(
            String tituloTexto,
            Runnable aoAtualizar,
            Node cards,
            Node barra,
            TableView<?> tabela,
            Label rodape
    ) {
        VBox root = new VBox(14);
        root.setFillWidth(true);
        root.setPadding(new Insets(8, 10, 8, 10));

        root.getChildren().add(cabecalho(tituloTexto, aoAtualizar));

        if (cards != null) root.getChildren().add(cards);
        if (barra != null) root.getChildren().add(barra);

        if (tabela != null) {
            estilizarTabela(tabela);
            VBox.setVgrow(tabela, Priority.ALWAYS);
            root.getChildren().add(tabela);
        }

        if (rodape != null) {
            root.getChildren().add(barraRodape(rodape));
        }

        return root;
    }
}
