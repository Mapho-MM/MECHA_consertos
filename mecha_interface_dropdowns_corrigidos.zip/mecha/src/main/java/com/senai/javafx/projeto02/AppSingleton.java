package com.senai.javafx.projeto02;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.prefs.Preferences;

/**
 * Singleton com o estado global da aplicação.
 * Mantém usuário logado e preferências da interface em um único ponto.
 */
public final class AppSingleton {

    private static final AppSingleton INSTANCE = new AppSingleton();
    private static final DateTimeFormatter FMT_ACESSO =
            DateTimeFormatter.ofPattern("dd/MM/yyyy 'às' HH:mm", Locale.forLanguageTag("pt-BR"));

    // Passa pelo Armazenamento: com o modo desenvolvedor ativo nada vai para o disco.
    private final Armazenamento preferencias = Armazenamento.get();

    private Usuario usuarioAtual;
    /** Momento do login desta sessão (em memória). */
    private Instant acessoAtual;

    private AppSingleton() {
    }

    public static AppSingleton getInstance() {
        return INSTANCE;
    }

    public Preferences getPreferencias() {
        return preferencias.bruto();
    }

    public Usuario getUsuarioAtual() {
        return usuarioAtual;
    }

    /**
     * Define o usuário logado e registra o horário de acesso
     * (último acesso anterior fica salvo nas preferências).
     */
    public void setUsuarioAtual(Usuario usuarioAtual) {
        this.usuarioAtual = usuarioAtual;
        this.acessoAtual = Instant.now();
        if (usuarioAtual != null && usuarioAtual.getLogin() != null) {
            // grava o acesso atual como "último" para a próxima sessão
            preferencias.putLong(chaveUltimoAcesso(usuarioAtual), acessoAtual.toEpochMilli());
        }
    }

    public void limparSessao() {
        usuarioAtual = null;
        acessoAtual = null;
    }

    /** Atualiza dados do usuário na sessão sem alterar horários de acesso. */
    public void atualizarUsuarioSessao(Usuario usuario) {
        this.usuarioAtual = usuario;
    }

    /** Horário deste login (sessão atual). */
    public String getAcessoAtualFormatado() {
        if (acessoAtual == null) return "—";
        return LocalDateTime.ofInstant(acessoAtual, ZoneId.systemDefault()).format(FMT_ACESSO);
    }

    /**
     * Último acesso anterior ao login atual (persistido).
     * Se for o primeiro login, retorna mensagem amigável.
     */
    public String getUltimoAcessoFormatado(Usuario usuario) {
        if (usuario == null || usuario.getLogin() == null) return "—";
        long millis = preferencias.getLong(chaveUltimoAcesso(usuario), -1L);
        if (millis <= 0) return "Primeiro acesso";
        // Se o valor salvo é o desta sessão, ainda não há "anterior"
        if (acessoAtual != null && Math.abs(millis - acessoAtual.toEpochMilli()) < 2000) {
            // tenta chave de histórico
            long anterior = preferencias.getLong(chaveUltimoAcessoAnterior(usuario), -1L);
            if (anterior <= 0) return "Primeiro acesso";
            return LocalDateTime.ofInstant(Instant.ofEpochMilli(anterior), ZoneId.systemDefault()).format(FMT_ACESSO);
        }
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(millis), ZoneId.systemDefault()).format(FMT_ACESSO);
    }

    /**
     * Ao logar, preserva o acesso anterior antes de sobrescrever.
     */
    public void registrarLogin(Usuario usuario) {
        if (usuario == null || usuario.getLogin() == null) {
            setUsuarioAtual(usuario);
            return;
        }
        long anterior = preferencias.getLong(chaveUltimoAcesso(usuario), -1L);
        if (anterior > 0) {
            preferencias.putLong(chaveUltimoAcessoAnterior(usuario), anterior);
        }
        setUsuarioAtual(usuario);
    }

    private String chaveUltimoAcesso(Usuario usuario) {
        return "ultimoAcesso." + Integer.toHexString(
                usuario.getLogin().toLowerCase(Locale.ROOT).hashCode());
    }

    private String chaveUltimoAcessoAnterior(Usuario usuario) {
        return "ultimoAcessoAnterior." + Integer.toHexString(
                usuario.getLogin().toLowerCase(Locale.ROOT).hashCode());
    }

    public int getModoTema() {
        return preferencias.getInt("modoTema", 2);
    }

    public void setModoTema(int modoTema) {
        preferencias.putInt("modoTema", modoTema);
    }

    public int getModoCor() {
        return preferencias.getInt("modoCor", 6);
    }

    public void setModoCor(int modoCor) {
        preferencias.putInt("modoCor", modoCor);
    }

    public int getModoLayout() {
        return preferencias.getInt("modoLayout", 0);
    }

    public void setModoLayout(int modoLayout) {
        preferencias.putInt("modoLayout", modoLayout);
    }

    public int getModoJanela() {
        return preferencias.getInt("modoJanela", 0);
    }

    public void setModoJanela(int modoJanela) {
        preferencias.putInt("modoJanela", modoJanela);
    }

    public boolean isModoDebug() {
        return preferencias.getBoolean("modoDebug", false);
    }

    /** O modo desenvolvedor nunca é gravado: o programa sempre abre com ele desligado. */
    public void setModoDebug(boolean modoDebug) {
        // intencionalmente vazio
    }

    public String getFotoPerfil(Usuario usuario) {
        if (usuario == null || usuario.getLogin() == null) return "";
        return preferencias.get(chaveFotoPerfil(usuario), "");
    }

    public void setFotoPerfil(Usuario usuario, String valor) {
        if (usuario == null || usuario.getLogin() == null) return;
        String chave = chaveFotoPerfil(usuario);
        if (valor == null || valor.isBlank()) preferencias.remove(chave);
        else preferencias.put(chave, valor);
    }

    public void removerFotoPerfil(Usuario usuario) {
        setFotoPerfil(usuario, "");
    }

    private String chaveFotoPerfil(Usuario usuario) {
        return "fotoPerfil." + Integer.toHexString(
                usuario.getLogin().toLowerCase(Locale.ROOT).hashCode());
    }
}
