package com.senai.javafx.projeto02;

import javafx.animation.*;
import javafx.application.Platform;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.effect.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.stage.*;
import javafx.util.Duration;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import com.senai.javafx.projeto02.Tema.Paleta;

import static com.senai.javafx.projeto02.Tema.*;
import static com.senai.javafx.projeto02.Dialogos.*;

/** Janela "Minha conta" e editor de foto de perfil. */
public final class PerfilDialogo {

    private PerfilDialogo() {
    }

    private static final AppSingleton app = AppSingleton.getInstance();

    /** Abre o perfil do usuário conectado (ou avisa que ninguém está conectado). */
    public static void abrir() {
        try {
            Usuario usuario = app.getUsuarioAtual();
            if (usuario == null) {
                mostrarMensagem("Usuário", "Nenhum usuário está conectado.");
                return;
            }
            abrir(usuario);
        } catch (Exception e) {
            e.printStackTrace();
            mostrarMensagem("Usuário", "Não foi possível abrir as informações do usuário.");
        }
    }

    /**
     * Abre o perfil com informações detalhadas da conta e da sessão atual.
     * A senha nunca é exibida; somente o estado da conta é apresentado.
     */
    public static void abrir(Usuario usuario) {
        Paleta p = paletaAtual();
        Stage janela = criarJanelaTematica();
        VBox cartao = criarCartaoTematico(440, p);
        cartao.setSpacing(18);
        cartao.setAlignment(Pos.TOP_CENTER);

        String nome = valorOuPadrao(usuario.getNome(), "Usuário");
        String login = valorOuPadrao(usuario.getLogin(), "Não informado");
        String perfil = valorOuPadrao(usuario.getPerfil(), "Usuário");
        String perfilNormalizado = perfil.toUpperCase();
        boolean admin = "ADMINISTRADOR".equalsIgnoreCase(perfil);

        // —— Foto central ——
        StackPane areaFoto = criarAreaFotoPerfil(usuario, p, 120);
        Label dicaFoto = new Label("Clique na foto para alterar");
        dicaFoto.setStyle("-fx-text-fill: " + p.textoTerc() + "; -fx-font-size: 11px;");

        VBox blocoFoto = new VBox(8, areaFoto, dicaFoto);
        blocoFoto.setAlignment(Pos.CENTER);

        // —— Badge de perfil ——
        Label badge = new Label(admin ? "ADMINISTRADOR" : "FUNCIONÁRIO");
        badge.setStyle(
                "-fx-background-color: " + fundoDestaque() + ";" +
                "-fx-background-radius: 20;" +
                "-fx-padding: 6 16;" +
                "-fx-text-fill: " + textoSobreDestaque() + ";" +
                "-fx-font-size: 11px;" +
                "-fx-font-weight: bold;"
        );

        // —— Nome editável ——
        Label lblNome = new Label("Nome de exibição");
        lblNome.setStyle("-fx-text-fill: " + p.textoSec() + "; -fx-font-size: 11px;");

        TextField campoNome = new TextField(nome);
        campoNome.setPrefHeight(44);
        campoNome.setMaxWidth(Double.MAX_VALUE);
        campoNome.setStyle(
                "-fx-background-color: " + p.overlay() + "0.12);" +
                "-fx-text-fill: " + p.texto() + ";" +
                "-fx-background-radius: 12;" +
                "-fx-border-color: " + p.borda() + ";" +
                "-fx-border-radius: 12;" +
                "-fx-border-width: 1;" +
                "-fx-font-size: 15px;" +
                "-fx-font-weight: bold;" +
                "-fx-padding: 0 14;"
        );

        Label msgNome = new Label("");
        msgNome.setStyle("-fx-text-fill: " + p.textoTerc() + "; -fx-font-size: 11px;");
        msgNome.setWrapText(true);

        Button btnSalvarNome = new Button("Salvar nome");
        btnSalvarNome.setPrefHeight(40);
        btnSalvarNome.setMaxWidth(Double.MAX_VALUE);
        btnSalvarNome.setStyle(
                "-fx-background-color: " + fundoDestaque() + ";" +
                "-fx-background-radius: 12;" +
                "-fx-text-fill: " + textoSobreDestaque() + ";" +
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-cursor: hand;"
        );
        btnSalvarNome.setOnAction(e -> {
            String novo = campoNome.getText() == null ? "" : campoNome.getText().trim();
            if (novo.isBlank()) {
                msgNome.setText("Digite um nome válido.");
                msgNome.setStyle("-fx-text-fill: #ff6b6b; -fx-font-size: 11px;");
                return;
            }
            if (novo.length() < 2) {
                msgNome.setText("O nome precisa ter pelo menos 2 caracteres.");
                msgNome.setStyle("-fx-text-fill: #ff6b6b; -fx-font-size: 11px;");
                return;
            }
            try {
                UsuarioService servico = new UsuarioService();
                Usuario atualizado = servico.atualizarNome(usuario.getLogin(), novo);
                if (atualizado == null) {
                    msgNome.setText("Não foi possível salvar o nome.");
                    msgNome.setStyle("-fx-text-fill: #ff6b6b; -fx-font-size: 11px;");
                    return;
                }
                app.atualizarUsuarioSessao(atualizado);
                Object ctrl = Navegador.controladorAtual();
                notificarFotoAlterada(atualizado);
                if (ctrl instanceof TelaController tc) {
                    tc.aoAtualizarAvatar(atualizado);
                }
                msgNome.setText("Nome atualizado com sucesso.");
                msgNome.setStyle("-fx-text-fill: #6bcb77; -fx-font-size: 11px;");
            } catch (Exception ex) {
                ex.printStackTrace();
                msgNome.setText("Erro ao salvar: " + ex.getMessage());
                msgNome.setStyle("-fx-text-fill: #ff6b6b; -fx-font-size: 11px;");
            }
        });

        VBox blocoNome = new VBox(6, lblNome, campoNome, btnSalvarNome, msgNome);
        blocoNome.setMaxWidth(Double.MAX_VALUE);

        // —— Info da conta (somente leitura) ——
        String ultimoAcesso = app.getUltimoAcessoFormatado(usuario);
        String acessoAgora = app.getAcessoAtualFormatado();

        VBox info = new VBox(10);
        info.setPadding(new Insets(16));
        info.setStyle(
                "-fx-background-color: " + p.overlay() + "0.07);" +
                "-fx-background-radius: 16;" +
                "-fx-border-color: " + p.borda() + ";" +
                "-fx-border-radius: 16;" +
                "-fx-border-width: 1;"
        );
        info.getChildren().addAll(
                linhaInfo("E-mail / login", login, p),
                linhaInfo("Status", "Online", p),
                linhaInfo("Último acesso", ultimoAcesso, p),
                linhaInfo("Acesso atual", acessoAgora, p)
        );

        Button fechar = botaoSecundario("Fechar", p);
        fechar.setMaxWidth(Double.MAX_VALUE);
        fechar.setPrefHeight(42);
        fechar.setOnAction(event -> {
            // força atualizar avatar/nome no painel
            try {
                Usuario u = app.getUsuarioAtual();
                Object ctrl = Navegador.controladorAtual();
                if (ctrl instanceof TelaController tc) {
                    tc.aoAtualizarAvatar(u);
                }
            } catch (Exception ignored) {
            }
            janela.close();
        });

        cartao.getChildren().addAll(
                criarTitulo("Meu perfil", p),
                blocoFoto,
                badge,
                blocoNome,
                info,
                fechar
        );

        exibirJanela(janela, cartao);
    }

    private static HBox linhaInfo(String rotulo, String valor, Paleta p) {
        Label r = new Label(rotulo);
        r.setStyle("-fx-text-fill: " + p.textoTerc() + "; -fx-font-size: 11px;");
        r.setMinWidth(110);
        Label v = new Label(valor);
        v.setStyle("-fx-text-fill: " + p.texto() + "; -fx-font-size: 12px; -fx-font-weight: bold;");
        v.setWrapText(true);
        HBox.setHgrow(v, Priority.ALWAYS);
        HBox linha = new HBox(8, r, v);
        linha.setAlignment(Pos.CENTER_LEFT);
        return linha;
    }

    public static VBox blocoPerfil(String titulo, Node... linhas) {
        Paleta p = paletaAtual();
        VBox bloco = new VBox(6);
        bloco.setPadding(new Insets(14));
        bloco.setStyle(
                "-fx-background-color: " + p.overlay() + "0.07);" +
                "-fx-background-radius: 18;" +
                "-fx-border-color: " + p.borda() + ";" +
                "-fx-border-radius: 18;" +
                "-fx-border-width: 1;"
        );
        Label cabecalho = criarTexto(titulo, p);
        cabecalho.setStyle(
                "-fx-text-fill: " + p.texto() + ";" +
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;"
        );
        bloco.getChildren().add(cabecalho);
        bloco.getChildren().addAll(linhas);
        return bloco;
    }

    public static HBox linhaPerfil(String campo, String valor, Paleta p) {
        Label campoLabel = new Label(campo);
        campoLabel.setMinWidth(145);
        campoLabel.setStyle(
                "-fx-text-fill: " + p.textoTerc() + ";" +
                "-fx-font-size: 11px;"
        );

        Label valorLabel = new Label(valor);
        valorLabel.setWrapText(true);
        valorLabel.setMaxWidth(320);
        valorLabel.setStyle(
                "-fx-text-fill: " + p.texto() + ";" +
                "-fx-font-size: 12px;"
        );

        HBox linha = new HBox(10, campoLabel, valorLabel);
        linha.setAlignment(Pos.CENTER_LEFT);
        return linha;
    }

    public static String valorOuPadrao(String valor, String padrao) {
        return valor == null || valor.isBlank() ? padrao : valor;
    }

    public static String iniciaisUsuario(String nome) {
        String[] partes = nome.trim().split("\\s+");
        if (partes.length == 0 || nome.isBlank()) return "U";
        String primeira = partes[0].substring(0, 1).toUpperCase();
        if (partes.length == 1) return primeira;
        String ultima = partes[partes.length - 1].substring(0, 1).toUpperCase();
        return primeira + ultima;
    }



    // Áreas de foto (perfil, editor...) que estão abertas; todas atualizam juntas.
    private record FotoAtiva(StackPane area, Runnable atualizar) {
    }

    private static final java.util.List<FotoAtiva> FOTOS_ATIVAS = new java.util.ArrayList<>();

    private static void registrarFotoAtiva(StackPane area, ImageView foto, Usuario usuario, double tamanho) {
        FOTOS_ATIVAS.add(new FotoAtiva(area, () -> {
            // Usa o usuário mais recente da sessão (o nome pode ter mudado → iniciais novas).
            Usuario sessao = app.getUsuarioAtual();
            Usuario atual = (sessao != null && sessao.getLogin() != null
                    && sessao.getLogin().equalsIgnoreCase(usuario.getLogin())) ? sessao : usuario;
            carregarFotoNoImageView(atual, foto, tamanho);
            atualizarVisualFoto(area, foto, atual, tamanho);
        }));
    }

    /**
     * Chame sempre que a foto (ou o nome) mudar: atualiza o botão do cabeçalho,
     * a foto do "Meu perfil" e o editor, tudo de uma vez.
     */
    public static void notificarFotoAlterada(Usuario usuario) {
        for (FotoAtiva f : new java.util.ArrayList<>(FOTOS_ATIVAS)) {
            Scene cena = f.area().getScene();
            if (cena == null || cena.getWindow() == null || !cena.getWindow().isShowing()) {
                FOTOS_ATIVAS.remove(f); // janela já fechada
                continue;
            }
            try {
                f.atualizar().run();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        atualizarAvatarDashboard(usuario);
    }

    /** Área circular clicável e com suporte a arrastar/soltar uma imagem. */
    public static StackPane criarAreaFotoPerfil(Usuario usuario, Paleta p, double tamanho) {
        ImageView foto = new ImageView();
        foto.setFitWidth(tamanho);
        foto.setFitHeight(tamanho);
        foto.setPreserveRatio(true);
        foto.setSmooth(true);
        foto.setClip(new Circle(tamanho / 2, tamanho / 2, tamanho / 2));

        StackPane area = new StackPane();
        area.setPrefSize(tamanho, tamanho);
        area.setMinSize(tamanho, tamanho);
        area.setMaxSize(tamanho, tamanho);
        area.setStyle(estiloAreaFoto(p, tamanho, false));
        area.getChildren().add(foto);
        // Carrega a foto salva imediatamente (antes só atualizava no notificar)
        carregarFotoNoImageView(usuario, foto, tamanho);
        atualizarVisualFoto(area, foto, usuario, tamanho);
        registrarFotoAtiva(area, foto, usuario, tamanho);

        Tooltip.install(area, new Tooltip("Clique para trocar ou arraste uma imagem para cá"));
        area.setOnMouseClicked(event -> abrirEditorFotoPerfil(usuario, p, tamanho));

        area.setOnDragOver(event -> {
            if (event.getGestureSource() != area && event.getDragboard().hasFiles()) {
                event.acceptTransferModes(javafx.scene.input.TransferMode.COPY);
            }
            event.consume();
        });
        area.setOnDragEntered(event -> {
            if (event.getDragboard().hasFiles()) {
                area.setStyle(estiloAreaFoto(p, tamanho, true));
            }
            event.consume();
        });
        area.setOnDragExited(event -> {
            area.setStyle(estiloAreaFoto(p, tamanho, false));
            event.consume();
        });
        area.setOnDragDropped(event -> {
            boolean sucesso = false;
            try {
                if (event.getDragboard().hasFiles()) {
                    File arquivo = event.getDragboard().getFiles().get(0);
                    sucesso = salvarFotoLocal(usuario, arquivo);
                    if (sucesso) {
                        notificarFotoAlterada(usuario);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            event.setDropCompleted(sucesso);
            event.consume();
        });

        return area;
    }

    public static String estiloAreaFoto(Paleta p, double tamanho, boolean destaque) {
        return "-fx-background-color: " + fundoDestaque() + ";" +
                "-fx-background-radius: " + (tamanho / 2) + ";" +
                "-fx-border-color: " + (destaque ? "white" : p.borda()) + ";" +
                "-fx-border-width: " + (destaque ? "3" : "1.5") + ";" +
                "-fx-border-radius: " + (tamanho / 2) + ";";
    }

    public static void atualizarVisualFoto(StackPane area, ImageView foto, Usuario usuario, double tamanho) {
        if (area == null || foto == null || usuario == null) return;

        // Mantém o placeholder atrás da imagem. Assim, se a foto terminar
        // de carregar alguns instantes depois, ela nunca fica escondida.
        area.getChildren().clear();

        Label iniciais = new Label(iniciaisUsuario(valorOuPadrao(usuario.getNome(), "Usuário")));
        iniciais.setMinSize(tamanho, tamanho);
        iniciais.setPrefSize(tamanho, tamanho);
        iniciais.setMaxSize(tamanho, tamanho);
        iniciais.setAlignment(Pos.CENTER);
        iniciais.setStyle(
                "-fx-background-color: " + fundoDestaque() + ";" +
                "-fx-background-radius: " + (tamanho / 2) + ";" +
                "-fx-text-fill: " + textoSobreDestaque() + ";" +
                "-fx-font-size: " + Math.max(24, tamanho * 0.28) + "px;" +
                "-fx-font-weight: bold;"
        );

        // Placeholder primeiro; a foto fica por cima quando estiver disponível.
        area.getChildren().addAll(iniciais, foto);
        atualizarEstadoVisualFoto(foto, iniciais);

        // URLs podem terminar de carregar depois da criação do ImageView.
        // O listener garante que o avatar seja atualizado automaticamente.
        if (!Boolean.TRUE.equals(foto.getProperties().get("mecha-foto-listener"))) {
            foto.getProperties().put("mecha-foto-listener", Boolean.TRUE);
            foto.imageProperty().addListener((obs, antiga, nova) ->
                    Platform.runLater(() -> atualizarEstadoVisualFoto(foto, iniciais)));
        }
    }

    public static void atualizarEstadoVisualFoto(ImageView foto, Label iniciais) {
        if (foto == null || iniciais == null) return;
        Image imagem = foto.getImage();
        boolean disponivel = imagem != null && !imagem.isError();
        foto.setVisible(disponivel);
        foto.setManaged(disponivel);
        iniciais.setVisible(!disponivel);
        iniciais.setManaged(!disponivel);
    }

    public static void abrirEditorFotoPerfil(Usuario usuario, Paleta p, double tamanho) {
        try {
            Stage janela = criarJanelaTematica();
            VBox cartao = criarCartaoTematico(540, p);
            cartao.setSpacing(14);

            Label instrucoes = criarTexto(
                    "Você pode selecionar uma imagem do computador, arrastar e soltar sobre o avatar ou usar um link.", p);
            instrucoes.setWrapText(true);

            ImageView preview = new ImageView();
            preview.setFitWidth(160);
            preview.setFitHeight(160);
            preview.setPreserveRatio(true);
            preview.setSmooth(true);
            preview.setClip(new Circle(80, 80, 80));
            carregarFotoNoImageView(usuario, preview, 160);

            StackPane previewArea = new StackPane(preview);
            previewArea.setPrefSize(160, 160);
            previewArea.setMinSize(160, 160);
            previewArea.setMaxSize(160, 160);
            atualizarVisualFoto(previewArea, preview, usuario, 160);
            previewArea.setStyle(estiloAreaFoto(p, 160, false));
            registrarFotoAtiva(previewArea, preview, usuario, 160);

            // Também aceita drag-and-drop diretamente no editor.
            configurarDropFoto(previewArea, preview, usuario, 160, p);

            Button selecionar = botaoPrimario("Selecionar imagem", p);
            selecionar.setOnAction(e -> {
                try {
                    javafx.stage.FileChooser chooser = new javafx.stage.FileChooser();
                    chooser.setTitle("Escolher foto de perfil");
                    chooser.getExtensionFilters().add(
                            new javafx.stage.FileChooser.ExtensionFilter(
                                    "Imagens", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.webp"));
                    File arquivo = chooser.showOpenDialog(janela);
                    if (arquivo != null && salvarFotoLocal(usuario, arquivo)) {
                        notificarFotoAlterada(usuario);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    mostrarMensagem("Foto de perfil", "Não foi possível carregar a imagem.");
                }
            });

            Button remover = botaoSecundario("Remover foto", p);
            remover.setOnAction(e -> {
                app.removerFotoPerfil(usuario);
                notificarFotoAlterada(usuario);
            });

            HBox botoes = new HBox(10, selecionar, remover);
            botoes.setAlignment(Pos.CENTER);

            Label dica = criarTexto(
                    "Escolha uma imagem do computador ou arraste um arquivo para a área de pré-visualização.", p);
            dica.setWrapText(true);

            Button fechar = botaoSecundario("Fechar", p);
            fechar.setOnAction(e -> janela.close());

            cartao.getChildren().addAll(
                    criarTitulo("Foto de perfil", p),
                    instrucoes,
                    previewArea,
                    botoes,
                    dica,
                    fechar
            );
            exibirJanela(janela, cartao);
        } catch (Exception e) {
            e.printStackTrace();
            mostrarMensagem("Foto de perfil", "Não foi possível abrir o editor de foto.");
        }
    }

    public static void configurarDropFoto(StackPane area, ImageView preview, Usuario usuario, double tamanho, Paleta p) {
        area.setOnDragOver(event -> {
            if (event.getGestureSource() != area && event.getDragboard().hasFiles()) {
                event.acceptTransferModes(javafx.scene.input.TransferMode.COPY);
            }
            event.consume();
        });
        area.setOnDragEntered(event -> {
            if (event.getDragboard().hasFiles()) area.setStyle(estiloAreaFoto(p, tamanho, true));
            event.consume();
        });
        area.setOnDragExited(event -> {
            area.setStyle(estiloAreaFoto(p, tamanho, false));
            event.consume();
        });
        area.setOnDragDropped(event -> {
            boolean sucesso = false;
            try {
                if (event.getDragboard().hasFiles()) {
                    sucesso = salvarFotoLocal(usuario, event.getDragboard().getFiles().get(0));
                    if (sucesso) {
                        notificarFotoAlterada(usuario);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            event.setDropCompleted(sucesso);
            event.consume();
        });
    }

    public static boolean salvarFotoLocal(Usuario usuario, File arquivo) {
        if (arquivo == null || !arquivo.isFile() || !isImagem(arquivo.getName())) return false;
        try {
            if (Tema.modoDebug()) {
                // Modo de teste: não copia nada para a pasta do sistema, só usa o arquivo original.
                app.setFotoPerfil(usuario, arquivo.getAbsolutePath());
                return true;
            }
            String ext = extensaoImagem(arquivo.getName());
            Path destino = destinoFoto(usuario, ext);
            if (!arquivo.toPath().toAbsolutePath().equals(destino.toAbsolutePath())) {
                Files.copy(arquivo.toPath(), destino, StandardCopyOption.REPLACE_EXISTING);
            }
            limparFotosAntigas(usuario, destino);
            app.setFotoPerfil(usuario, destino.toString());
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /** Caminho onde a foto do usuário é guardada (arquivo temporário no modo de teste). */
    private static Path destinoFoto(Usuario usuario, String ext) throws java.io.IOException {
        if (Tema.modoDebug()) {
            Path tmp = Files.createTempFile("mecha-foto-", "." + ext);
            tmp.toFile().deleteOnExit();
            return tmp;
        }
        Path pasta = Paths.get(System.getProperty("user.home"), ".mecha-consertos", "perfil");
        Files.createDirectories(pasta);
        String nomeSeguro = Integer.toHexString(usuario.getLogin().toLowerCase(java.util.Locale.ROOT).hashCode());
        return pasta.resolve(nomeSeguro + "." + ext);
    }

    /** Apaga fotos antigas do mesmo usuário com outra extensão (evita lixo e foto errada). */
    private static void limparFotosAntigas(Usuario usuario, Path atual) {
        try {
            Path pasta = atual.getParent();
            String nomeSeguro = Integer.toHexString(usuario.getLogin().toLowerCase(java.util.Locale.ROOT).hashCode());
            try (var arquivos = Files.list(pasta)) {
                arquivos.filter(f -> f.getFileName().toString().startsWith(nomeSeguro + "."))
                        .filter(f -> !f.equals(atual))
                        .forEach(f -> {
                            try {
                                Files.deleteIfExists(f);
                            } catch (Exception ignored) {
                            }
                        });
            }
        } catch (Exception ignored) {
        }
    }

    /**
     * Baixa a imagem do link e salva localmente (mais confiável que carregar URL direto no ImageView).
     */
    public static boolean salvarFotoUrl(Usuario usuario, String url) {
        try {
            String valor = url == null ? "" : url.trim();
            if (!(valor.startsWith("http://") || valor.startsWith("https://"))) return false;

            HttpURLConnection conn = (HttpURLConnection) new URL(valor).openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(15000);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (MechaConsertos/1.0)");
            conn.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
            int code = conn.getResponseCode();
            // segue um redirect manual se necessário
            if (code >= 300 && code < 400) {
                String loc = conn.getHeaderField("Location");
                conn.disconnect();
                if (loc == null || loc.isBlank()) return false;
                conn = (HttpURLConnection) new URL(loc).openConnection();
                conn.setConnectTimeout(12000);
                conn.setReadTimeout(15000);
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (MechaConsertos/1.0)");
                code = conn.getResponseCode();
            }
            if (code < 200 || code >= 300) {
                conn.disconnect();
                return false;
            }
            String contentType = conn.getContentType();
            if (contentType != null && !contentType.toLowerCase(java.util.Locale.ROOT).startsWith("image/")
                    && !contentType.toLowerCase(java.util.Locale.ROOT).contains("octet-stream")) {
                // alguns CDNs não mandam content-type de imagem; ainda tenta
            }

            String ext = "jpg";
            if (contentType != null) {
                String ct = contentType.toLowerCase(java.util.Locale.ROOT);
                if (ct.contains("png")) ext = "png";
                else if (ct.contains("gif")) ext = "gif";
                else if (ct.contains("webp")) ext = "webp";
                else if (ct.contains("jpeg") || ct.contains("jpg")) ext = "jpg";
            } else {
                String lower = valor.toLowerCase(java.util.Locale.ROOT);
                if (lower.contains(".png")) ext = "png";
                else if (lower.contains(".gif")) ext = "gif";
                else if (lower.contains(".webp")) ext = "webp";
            }

            Path destino = destinoFoto(usuario, ext);

            try (InputStream in = conn.getInputStream();
                 OutputStream out = Files.newOutputStream(destino)) {
                in.transferTo(out);
            }
            conn.disconnect();

            // valida se o JavaFX consegue ler
            Image teste = new Image(destino.toUri().toString(), 120, 120, true, true, false);
            if (teste.isError()) {
                Files.deleteIfExists(destino);
                return false;
            }
            limparFotosAntigas(usuario, destino);
            app.setFotoPerfil(usuario, destino.toString());
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void carregarFotoNoImageView(Usuario usuario, ImageView imagem, double tamanho) {
        if (usuario == null || imagem == null) return;
        String fonte = app.getFotoPerfil(usuario);
        if (fonte == null || fonte.isBlank()) {
            imagem.setImage(null);
            return;
        }
        try {
            String local;
            if (fonte.startsWith("http://") || fonte.startsWith("https://")) {
                // links antigos: tenta baixar e converter para arquivo local
                if (salvarFotoUrl(usuario, fonte)) {
                    fonte = app.getFotoPerfil(usuario);
                }
            }
            Path path = Paths.get(fonte);
            if (!Files.exists(path)) {
                imagem.setImage(null);
                return;
            }
            local = path.toUri().toString();
            // Carrega em resolução maior e recorta o quadrado central (efeito "cover"),
            // para a foto preencher o círculo inteiro, mesmo sendo retangular.
            // backgroundLoading=false para arquivo local (já no disco)
            Image image = new Image(local, tamanho * 2, tamanho * 2, true, true, false);
            if (image.isError() || image.getWidth() <= 0) {
                // tenta sem resize forçado
                image = new Image(local, true);
                if (image.isError()) {
                    imagem.setImage(null);
                    imagem.setViewport(null);
                    return;
                }
            }
            ajustarFotoNoCirculo(imagem, image, tamanho);
        } catch (Exception e) {
            e.printStackTrace();
            imagem.setImage(null);
        }
    }

    /**
     * Faz a imagem preencher todo o círculo: recorta o maior quadrado centralizado
     * (como o object-fit: cover do CSS) em vez de encolher a imagem para caber.
     */
    public static void ajustarFotoNoCirculo(ImageView iv, Image image, double tamanho) {
        double w = image.getWidth();
        double h = image.getHeight();
        double lado = Math.min(w, h);
        iv.setImage(image);
        iv.setViewport(new Rectangle2D((w - lado) / 2, (h - lado) / 2, lado, lado));
        iv.setPreserveRatio(true);
        iv.setFitWidth(tamanho);
        iv.setFitHeight(tamanho);
        iv.setSmooth(true);
        iv.setClip(new Circle(tamanho / 2, tamanho / 2, tamanho / 2));
    }

    public static void atualizarAvatarDashboard(Usuario usuario) {
        if (usuario == null) return;
        if (Navegador.controladorAtual() instanceof TelaController tela) {
            tela.aoAtualizarAvatar(usuario);
        }
    }

    public static void atualizarBotaoUsuario(Button botao, Usuario usuario) {
        if (botao == null || usuario == null) return;

        // Só avatar no botão — o nome completo fica no Label ao lado (usuarioTexto)
        String fonte = app.getFotoPerfil(usuario);
        botao.setMinSize(52, 52);
        botao.setPrefSize(52, 52);
        botao.setMaxSize(52, 52);
        if (fonte == null || fonte.isBlank()) {
            botao.setGraphic(null);
            botao.setText("👤");
            botao.setStyle(
                    (botao.getStyle() == null ? "" : botao.getStyle()) +
                    ";-fx-font-size: 22px; -fx-background-radius: 26; -fx-background-color: rgba(255,255,255,0.10);"
            );
        } else {
            try {
                String local = fonte;
                if (!fonte.startsWith("http://") && !fonte.startsWith("https://")) {
                    Path path = Paths.get(fonte);
                    if (!Files.exists(path)) throw new IllegalArgumentException("Foto não encontrada");
                    local = path.toUri().toString();
                }
                Image image = new Image(local, 96, 96, true, true, false);
                if (image.isError()) throw new IllegalArgumentException("Imagem inválida");
                ImageView iv = new ImageView();
                ajustarFotoNoCirculo(iv, image, 44);
                botao.setText("");
                botao.setGraphic(iv);
                botao.setMinSize(52, 52);
                botao.setPrefSize(52, 52);
                botao.setMaxSize(52, 52);
            } catch (Exception e) {
                botao.setGraphic(null);
                botao.setText("👤");
            }
        }
        String tip = (usuario.getNome() != null ? usuario.getNome() : "Usuário") + " — Minha conta";
        if (botao.getTooltip() == null) {
            botao.setTooltip(new Tooltip(tip));
        } else {
            botao.getTooltip().setText(tip);
        }
    }

    public static boolean isImagem(String nome) {
        String n = nome == null ? "" : nome.toLowerCase(java.util.Locale.ROOT);
        return n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") ||
                n.endsWith(".gif") || n.endsWith(".webp");
    }

    public static String extensaoImagem(String nome) {
        int indice = nome.lastIndexOf('.');
        return indice >= 0 ? nome.substring(indice + 1).toLowerCase(java.util.Locale.ROOT) : "png";
    }
}
