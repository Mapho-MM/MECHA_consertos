package com.senai.javafx.projeto02.entidades;

import java.util.ArrayList;
import java.util.List;
import java.time.LocalDateTime;

public class Servico {
    private int quantidadeUsos;
    private double preco;
    private String nome;
    private Status status = Status.ORCAMENTO;
    private final ArrayList<Mecanico> mecanicos = new ArrayList<>();
    /** Número do orçamento / OS vinculado (quando existir). */
    private Integer numeroOrcamento;
    private String defeito;
    private String diagnostico;
    private String observacoes;
    private LocalDateTime dataHoraInicio;
    private LocalDateTime previsaoConclusao;
    private LocalDateTime dataHoraConclusao;

    public Servico(double preco, String nome) {
        this.preco = preco;
        this.nome = nome;
    }

    /** Cópia para vincular a um veículo sem compartilhar status do catálogo. */
    public Servico copiar() {
        Servico c = new Servico(this.preco, this.nome);
        c.status = Status.ORCAMENTO;
        return c;
    }

    public int getQuantidadeUsos() { return quantidadeUsos; }
    public double getPreco() { return preco; }
    public String getNome() { return nome; }
    public Status getStatus() { return status; }
    public List<Mecanico> getMecanicos() { return mecanicos; }
    public Integer getNumeroOrcamento() { return numeroOrcamento; }
    public String getDefeito() { return defeito; }
    public String getDiagnostico() { return diagnostico; }
    public String getObservacoes() { return observacoes; }
    public LocalDateTime getDataHoraInicio() { return dataHoraInicio; }
    public LocalDateTime getPrevisaoConclusao() { return previsaoConclusao; }
    public LocalDateTime getDataHoraConclusao() { return dataHoraConclusao; }

    public void incrementarUso() { quantidadeUsos++; }
    public void setPreco(double preco) { this.preco = preco; }
    public void setNome(String nome) { this.nome = nome; }
    public void setStatus(Status status) { this.status = status; }
    public void setNumeroOrcamento(Integer numeroOrcamento) { this.numeroOrcamento = numeroOrcamento; }
    public void setDefeito(String defeito) { this.defeito = defeito; }
    public void setDiagnostico(String diagnostico) { this.diagnostico = diagnostico; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }
    public void setDataHoraInicio(LocalDateTime dataHoraInicio) { this.dataHoraInicio = dataHoraInicio; }
    public void setPrevisaoConclusao(LocalDateTime previsaoConclusao) { this.previsaoConclusao = previsaoConclusao; }
    public void setDataHoraConclusao(LocalDateTime dataHoraConclusao) { this.dataHoraConclusao = dataHoraConclusao; }

    public boolean adicionarMecanico(Mecanico mecanico) {
        if (mecanico == null || mecanicos.contains(mecanico)) return false;
        return mecanicos.add(mecanico);
    }

    public boolean removerMecanico(Mecanico mecanico) {
        return mecanicos.remove(mecanico);
    }

    /**
     * Avança o status no fluxo oficial:
     * ORCAMENTO → AGENDADO → ANDAMENTO → FINALIZADO
     */
    public boolean avancarStatus(Status novoStatus) {
        if (status == Status.ORCAMENTO && novoStatus == Status.AGENDADO) {
            status = novoStatus;
            return true;
        }
        if (status == Status.AGENDADO && novoStatus == Status.ANDAMENTO) {
            status = novoStatus;
            if (dataHoraInicio == null) dataHoraInicio = LocalDateTime.now();
            return true;
        }
        if (status == Status.ANDAMENTO && novoStatus == Status.FINALIZADO) {
            status = novoStatus;
            if (dataHoraInicio == null) dataHoraInicio = LocalDateTime.now();
            dataHoraConclusao = LocalDateTime.now();
            return true;
        }
        // Compatibilidade: permitir ORCAMENTO → ANDAMENTO
        if (status == Status.ORCAMENTO && novoStatus == Status.ANDAMENTO) {
            status = novoStatus;
            if (dataHoraInicio == null) dataHoraInicio = LocalDateTime.now();
            return true;
        }
        return false;
    }
}
