package com.senai.javafx.projeto02.entidades;

/**
 * Item de estoque da oficina.
 * {@code aposAbertura} indica se o produto foi cadastrado pelo usuário após a abertura do sistema
 * (em oposição aos itens de demonstração carregados no seed inicial).
 */
public class Estoque {
    private String produto;
    private int quantidade;
    private double preco;
    /** true = cadastrado após abertura do sistema; false = item do seed inicial. */
    private boolean aposAbertura = true;

    public Estoque(String produto, int quantidade, double preco) {
        this(produto, quantidade, preco, true);
    }

    public Estoque(String produto, int quantidade, double preco, boolean aposAbertura) {
        this.produto = produto;
        this.quantidade = quantidade;
        this.preco = preco;
        this.aposAbertura = aposAbertura;
    }

    public String getProduto() { return produto; }
    public int getQuantidade() { return quantidade; }
    public double getPreco() { return preco; }
    public boolean isAposAbertura() { return aposAbertura; }

    public void setProduto(String produto) { this.produto = produto; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }
    public void setPreco(double preco) { this.preco = preco; }
    public void setAposAbertura(boolean aposAbertura) { this.aposAbertura = aposAbertura; }
}
