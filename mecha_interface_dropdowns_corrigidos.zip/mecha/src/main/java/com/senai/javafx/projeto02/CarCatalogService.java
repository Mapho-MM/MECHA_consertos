package com.senai.javafx.projeto02;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.*;
import java.util.stream.Collectors;

/** Catálogo local de marcas e modelos; funciona sem internet. */
public final class CarCatalogService {
    private static final Map<String, List<String>> CATALOGO = carregar();
    private CarCatalogService() {}

    public record Identificacao(String marca, String modelo) {}

    private static Map<String, List<String>> carregar() {
        Map<String, List<String>> mapa = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        try (InputStream in = CarCatalogService.class.getResourceAsStream("/com/senai/javafx/projeto02/car-catalog.tsv")) {
            if (in == null) return Collections.unmodifiableMap(mapa);
            try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String linha;
                while ((linha = br.readLine()) != null) {
                    String[] p = linha.split("\\t", 2);
                    if (p.length == 2) mapa.computeIfAbsent(p[0].trim(), k -> new ArrayList<>()).add(p[1].trim());
                }
            }
        } catch (Exception ignored) { }
        mapa.replaceAll((k, v) -> v.stream().distinct().sorted(String.CASE_INSENSITIVE_ORDER).collect(Collectors.toList()));
        return Collections.unmodifiableMap(mapa);
    }

    public static List<String> marcas() { return List.copyOf(CATALOGO.keySet()); }
    public static List<String> modelos(String marca) {
        if (marca == null || marca.isBlank()) return CATALOGO.values().stream().flatMap(Collection::stream).distinct().sorted(String.CASE_INSENSITIVE_ORDER).toList();
        return CATALOGO.entrySet().stream().filter(e -> normalizar(e.getKey()).equals(normalizar(marca.trim())))
                .findFirst().map(Map.Entry::getValue).orElse(List.of());
    }

    /** Reconhece entradas como "Fiat Uno", "Uno", "Toyota Corolla" ou a marca isolada. */
    public static Optional<Identificacao> detectar(String entrada) {
        if (entrada == null || entrada.isBlank()) return Optional.empty();
        String texto = entrada.trim().replaceAll("\\s+", " ");
        String n = normalizar(texto);
        // Primeiro procura a combinação mais longa marca + modelo.
        for (String marca : CATALOGO.keySet().stream().sorted(Comparator.comparingInt((String s) -> s.length()).reversed()).toList()) {
            String mn = normalizar(marca);
            if (n.equals(mn)) return Optional.of(new Identificacao(marca, ""));
            if (n.startsWith(mn + " ")) {
                String resto = texto.substring(Math.min(texto.length(), marca.length())).trim();
                Optional<String> modelo = melhorModelo(marca, resto);
                if (modelo.isPresent()) return Optional.of(new Identificacao(marca, modelo.get()));
            }
        }
        // Se o usuário digitou apenas o modelo, tenta encontrar uma correspondência única.
        List<Identificacao> achados = new ArrayList<>();
        for (var e : CATALOGO.entrySet()) {
            Optional<String> m = melhorModelo(e.getKey(), texto);
            m.ifPresent(v -> achados.add(new Identificacao(e.getKey(), v)));
        }
        if (achados.size() == 1) return Optional.of(achados.get(0));
        // Quando há modelos repetidos entre marcas, não adivinha a marca.
        return Optional.empty();
    }

    private static Optional<String> melhorModelo(String marca, String texto) {
        String n = normalizar(texto);
        return modelos(marca).stream().filter(m -> {
            String mn = normalizar(m);
            return n.equals(mn) || n.startsWith(mn + " ");
        }).sorted(Comparator.comparingInt((String m) -> normalizar(m).length()).reversed()).findFirst();
    }

    private static String normalizar(String s) {
        return Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim().replaceAll("\\s+", " ");
    }
}
