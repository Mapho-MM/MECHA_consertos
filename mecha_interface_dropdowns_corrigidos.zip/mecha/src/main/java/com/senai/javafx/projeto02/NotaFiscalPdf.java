package com.senai.javafx.projeto02;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.MemoryCacheImageOutputStream;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Gera um PDF de uma página com a imagem da nota (alta qualidade).
 */
final class NotaFiscalPdf {

    private NotaFiscalPdf() {
    }

    static void escrever(BufferedImage imagem, OutputStream out) throws IOException {
        if (imagem == null || imagem.getWidth() < 1 || imagem.getHeight() < 1) {
            throw new IOException("A imagem da nota está vazia.");
        }

        BufferedImage rgb = new BufferedImage(imagem.getWidth(), imagem.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D g = rgb.createGraphics();
        try {
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(java.awt.Color.WHITE);
            g.fillRect(0, 0, rgb.getWidth(), rgb.getHeight());
            g.drawImage(imagem, 0, 0, null);
        } finally {
            g.dispose();
        }

        byte[] jpeg = jpegAltaQualidade(rgb);

        // Página em pontos: 2x snapshot ≈ 192 dpi → 72/192
        double scale = 72.0 / 192.0;
        double pageW = imagem.getWidth() * scale;
        double pageH = imagem.getHeight() * scale;
        // Garante proporção legível (largura mínima A4-ish se muito estreito)
        if (pageW < 400) {
            double f = 400.0 / pageW;
            pageW *= f;
            pageH *= f;
        }

        List<byte[]> objetos = new ArrayList<>();
        objetos.add(obj("<< /Type /Catalog /Pages 2 0 R >>"));
        objetos.add(obj("<< /Type /Pages /Kids [3 0 R] /Count 1 >>"));
        objetos.add(obj(String.format(
                "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2f %.2f] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>",
                pageW, pageH)));
        String imgHeader = String.format(
                "<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length %d >>\nstream\n",
                rgb.getWidth(), rgb.getHeight(), jpeg.length);
        byte[] imgObj = concat(imgHeader.getBytes(StandardCharsets.US_ASCII), jpeg, "\nendstream".getBytes(StandardCharsets.US_ASCII));
        objetos.add(imgObj);
        String content = String.format("q %.2f 0 0 %.2f 0 0 cm /Im0 Do Q", pageW, pageH);
        byte[] contentBytes = content.getBytes(StandardCharsets.US_ASCII);
        String contentObj = String.format("<< /Length %d >>\nstream\n%s\nendstream", contentBytes.length, content);
        objetos.add(obj(contentObj));

        ByteArrayOutputStream pdf = new ByteArrayOutputStream();
        pdf.write("%PDF-1.4\n".getBytes(StandardCharsets.US_ASCII));
        List<Integer> offsets = new ArrayList<>();
        offsets.add(0);
        for (int i = 0; i < objetos.size(); i++) {
            offsets.add(pdf.size());
            pdf.write(String.format("%d 0 obj\n", i + 1).getBytes(StandardCharsets.US_ASCII));
            pdf.write(objetos.get(i));
            pdf.write("\nendobj\n".getBytes(StandardCharsets.US_ASCII));
        }
        int xrefPos = pdf.size();
        pdf.write(String.format("xref\n0 %d\n", objetos.size() + 1).getBytes(StandardCharsets.US_ASCII));
        pdf.write("0000000000 65535 f \n".getBytes(StandardCharsets.US_ASCII));
        for (int i = 1; i <= objetos.size(); i++) {
            pdf.write(String.format("%010d 00000 n \n", offsets.get(i)).getBytes(StandardCharsets.US_ASCII));
        }
        pdf.write(String.format("trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n",
                objetos.size() + 1, xrefPos).getBytes(StandardCharsets.US_ASCII));
        out.write(pdf.toByteArray());
    }

    private static byte[] jpegAltaQualidade(BufferedImage rgb) throws IOException {
        ByteArrayOutputStream jpegBuf = new ByteArrayOutputStream();
        Iterator<ImageWriter> writers = ImageIO.getImageWritersByFormatName("jpeg");
        if (!writers.hasNext()) {
            ImageIO.write(rgb, "jpg", jpegBuf);
            return jpegBuf.toByteArray();
        }
        ImageWriter writer = writers.next();
        ImageWriteParam param = writer.getDefaultWriteParam();
        if (param.canWriteCompressed()) {
            param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
            param.setCompressionQuality(0.95f);
        }
        try (MemoryCacheImageOutputStream ios = new MemoryCacheImageOutputStream(jpegBuf)) {
            writer.setOutput(ios);
            writer.write(null, new IIOImage(rgb, null, null), param);
        } finally {
            writer.dispose();
        }
        return jpegBuf.toByteArray();
    }

    private static byte[] obj(String s) {
        return s.getBytes(StandardCharsets.US_ASCII);
    }

    private static byte[] concat(byte[]... parts) {
        int len = 0;
        for (byte[] p : parts) len += p.length;
        byte[] r = new byte[len];
        int o = 0;
        for (byte[] p : parts) {
            System.arraycopy(p, 0, r, o, p.length);
            o += p.length;
        }
        return r;
    }
}
