package com.senai.javafx.projeto02.entidades;

import java.util.ArrayList;
import java.util.List;

public class Oficina {
    private String nome;
    private final ArrayList<Cliente> clientes = new ArrayList<>();
    private final ArrayList<Estoque> estoque = new ArrayList<>();
    private final ArrayList<Servico> catalogoServicos = new ArrayList<>();
    private final ArrayList<Mecanico> mecanicos = new ArrayList<>();

    public Oficina(String nome) {
        this.nome = nome;
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public List<Cliente> getClientes() { return clientes; }
    public List<Estoque> getEstoque() { return estoque; }
    public List<Servico> getCatalogoServicos() { return catalogoServicos; }
    public List<Mecanico> getMecanicos() { return mecanicos; }
}
