package com.senai.javafx.projeto02.entidades;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/**
 * Persistência preferencial em SQLite (~/.mecha-consertos/oficina.db).
 * Se o driver/módulo falhar, usa arquivo texto legado automaticamente.
 */
public final class PersistenciaOficina {

    private static final Path DIR = Paths.get(System.getProperty("user.home"), ".mecha-consertos");
    private static final Path DB = DIR.resolve("oficina.db");
    private static final Path TEXTO = DIR.resolve("oficina-dados.txt");

    private static boolean carregado = false;
    private static boolean usarSqlite = true;

    private PersistenciaOficina() {
    }

    private static String url() {
        return "jdbc:sqlite:" + DB.toAbsolutePath();
    }

    public static synchronized void carregarSeNecessario() {
        if (carregado) return;
        carregado = true;
        Oficina of = SingleTon.getInstancia().getOficina();
        try {
            Files.createDirectories(DIR);
            Class.forName("org.sqlite.JDBC");
            try (Connection c = DriverManager.getConnection(url())) {
                criarTabelas(c);
                if (estaVazio(c)) {
                    if (Files.exists(TEXTO)) {
                        carregarTexto(of);
                        salvarSqlite(c, of);
                    } else {
                        OficinaService.carregarDadosIniciais(of);
                        salvarSqlite(c, of);
                    }
                } else {
                    carregarSqlite(c, of);
                }
                usarSqlite = true;
                return;
            }
        } catch (Throwable e) {
            System.err.println("[Persistencia] SQLite indisponível, usando arquivo texto: " + e.getMessage());
            usarSqlite = false;
        }
        try {
            if (Files.exists(TEXTO)) {
                carregarTexto(of);
            } else {
                OficinaService.carregarDadosIniciais(of);
                salvarTexto(of);
            }
        } catch (Exception e) {
            e.printStackTrace();
            carregado = false;
            try {
                OficinaService.carregarDadosIniciais(of);
            } catch (Exception ignored) {
            }
        }
    }

    /** Descarta o que está em memória e recarrega do disco (usado ao sair do modo desenvolvedor). */
    public static synchronized void recarregarDoDisco() {
        Oficina of = SingleTon.getInstancia().getOficina();
        try {
            if (usarSqlite) {
                Class.forName("org.sqlite.JDBC");
                try (Connection c = DriverManager.getConnection(url())) {
                    criarTabelas(c);
                    carregarSqlite(c, of);
                    return;
                }
            }
        } catch (Throwable e) {
            System.err.println("[Persistencia] Não foi possível recarregar do SQLite: " + e.getMessage());
        }
        try {
            if (Files.exists(TEXTO)) carregarTexto(of);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static synchronized void salvar() {
        // Modo desenvolvedor = modo de teste: não grava nada no disco.
        if (com.senai.javafx.projeto02.Tema.modoDebug()) return;
        try {
            Files.createDirectories(DIR);
            Oficina of = SingleTon.getInstancia().getOficina();
            if (usarSqlite) {
                try {
                    Class.forName("org.sqlite.JDBC");
                    try (Connection c = DriverManager.getConnection(url())) {
                        criarTabelas(c);
                        salvarSqlite(c, of);
                        return;
                    }
                } catch (Throwable e) {
                    System.err.println("[Persistencia] Falha ao salvar SQLite, caindo para texto: " + e.getMessage());
                    usarSqlite = false;
                }
            }
            salvarTexto(of);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void criarTabelas(Connection c) throws SQLException {
        try (Statement st = c.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS mecanicos (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, salario REAL NOT NULL, login_vinculado TEXT)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS estoque (id INTEGER PRIMARY KEY AUTOINCREMENT, produto TEXT NOT NULL, quantidade INTEGER NOT NULL, preco REAL NOT NULL, apos_abertura INTEGER NOT NULL DEFAULT 1)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS catalogo_servicos (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, preco REAL NOT NULL, usos INTEGER NOT NULL DEFAULT 0)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS clientes (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, cpf TEXT NOT NULL, telefone TEXT NOT NULL, status TEXT NOT NULL)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS veiculos (id INTEGER PRIMARY KEY AUTOINCREMENT, cliente_id INTEGER NOT NULL, placa TEXT NOT NULL, modelo TEXT NOT NULL)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS servicos_exec (id INTEGER PRIMARY KEY AUTOINCREMENT, veiculo_id INTEGER NOT NULL, nome TEXT NOT NULL, preco REAL NOT NULL, status TEXT NOT NULL, inicio TEXT, previsao TEXT, conclusao TEXT)");
            // Migração compatível com bancos já existentes.
            for (String coluna : new String[]{"inicio", "previsao", "conclusao"}) {
                try { st.executeUpdate("ALTER TABLE servicos_exec ADD COLUMN " + coluna + " TEXT"); } catch (SQLException ignored) {}
            }
            try { st.executeUpdate("ALTER TABLE estoque ADD COLUMN apos_abertura INTEGER NOT NULL DEFAULT 1"); } catch (SQLException ignored) {}
            st.executeUpdate("CREATE TABLE IF NOT EXISTS servico_mecanicos (servico_id INTEGER NOT NULL, mecanico_nome TEXT NOT NULL, PRIMARY KEY(servico_id, mecanico_nome))");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS pecas_veiculo (id INTEGER PRIMARY KEY AUTOINCREMENT, veiculo_id INTEGER NOT NULL, produto TEXT NOT NULL, quantidade INTEGER NOT NULL, preco_unitario REAL NOT NULL)");
        }
    }

    private static boolean estaVazio(Connection c) throws SQLException {
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM clientes")) {
            if (rs.next() && rs.getInt(1) > 0) return false;
        }
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM estoque")) {
            if (rs.next() && rs.getInt(1) > 0) return false;
        }
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM mecanicos")) {
            return !(rs.next() && rs.getInt(1) > 0);
        }
    }

    private static void salvarSqlite(Connection c, Oficina of) throws SQLException {
        c.setAutoCommit(false);
        try (Statement st = c.createStatement()) {
            st.executeUpdate("DELETE FROM pecas_veiculo");
            st.executeUpdate("DELETE FROM servico_mecanicos");
            st.executeUpdate("DELETE FROM servicos_exec");
            st.executeUpdate("DELETE FROM veiculos");
            st.executeUpdate("DELETE FROM clientes");
            st.executeUpdate("DELETE FROM catalogo_servicos");
            st.executeUpdate("DELETE FROM estoque");
            st.executeUpdate("DELETE FROM mecanicos");
        }
        try (PreparedStatement ps = c.prepareStatement("INSERT INTO mecanicos(nome, salario, login_vinculado) VALUES (?,?,?)")) {
            for (Mecanico m : of.getMecanicos()) {
                ps.setString(1, m.getNome());
                ps.setDouble(2, m.getSalario());
                ps.setString(3, m.getLoginVinculado());
                ps.executeUpdate();
            }
        }
        try (PreparedStatement ps = c.prepareStatement("INSERT INTO estoque(produto, quantidade, preco, apos_abertura) VALUES (?,?,?,?)")) {
            for (Estoque e : of.getEstoque()) {
                ps.setString(1, e.getProduto());
                ps.setInt(2, e.getQuantidade());
                ps.setDouble(3, e.getPreco());
                ps.setInt(4, e.isAposAbertura() ? 1 : 0);
                ps.executeUpdate();
            }
        } catch (SQLException ex) {
            // Banco antigo sem coluna apos_abertura
            try (PreparedStatement ps = c.prepareStatement("INSERT INTO estoque(produto, quantidade, preco) VALUES (?,?,?)")) {
                for (Estoque e : of.getEstoque()) {
                    ps.setString(1, e.getProduto());
                    ps.setInt(2, e.getQuantidade());
                    ps.setDouble(3, e.getPreco());
                    ps.executeUpdate();
                }
            }
        }
        try (PreparedStatement ps = c.prepareStatement("INSERT INTO catalogo_servicos(nome, preco, usos) VALUES (?,?,?)")) {
            for (Servico s : of.getCatalogoServicos()) {
                ps.setString(1, s.getNome());
                ps.setDouble(2, s.getPreco());
                ps.setInt(3, s.getQuantidadeUsos());
                ps.executeUpdate();
            }
        }
        try (PreparedStatement psCli = c.prepareStatement("INSERT INTO clientes(nome, cpf, telefone, status) VALUES (?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
             PreparedStatement psVei = c.prepareStatement("INSERT INTO veiculos(cliente_id, placa, modelo) VALUES (?,?,?)", Statement.RETURN_GENERATED_KEYS);
             PreparedStatement psSrv = c.prepareStatement("INSERT INTO servicos_exec(veiculo_id, nome, preco, status, inicio, previsao, conclusao) VALUES (?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
             PreparedStatement psMec = c.prepareStatement("INSERT INTO servico_mecanicos(servico_id, mecanico_nome) VALUES (?,?)");
             PreparedStatement psPec = c.prepareStatement("INSERT INTO pecas_veiculo(veiculo_id, produto, quantidade, preco_unitario) VALUES (?,?,?,?)")) {
            for (Cliente cli : of.getClientes()) {
                psCli.setString(1, cli.getNome());
                psCli.setString(2, cli.getCpf());
                psCli.setString(3, cli.getTelefone());
                psCli.setString(4, cli.getStatus() != null ? cli.getStatus().name() : "AGENDADO");
                psCli.executeUpdate();
                int cliId = genId(psCli);
                for (Veiculo v : cli.getCarros()) {
                    psVei.setInt(1, cliId);
                    psVei.setString(2, v.getPlaca());
                    psVei.setString(3, v.getModelo());
                    psVei.executeUpdate();
                    int veiId = genId(psVei);
                    for (Servico s : v.getServicos()) {
                        psSrv.setInt(1, veiId);
                        psSrv.setString(2, s.getNome());
                        psSrv.setDouble(3, s.getPreco());
                        psSrv.setString(4, s.getStatus().name());
                        psSrv.setString(5, s.getDataHoraInicio() == null ? null : s.getDataHoraInicio().toString());
                        psSrv.setString(6, s.getPrevisaoConclusao() == null ? null : s.getPrevisaoConclusao().toString());
                        psSrv.setString(7, s.getDataHoraConclusao() == null ? null : s.getDataHoraConclusao().toString());
                        psSrv.executeUpdate();
                        int srvId = genId(psSrv);
                        for (Mecanico m : s.getMecanicos()) {
                            psMec.setInt(1, srvId);
                            psMec.setString(2, m.getNome());
                            psMec.executeUpdate();
                        }
                    }
                    for (PecaUtilizada p : v.getPecasUtilizadas()) {
                        psPec.setInt(1, veiId);
                        psPec.setString(2, p.getNome());
                        psPec.setInt(3, p.getQuantidade());
                        psPec.setDouble(4, p.getPrecoUnitario());
                        psPec.executeUpdate();
                    }
                }
            }
        }
        c.commit();
        c.setAutoCommit(true);
    }

    private static int genId(PreparedStatement ps) throws SQLException {
        try (ResultSet rs = ps.getGeneratedKeys()) {
            if (rs.next()) return rs.getInt(1);
        }
        throw new SQLException("Sem ID gerado");
    }

    private static void carregarSqlite(Connection c, Oficina of) throws SQLException {
        of.getClientes().clear();
        of.getEstoque().clear();
        of.getCatalogoServicos().clear();
        of.getMecanicos().clear();

        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT nome, salario, login_vinculado FROM mecanicos")) {
            while (rs.next()) {
                of.getMecanicos().add(new Mecanico(rs.getString(1), rs.getDouble(2), rs.getString(3) != null ? rs.getString(3) : ""));
            }
        }
        // Compatível com bancos antigos (sem coluna apos_abertura)
        boolean temApos = false;
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("PRAGMA table_info(estoque)")) {
            while (rs.next()) {
                if ("apos_abertura".equalsIgnoreCase(rs.getString("name"))) { temApos = true; break; }
            }
        }
        String sqlEst = temApos
                ? "SELECT produto, quantidade, preco, apos_abertura FROM estoque"
                : "SELECT produto, quantidade, preco FROM estoque";
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sqlEst)) {
            while (rs.next()) {
                boolean apos = true;
                if (temApos) {
                    try { apos = rs.getInt(4) != 0; } catch (SQLException ignored) { apos = true; }
                }
                of.getEstoque().add(new Estoque(rs.getString(1), rs.getInt(2), rs.getDouble(3), apos));
            }
        }
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT nome, preco, usos FROM catalogo_servicos")) {
            while (rs.next()) {
                Servico s = new Servico(rs.getDouble(2), rs.getString(1));
                for (int i = 0; i < rs.getInt(3); i++) s.incrementarUso();
                of.getCatalogoServicos().add(s);
            }
        }
        Map<Integer, Cliente> clientes = new LinkedHashMap<>();
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT id, nome, cpf, telefone, status FROM clientes")) {
            while (rs.next()) {
                Cliente cli = new Cliente(rs.getString(2), rs.getString(3), rs.getString(4));
                try { cli.setStatus(Status.valueOf(rs.getString(5))); } catch (Exception ignored) {}
                of.getClientes().add(cli);
                clientes.put(rs.getInt(1), cli);
            }
        }
        Map<Integer, Veiculo> veiculos = new LinkedHashMap<>();
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT id, cliente_id, placa, modelo FROM veiculos")) {
            while (rs.next()) {
                Cliente cli = clientes.get(rs.getInt(2));
                if (cli == null) continue;
                Veiculo v = new Veiculo(rs.getString(3), rs.getString(4));
                cli.adicionarVeiculo(v);
                veiculos.put(rs.getInt(1), v);
            }
        }
        Map<Integer, Servico> servicos = new LinkedHashMap<>();
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT id, veiculo_id, nome, preco, status, inicio, previsao, conclusao FROM servicos_exec")) {
            while (rs.next()) {
                Veiculo v = veiculos.get(rs.getInt(2));
                if (v == null) continue;
                Servico s = new Servico(rs.getDouble(4), rs.getString(3));
                try { s.setStatus(Status.valueOf(rs.getString(5))); } catch (Exception ignored) {}
                try { if (rs.getString(6) != null) s.setDataHoraInicio(java.time.LocalDateTime.parse(rs.getString(6))); } catch (Exception ignored) {}
                try { if (rs.getString(7) != null) s.setPrevisaoConclusao(java.time.LocalDateTime.parse(rs.getString(7))); } catch (Exception ignored) {}
                try { if (rs.getString(8) != null) s.setDataHoraConclusao(java.time.LocalDateTime.parse(rs.getString(8))); } catch (Exception ignored) {}
                v.getServicos().add(s);
                servicos.put(rs.getInt(1), s);
            }
        }
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT servico_id, mecanico_nome FROM servico_mecanicos")) {
            while (rs.next()) {
                Servico s = servicos.get(rs.getInt(1));
                if (s == null) continue;
                String nome = rs.getString(2);
                for (Mecanico m : of.getMecanicos()) {
                    if (m.getNome().equals(nome)) { s.adicionarMecanico(m); break; }
                }
            }
        }
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT veiculo_id, produto, quantidade, preco_unitario FROM pecas_veiculo")) {
            while (rs.next()) {
                Veiculo v = veiculos.get(rs.getInt(1));
                if (v == null) continue;
                String produto = rs.getString(2);
                int qtd = rs.getInt(3);
                double preco = rs.getDouble(4);
                Estoque origem = null;
                for (Estoque e : of.getEstoque()) {
                    if (e.getProduto().equals(produto)) { origem = e; break; }
                }
                if (origem == null) origem = new Estoque(produto, 0, preco);
                if (qtd > 0) v.getPecasUtilizadas().add(new PecaUtilizada(origem, qtd));
            }
        }
    }

    private static void salvarTexto(Oficina of) throws Exception {
        List<String> linhas = new ArrayList<>();
        linhas.add("VERSION=1");
        for (Mecanico m : of.getMecanicos()) {
            linhas.add("MEC|" + esc(m.getNome()) + "|" + m.getSalario() + "|" + esc(m.getLoginVinculado()));
        }
        for (Estoque e : of.getEstoque()) {
            linhas.add("EST|" + esc(e.getProduto()) + "|" + e.getQuantidade() + "|" + e.getPreco() + "|" + (e.isAposAbertura() ? "1" : "0"));
        }
        for (Servico s : of.getCatalogoServicos()) {
            linhas.add("CAT|" + esc(s.getNome()) + "|" + s.getPreco() + "|" + s.getQuantidadeUsos());
        }
        for (Cliente c : of.getClientes()) {
            linhas.add("CLI|" + esc(c.getNome()) + "|" + esc(c.getCpf()) + "|" + esc(c.getTelefone())
                    + "|" + (c.getStatus() != null ? c.getStatus().name() : "AGENDADO"));
            for (Veiculo v : c.getCarros()) {
                linhas.add("VEI|" + esc(v.getPlaca()) + "|" + esc(v.getModelo()));
                for (Servico s : v.getServicos()) {
                    StringBuilder mecs = new StringBuilder();
                    for (Mecanico m : s.getMecanicos()) {
                        if (mecs.length() > 0) mecs.append(",");
                        mecs.append(esc(m.getNome()));
                    }
                    linhas.add("SRV|" + esc(s.getNome()) + "|" + s.getPreco() + "|" + s.getStatus().name() + "|" + mecs
                            + "|" + (s.getDataHoraInicio() == null ? "" : s.getDataHoraInicio())
                            + "|" + (s.getPrevisaoConclusao() == null ? "" : s.getPrevisaoConclusao())
                            + "|" + (s.getDataHoraConclusao() == null ? "" : s.getDataHoraConclusao()));
                }
                for (PecaUtilizada p : v.getPecasUtilizadas()) {
                    linhas.add("PEC|" + esc(p.getNome()) + "|" + p.getQuantidade() + "|" + p.getPrecoUnitario());
                }
            }
        }
        Files.write(TEXTO, linhas, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }

    private static void carregarTexto(Oficina of) throws Exception {
        of.getClientes().clear();
        of.getEstoque().clear();
        of.getCatalogoServicos().clear();
        of.getMecanicos().clear();
        List<String> linhas = Files.readAllLines(TEXTO, StandardCharsets.UTF_8);
        Cliente clienteAtual = null;
        Veiculo veiculoAtual = null;
        for (String linha : linhas) {
            if (linha == null || linha.isBlank() || linha.startsWith("VERSION")) continue;
            String[] p = linha.split("\\|", -1);
            switch (p[0]) {
                case "MEC" -> of.getMecanicos().add(new Mecanico(unesc(p[1]), Double.parseDouble(p[2]), p.length > 3 ? unesc(p[3]) : ""));
                case "EST" -> {
                    boolean apos = p.length < 5 || !"0".equals(p[4]);
                    of.getEstoque().add(new Estoque(unesc(p[1]), Integer.parseInt(p[2]), Double.parseDouble(p[3]), apos));
                }
                case "CAT" -> {
                    Servico s = new Servico(Double.parseDouble(p[2]), unesc(p[1]));
                    int usos = p.length > 3 ? Integer.parseInt(p[3]) : 0;
                    for (int i = 0; i < usos; i++) s.incrementarUso();
                    of.getCatalogoServicos().add(s);
                }
                case "CLI" -> {
                    clienteAtual = new Cliente(unesc(p[1]), unesc(p[2]), unesc(p[3]));
                    if (p.length > 4) {
                        try { clienteAtual.setStatus(Status.valueOf(p[4])); } catch (Exception ignored) {}
                    }
                    of.getClientes().add(clienteAtual);
                    veiculoAtual = null;
                }
                case "VEI" -> {
                    if (clienteAtual == null) break;
                    veiculoAtual = new Veiculo(unesc(p[1]), unesc(p[2]));
                    clienteAtual.adicionarVeiculo(veiculoAtual);
                }
                case "SRV" -> {
                    if (veiculoAtual == null) break;
                    Servico s = new Servico(Double.parseDouble(p[2]), unesc(p[1]));
                    try { s.setStatus(Status.valueOf(p[3])); } catch (Exception ignored) {}
                    try { if (p.length > 5 && !p[5].isBlank()) s.setDataHoraInicio(java.time.LocalDateTime.parse(p[5])); } catch (Exception ignored) {}
                    try { if (p.length > 6 && !p[6].isBlank()) s.setPrevisaoConclusao(java.time.LocalDateTime.parse(p[6])); } catch (Exception ignored) {}
                    try { if (p.length > 7 && !p[7].isBlank()) s.setDataHoraConclusao(java.time.LocalDateTime.parse(p[7])); } catch (Exception ignored) {}
                    if (p.length > 4 && !p[4].isBlank()) {
                        for (String nomeM : p[4].split(",")) {
                            String nm = unesc(nomeM);
                            for (Mecanico m : of.getMecanicos()) {
                                if (m.getNome().equals(nm)) { s.adicionarMecanico(m); break; }
                            }
                        }
                    }
                    veiculoAtual.getServicos().add(s);
                }
                case "PEC" -> {
                    if (veiculoAtual == null) break;
                    String nomePeca = unesc(p[1]);
                    int qtd = Integer.parseInt(p[2]);
                    double preco = Double.parseDouble(p[3]);
                    Estoque origem = null;
                    for (Estoque e : of.getEstoque()) {
                        if (e.getProduto().equals(nomePeca)) { origem = e; break; }
                    }
                    if (origem == null) origem = new Estoque(nomePeca, 0, preco);
                    if (qtd > 0) veiculoAtual.getPecasUtilizadas().add(new PecaUtilizada(origem, qtd));
                }
                default -> {}
            }
        }
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("|", "\\|").replace("\n", " ");
    }

    private static String unesc(String s) {
        if (s == null) return "";
        return s.replace("\\|", "|").replace("\\\\", "\\");
    }
}
