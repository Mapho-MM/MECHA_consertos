package com.senai.javafx.projeto02.entidades;

/**
 * Instância única da oficina — ponto central dos cadastros.
 * Inicialização preguiçosa para evitar NPE durante o &lt;clinit&gt;
 * (Persistência não pode chamar getInstancia() enquanto o static final ainda é null).
 */
public final class SingleTon {
    private static volatile SingleTon instancia;
    private final Oficina oficina;

    private SingleTon() {
        oficina = new Oficina("Oficina Mecânica");
    }

    public static SingleTon getInstancia() {
        if (instancia == null) {
            synchronized (SingleTon.class) {
                if (instancia == null) {
                    instancia = new SingleTon();
                    // Só carrega o arquivo DEPOIS de instancia estar atribuída
                    PersistenciaOficina.carregarSeNecessario();
                }
            }
        }
        return instancia;
    }

    public Oficina getOficina() {
        return oficina;
    }
}
