package com.senai.javafx.projeto02.entidades;

import java.util.ArrayList;
import java.util.List;

public class Veiculo {
    private String placa;
    private String modelo;
    private Cliente proprietario;
    private final ArrayList<Servico> servicos = new ArrayList<>();
    private final ArrayList<PecaUtilizada> pecasUtilizadas = new ArrayList<>();

    public Veiculo(String placa, String modelo) {
        this.placa = placa;
        this.modelo = modelo;
    }

    public String getModelo() { return modelo; }
    public String getPlaca() { return placa; }
    public Cliente getProprietario() { return proprietario; }
    public List<Servico> getServicos() { return servicos; }
    public List<PecaUtilizada> getPecasUtilizadas() { return pecasUtilizadas; }

    public void setModelo(String modelo) { this.modelo = modelo; }
    public void setPlaca(String placa) { this.placa = placa; }
    public void setProprietario(Cliente proprietario) { this.proprietario = proprietario; }
}
