package com.senai.javafx.projeto02.entidades;

/**
 * Mecânico da oficina (mão de obra).
 * Opcionalmente vinculado a uma conta de login ({@code loginVinculado})
 * para o painel do funcionário listar as tarefas corretas.
 */
public class Mecanico {
    private String nome;
    private double salario;
    /** Login/e-mail da conta do sistema (Usuario), ou vazio se não vinculado. */
    private String loginVinculado = "";

    public Mecanico(String nome, double salario) {
        this.nome = nome;
        this.salario = salario;
    }

    public Mecanico(String nome, double salario, String loginVinculado) {
        this.nome = nome;
        this.salario = salario;
        this.loginVinculado = loginVinculado != null ? loginVinculado.trim().toLowerCase() : "";
    }

    public String getNome() { return nome; }
    public double getSalario() { return salario; }
    public String getLoginVinculado() { return loginVinculado == null ? "" : loginVinculado; }

    public void setNome(String nome) { this.nome = nome; }
    public void setSalario(double salario) { this.salario = salario; }
    public void setLoginVinculado(String loginVinculado) {
        this.loginVinculado = loginVinculado != null ? loginVinculado.trim().toLowerCase() : "";
    }
}
