package com.senai.javafx.projeto02;

import javafx.application.Platform;
import javafx.animation.ScaleTransition;
import javafx.animation.PauseTransition;
import javafx.util.Duration;
import javafx.concurrent.Worker;
import javafx.embed.swing.SwingFXUtils;
import javafx.geometry.*;
import javafx.scene.Node;
import javafx.scene.image.ImageView;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.*;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.transform.Scale;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.fxml.FXML;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.senai.javafx.projeto02.entidades.*;

import static com.senai.javafx.projeto02.Dialogos.*;
import static com.senai.javafx.projeto02.Tema.*;

/** Painel do administrador (dashboard-admin-view.fxml). */
public class DashboardAdminController extends DashboardBase {

    @FXML private VBox dashboardAdmin;
    @FXML private ImageView fundoMenuAdmin;
    @FXML private Pane sombraFundoMenuAdmin;
    @FXML private VBox menuAdmin;
    @FXML private VBox areaAdmin;

    @FXML private Button botaoMenuAdmin;
    @FXML private Button botaoUsuarioAdmin;
    @FXML private Label rotuloPerfilAdmin;
    @FXML private Label usuarioTexto;

    private WebEngine engineNotaFiscal;
    private WebView webViewNotaFiscal;
    private double zoomAtual = 1.0;
    private Label rotuloZoom;
    private ComboBox<NFServicoRef> seletorServicoNF;
    private ComboBox<NotaFiscalRepositorio.Registro> seletorNotaSalva;
    private String notaFiscalAtualId;
    private NFServicoRef servicoNFAtual;
    private NFServicoRef servicoParaPreencherNF;

    private static final class NFServicoRef {
        final Cliente cliente; final Veiculo veiculo; final Servico servico;
        NFServicoRef(Cliente c, Veiculo v, Servico s) { cliente=c; veiculo=v; servico=s; }
        @Override public String toString() {
            String os=servico.getNumeroOrcamento()==null?"----":String.format("%04d",servico.getNumeroOrcamento());
            return "OS "+os+" • "+cliente.getNome()+" • "+veiculo.getModelo()+" • "+servico.getNome()+" ("+servico.getStatus()+")";
        }
    }

    @Override
    protected VBox menuLateral() {
        return menuAdmin;
    }

    @FXML
    public void initialize() {
        configurarFundoMenu();
    }

    private void configurarFundoMenu() {
        if (fundoMenuAdmin != null && dashboardAdmin != null) {
            if (!fundoMenuAdmin.fitWidthProperty().isBound()) {
                fundoMenuAdmin.fitWidthProperty().bind(dashboardAdmin.widthProperty());
                fundoMenuAdmin.fitHeightProperty().bind(dashboardAdmin.heightProperty());
            }
            fundoMenuAdmin.setMouseTransparent(true);
        }
        if (sombraFundoMenuAdmin != null) {
            boolean temaClaro = Tema.temaEfetivo() == 1;
            sombraFundoMenuAdmin.setStyle(temaClaro
                    ? "-fx-background-color: rgba(248,250,252,0.68);"
                    : "-fx-background-color: rgba(3,7,18,0.48);");
            if (fundoMenuAdmin != null) {
                fundoMenuAdmin.setOpacity(temaClaro ? 0.40 : 0.66);
            }
        }
    }

    @Override
    public void aoEntrar() {
        Usuario usuario = app.getUsuarioAtual();
        usuarioTexto.setText(usuario != null ? usuario.getNome() : "Administrador");
        aoAtualizarAvatar(usuario);
        Tema.estilizarItensMenuLateral(menuAdmin);
        // Uma única tela inicial real — não usa o placeholder estático do FXML.
        if (secaoAtual == null) {
            adminDashboard();
        }
    }

    @Override
    public void aoMudarTema() {
        configurarFundoMenu();
        estilizarLiquidGlass(dashboardAdmin, menuAdmin, botaoMenuAdmin, botaoUsuarioAdmin);
        Tema.estilizarItensMenuLateral(menuAdmin);
        super.aoMudarTema();
        Tema.estilizarItensMenuLateral(menuAdmin);
    }

    @Override
    public void aoAtualizarAvatar(Usuario usuario) {
        PerfilDialogo.atualizarBotaoUsuario(botaoUsuarioAdmin, usuario);
        if (usuarioTexto != null) {
            usuarioTexto.setText(usuario != null ? usuario.getNome() : "Administrador");
        }
    }

    @Override
    protected void configurarMenu(boolean compacto) {
        configurarMenu(menuAdmin, areaAdmin, botaoMenuAdmin, rotuloPerfilAdmin, usuarioTexto, compacto);
    }

    @Override
    protected VBox areaConteudo() {
        return areaAdmin;
    }

    @Override
    protected Map<String, Runnable> rotasDePesquisa() {
        Map<String, Runnable> rotas = new LinkedHashMap<>();
        rotas.put("Dashboard", this::adminDashboard);
        rotas.put("Ordens de serviço", this::adminOrdens);
        rotas.put("Clientes", this::adminAtendimentos);
        rotas.put("Veículos", this::adminVeiculos);
        rotas.put("Serviços (catálogo)", this::adminServicos);
        rotas.put("Estoque", this::adminEstoque);
        rotas.put("Mecânicos", this::adminFuncionarios);
        rotas.put("Financeiro", this::adminFinanceiro);
        rotas.put("Relatórios", this::adminRelatorios);
        return rotas;
    }

    @FXML private void adminDashboard() {
        lembrarSecao(this::mostrarDashboardReal, "Dashboard");
        mostrarDashboardReal();
    }

    private void mostrarDashboardReal() {
        VBox area = areaConteudo();
        if (area == null) return;
        area.getChildren().clear();

        String txt = paletaAtual().texto();
        String sec = paletaAtual().textoSec();

        Label titulo = new Label("Início");
        titulo.setStyle("-fx-text-fill: " + txt + "; -fx-font-size: 26px; -fx-font-weight: bold;");
        Label sub = new Label("Visão geral da oficina — um pouco de cada área");
        sub.setStyle("-fx-text-fill: " + sec + "; -fx-font-size: 13px;");

        int clientes = OficinaService.oficina().getClientes().size();
        int veiculos = OficinaService.listarTodosVeiculos().size();
        int orc = OficinaService.contarServicosPorStatus(Status.ORCAMENTO);
        int ag = OficinaService.contarServicosPorStatus(Status.AGENDADO);
        int and = OficinaService.contarServicosPorStatus(Status.ANDAMENTO);
        int fin = OficinaService.contarServicosPorStatus(Status.FINALIZADO);
        int unidades = OficinaService.totalUnidadesEstoque();
        int itensEstoque = OficinaService.oficina().getEstoque().size();
        int mecanicos = OficinaService.oficina().getMecanicos().size();
        int catalogo = OficinaService.oficina().getCatalogoServicos().size();
        String totalFin = formatarMoeda(OficinaService.totalFinanceiroClientes());
        String valorEstoque = formatarMoeda(OficinaService.valorEstoque());

        // Cards principais (resumo de todas as abas)
        VBox[] listaCards = {
                cardResumoClicavel("Clientes", String.valueOf(clientes), this::adminAtendimentos),
                cardResumoClicavel("Veículos", String.valueOf(veiculos), this::adminVeiculos),
                cardResumoClicavel("Orçamentos", String.valueOf(orc), this::adminOrdens),
                cardResumoClicavel("Agendados", String.valueOf(ag), this::adminOrdens),
                cardResumoClicavel("Em andamento", String.valueOf(and), this::adminOrdens),
                cardResumoClicavel("Finalizados", String.valueOf(fin), this::adminOrdens),
                cardResumoClicavel("Catálogo", String.valueOf(catalogo), this::adminServicos),
                cardResumoClicavel("Estoque (itens)", String.valueOf(itensEstoque), this::adminEstoque),
                cardResumoClicavel("Peças (un.)", String.valueOf(unidades), this::adminEstoque),
                cardResumoClicavel("Mecânicos", String.valueOf(mecanicos), this::adminFuncionarios),
                cardResumoClicavel("Financeiro", totalFin, this::adminFinanceiro),
                cardResumoClicavel("Valor estoque", valorEstoque, this::adminEstoque)
        };
        // Grade com colunas de largura igual: os cards ocupam a linha toda (sem sobra em branco).
        GridPane cards = new GridPane();
        cards.setHgap(14);
        cards.setVgap(14);
        int colunasCards = Tema.layoutCompacto() ? 2 : 4;
        for (int i = 0; i < colunasCards; i++) {
            ColumnConstraints cc = new ColumnConstraints();
            cc.setPercentWidth(100.0 / colunasCards);
            cc.setHgrow(Priority.ALWAYS);
            cards.getColumnConstraints().add(cc);
        }
        for (int i = 0; i < listaCards.length; i++) {
            listaCards[i].setMaxWidth(Double.MAX_VALUE);
            GridPane.setFillWidth(listaCards[i], true);
            cards.add(listaCards[i], i % colunasCards, i / colunasCards);
        }

        // Atalhos rápidos
        HBox acoes = new HBox(10);
        acoes.setAlignment(Pos.CENTER_LEFT);
        Button btnOs = botaoSecao("＋  Nova OS");
        btnOs.setOnAction(e -> CadastroDialogos.criarOrdemServico(this::mostrarDashboardReal));
        Button btnOrdens = botaoSecao("📋  Ordens");
        btnOrdens.setOnAction(e -> adminOrdens());
        Button btnFin = botaoSecao("💰  Financeiro");
        btnFin.setOnAction(e -> adminFinanceiro());
        Button btnRel = botaoSecao("📊  Relatórios");
        btnRel.setOnAction(e -> adminRelatorios());
        acoes.getChildren().addAll(btnOs, btnOrdens, btnFin, btnRel);

        // Painéis laterais: OS recentes + estoque baixo + mecânicos
        List<Map<String, String>> linhasOs = new ArrayList<>();
        int n = 1;
        for (Cliente c : OficinaService.oficina().getClientes()) {
            for (Veiculo v : c.getCarros()) {
                for (Servico s : v.getServicos()) {
                    Map<String, String> row = new LinkedHashMap<>();
                    row.put("OS", s.getNumeroOrcamento() != null
                            ? String.format("%04d", s.getNumeroOrcamento()) : String.format("%04d", n));
                    row.put("Cliente", c.getNome());
                    row.put("Veículo", v.getModelo() + " · " + v.getPlaca());
                    row.put("Serviço", s.getNome());
                    row.put("Valor", formatarMoeda(s.getPreco()));
                    row.put("Status", rotuloStatusDash(s.getStatus()));
                    row.put("_cli", c.getCpf());
                    row.put("_placa", v.getPlaca());
                    row.put("_srv", s.getNome() + "|" + s.getStatus().name());
                    linhasOs.add(row);
                    n++;
                }
            }
        }
        if (linhasOs.size() > 8) linhasOs = new ArrayList<>(linhasOs.subList(0, 8));

        TableView<Map<String, String>> tabelaOs = miniTabela(
                linhasOs,
                new String[]{"OS", "Cliente", "Veículo", "Serviço", "Valor", "Status"},
                "Nenhuma ordem ainda.");
        tabelaOs.setPrefHeight(300);
        List<Map<String, String>> linhasEst = new ArrayList<>();
        for (Estoque e : OficinaService.oficina().getEstoque()) {
            Map<String, String> row = new LinkedHashMap<>();
            row.put("Peça", e.getProduto());
            row.put("Qtd", String.valueOf(e.getQuantidade()));
            row.put("Preço", formatarMoeda(e.getPreco()));
            linhasEst.add(row);
        }
        if (linhasEst.size() > 6) linhasEst = new ArrayList<>(linhasEst.subList(0, 6));
        TableView<Map<String, String>> tabelaEst = miniTabela(
                linhasEst, new String[]{"Peça", "Qtd", "Preço"}, "Estoque vazio.");
        tabelaEst.setPrefHeight(300);

        List<Map<String, String>> linhasMec = new ArrayList<>();
        for (Mecanico m : OficinaService.oficina().getMecanicos()) {
            Map<String, String> row = new LinkedHashMap<>();
            row.put("Nome", m.getNome());
            row.put("Salário", formatarMoeda(m.getSalario()));
            row.put("OS", String.valueOf(OficinaService.contarServicosDoMecanico(m)));
            linhasMec.add(row);
        }
        TableView<Map<String, String>> tabelaMec = miniTabela(
                linhasMec, new String[]{"Nome", "Salário", "OS"}, "Nenhum mecânico.");
        tabelaMec.setPrefHeight(300);

        VBox colOs = painelSecao("Ordens recentes", "Ver todas →", this::adminOrdens, null, tabelaOs);
        VBox colEst = painelSecao("Estoque", "Abrir estoque →", this::adminEstoque, null, tabelaEst);
        VBox colMec = painelSecao("Mecânicos", "Ver equipe →", this::adminFuncionarios, null, tabelaMec);

        HBox colunas = new HBox(14, colOs, colEst, colMec);
        colunas.setAlignment(Pos.TOP_LEFT);
        HBox.setHgrow(colOs, Priority.ALWAYS);
        HBox.setHgrow(colEst, Priority.ALWAYS);
        HBox.setHgrow(colMec, Priority.ALWAYS);
        colOs.setMaxWidth(Double.MAX_VALUE);
        colEst.setMaxWidth(Double.MAX_VALUE);
        colMec.setMaxWidth(Double.MAX_VALUE);

        ScrollPane scroll = new ScrollPane(new VBox(16, titulo, sub, cards, acoes, colunas));
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        VBox.setVgrow(scroll, Priority.ALWAYS);
        area.getChildren().add(scroll);

        if (Tema.layoutCompacto()) {
            menuAberto = false;
            configurarMenu(true);
        }
    }

    private static String rotuloStatusDash(Status st) {
        if (st == null) return "—";
        return switch (st) {
            case ORCAMENTO -> "Orçamento";
            case AGENDADO -> "Agendado";
            case ANDAMENTO -> "Andamento";
            case FINALIZADO -> "Finalizado";
        };
    }

    private VBox cardResumoClicavel(String rotulo, String valor, Runnable acao) {
        VBox card = cardResumo(rotulo, valor);
        card.setCursor(javafx.scene.Cursor.HAND);
        card.setOnMouseClicked(e -> {
            if (acao != null) acao.run();
        });
        return card;
    }

    private VBox painelSecao(String titulo, String linkTxt, Runnable linkAcao, Node extra, Node corpo) {
        Label t = Visual.tituloComIcone(Visual.icone(titulo), titulo, 17);
        Button link = new Button(linkTxt);
        link.setStyle("-fx-background-color: transparent; -fx-text-fill: " + LayoutPadrao.COR_PRIMARIO
                + "; -fx-cursor: hand; -fx-font-size: 12px;");
        link.setOnAction(e -> {
            if (linkAcao != null) linkAcao.run();
        });
        HBox cab = new HBox(8, t, new javafx.scene.layout.Region(), link);
        HBox.setHgrow(cab.getChildren().get(1), Priority.ALWAYS);
        cab.setAlignment(Pos.CENTER_LEFT);
        VBox box = new VBox(10, cab);
        if (extra != null) box.getChildren().add(extra);
        if (corpo != null) {
            VBox.setVgrow(corpo, Priority.ALWAYS);
            box.getChildren().add(corpo);
        }
        box.setStyle(Visual.estiloPainel(18, 16));
        box.setMinWidth(200);
        return box;
    }

    private TableView<Map<String, String>> miniTabela(List<Map<String, String>> linhas, String[] cols, String vazio) {
        TableView<Map<String, String>> tabela = new TableView<>();
        tabela.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        tabela.setPlaceholder(new Label(vazio));
        Visual.estilizarTabela(tabela, 12);
        for (String col : cols) {
            TableColumn<Map<String, String>, String> c = new TableColumn<>(col);
            final String chave = col;
            c.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(
                    d.getValue() != null ? d.getValue().getOrDefault(chave, "") : ""));
            tabela.getColumns().add(c);
        }
        tabela.setItems(javafx.collections.FXCollections.observableArrayList(linhas));
        return tabela;
    }

    private void acaoStatusOs(TableView<Map<String, String>> tabela, boolean iniciar) {
        Map<String, String> sel = tabela.getSelectionModel().getSelectedItem();
        if (sel == null) {
            mostrarMensagem("OS", "Selecione uma ordem na tabela.");
            return;
        }
        String cpf = sel.get("_cli");
        String placa = sel.get("_placa");
        String srvKey = sel.get("_srv");
        Cliente cli = null;
        for (Cliente c : OficinaService.oficina().getClientes()) {
            if (c.getCpf().equals(cpf)) { cli = c; break; }
        }
        if (cli == null) return;
        Veiculo vei = null;
        for (Veiculo v : cli.getCarros()) {
            if (v.getPlaca().equalsIgnoreCase(placa)) { vei = v; break; }
        }
        if (vei == null) return;
        Servico alvo = null;
        for (Servico s : vei.getServicos()) {
            if ((s.getNome() + "|" + s.getStatus().name()).equals(srvKey)) { alvo = s; break; }
        }
        if (alvo == null) return;
        try {
            if (iniciar) OficinaService.iniciarServico(cli, vei, alvo);
            else OficinaService.finalizarServico(cli, vei, alvo);
            // Permanece na seção atual (não troca Dashboard → Ordens).
            recarregarSecaoAtual();
            mostrarMensagem("OS", iniciar ? "Serviço iniciado!" : "Serviço finalizado!");
        } catch (Exception ex) {
            mostrarMensagem("OS", ex.getMessage());
        }
    }


    @FXML private void adminOrdens() {
        lembrarSecao(this::carregarOrdens, "Ordens");
        carregarOrdens();
    }

    private void carregarOrdens() {
        VBox area = areaConteudo();
        if (area == null) return;
        try {
            ModuloOrdensController ctrl = ModulosFxml.carregar(area, "modulo-ordens-view.fxml");
            ctrl.setCallbacks(this::adminServicos, this::carregarOrdens);
            ctrl.setAoNotaFiscal(this::adminNotaFiscal);
            ctrl.setAoNotaFiscalComServico(this::abrirNotaFiscalDoServico);
            ctrl.setAoNotaServicoComServico(this::abrirNotaServicoDoServico);
            ctrl.setAoClientes(this::adminAtendimentos);
            if (Tema.layoutCompacto()) {
                menuAberto = false;
                configurarMenu(true);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            mostrarMensagem("Ordens", "Falha ao abrir módulo FXML: " + ex.getMessage());
        }
    }

    @FXML private void adminServicos() { lembrarSecao(this::carregarServicos, "Catálogo"); carregarServicos(); }

    private void carregarServicos() {
        List<Map<String, String>> linhas = new ArrayList<>();
        int i = 1;
        List<Servico> lista = OficinaService.oficina().getCatalogoServicos();
        for (Servico s : lista) {
            Map<String, String> row = new LinkedHashMap<>();
            row.put("Cód.", String.valueOf(i++));
            row.put("Nome", s.getNome());
            row.put("Preço", formatarMoeda(s.getPreco()));
            row.put("Usos", String.valueOf(s.getQuantidadeUsos()));
            row.put("_idx", String.valueOf(lista.indexOf(s)));
            linhas.add(row);
        }
        abrirSecaoComAcoes(
                "Serviços (catálogo)",
                "Serviços oferecidos pela oficina. Use Novo para cadastrar ou selecione uma linha.",
                new String[]{"Cód.", "Nome", "Preço", "Usos"},
                linhas,
                "Nenhum serviço no catálogo.",
                new String[][]{
                        {"Serviços", String.valueOf(linhas.size())},
                        {"Taxa M.O.", formatarMoeda(Orcamento.TAXA_FIXA_MAO_DE_OBRA)},
                        {"Ordens", String.valueOf(OficinaService.contarServicosPorStatus(Status.AGENDADO)
                                + OficinaService.contarServicosPorStatus(Status.ANDAMENTO)
                                + OficinaService.contarServicosPorStatus(Status.FINALIZADO))}
                },
                () -> CadastroDialogos.cadastrarServico(this::carregarServicos),
                this::carregarServicos,
                row -> {
                    int idx = Integer.parseInt(row.getOrDefault("_idx", "-1"));
                    if (idx < 0 || idx >= lista.size()) return;
                    Servico s = lista.get(idx);
                    if (confirmar("Editar serviço", "Editar \"" + s.getNome() + "\"?", "Cancelar", "Editar")) {
                        CadastroDialogos.editarServico(s, this::carregarServicos);
                    }
                },
                row -> {
                    int idx = Integer.parseInt(row.getOrDefault("_idx", "-1"));
                    if (idx < 0 || idx >= lista.size()) return;
                    Servico s = lista.get(idx);
                    if (confirmar("Remover", "Remover \"" + s.getNome() + "\" do catálogo?", "Não", "Sim")) {
                        OficinaService.removerServicoCatalogo(s);
                        carregarServicos();
                    }
                }
        );
    }

    @FXML private void adminAtendimentos() { lembrarSecao(this::carregarAtendimentos, "Clientes"); carregarAtendimentos(); }

    private void carregarAtendimentos() {
        List<Map<String, String>> linhas = new ArrayList<>();
        List<Cliente> lista = OficinaService.oficina().getClientes();
        int i = 1;
        for (Cliente c : lista) {
            Map<String, String> row = new LinkedHashMap<>();
            row.put("#", String.valueOf(i++));
            row.put("Cliente", c.getNome());
            row.put("CPF", c.getCpf());
            row.put("Telefone", c.getTelefone());
            row.put("Veículos", String.valueOf(c.getCarros().size()));
            row.put("Status", c.getStatus() != null ? c.getStatus().name() : "—");
            row.put("Total", formatarMoeda(c.calcularTotal()));
            row.put("_idx", String.valueOf(lista.indexOf(c)));
            linhas.add(row);
        }
        GerenciadorContadores g = OficinaService.contadores();
        abrirSecaoComAcoes(
                "Clientes",
                "Cadastro de clientes da oficina. Clique duas vezes para editar.",
                new String[]{"#", "Cliente", "CPF", "Telefone", "Veículos", "Status", "Total"},
                linhas,
                "Nenhum cliente cadastrado.",
                new String[][]{
                        {"Agendados", String.valueOf(g.getQuantidade(Status.AGENDADO))},
                        {"Andamento", String.valueOf(g.getQuantidade(Status.ANDAMENTO))},
                        {"Finalizados", String.valueOf(g.getQuantidade(Status.FINALIZADO))}
                },
                () -> CadastroDialogos.cadastrarCliente(this::carregarAtendimentos),
                this::carregarAtendimentos,
                row -> {
                    int idx = Integer.parseInt(row.getOrDefault("_idx", "-1"));
                    if (idx < 0 || idx >= lista.size()) return;
                    Cliente c = lista.get(idx);
                    if (confirmar("Cliente", "Ver detalhes financeiros de " + c.getNome() + "?\n(Não = editar cadastro)", "Editar", "Detalhes")) {
                        CadastroDialogos.detalhesCliente(c);
                    } else {
                        CadastroDialogos.editarCliente(c, this::carregarAtendimentos);
                    }
                },
                row -> {
                    int idx = Integer.parseInt(row.getOrDefault("_idx", "-1"));
                    if (idx < 0 || idx >= lista.size()) return;
                    Cliente c = lista.get(idx);
                    if (confirmar("Excluir cliente", "Excluir " + c.getNome() + " e seus veículos?", "Não", "Excluir")) {
                        OficinaService.removerCliente(c);
                        carregarAtendimentos();
                    }
                }
        );
    }

    @FXML private void adminVeiculos() { lembrarSecao(this::carregarVeiculos, "Veículos"); carregarVeiculos(); }

    private void carregarVeiculos() {
        List<Map<String, String>> linhas = new ArrayList<>();
        List<Veiculo> todos = OficinaService.listarTodosVeiculos();
        int i = 1;
        for (Veiculo v : todos) {
            Map<String, String> row = new LinkedHashMap<>();
            row.put("Cód.", String.valueOf(i++));
            row.put("Placa", v.getPlaca());
            row.put("Modelo", v.getModelo());
            row.put("Cliente", v.getProprietario() != null ? v.getProprietario().getNome() : "—");
            row.put("Serviços", String.valueOf(v.getServicos().size()));
            row.put("Peças", String.valueOf(v.getPecasUtilizadas().size()));
            row.put("_placa", v.getPlaca());
            linhas.add(row);
        }
        abrirSecaoComAcoes(
                "Veículos",
                "Veículos dos clientes. Placa única na oficina.",
                new String[]{"Cód.", "Placa", "Modelo", "Cliente", "Serviços", "Peças"},
                linhas,
                "Nenhum veículo cadastrado.",
                new String[][]{
                        {"Total", String.valueOf(linhas.size())},
                        {"Clientes", String.valueOf(OficinaService.oficina().getClientes().size())},
                        {"Oficina", "Oficina mecânica"}
                },
                () -> CadastroDialogos.cadastrarVeiculo(this::carregarVeiculos),
                this::carregarVeiculos,
                row -> {
                    Veiculo v = acharVeiculo(row.get("_placa"));
                    if (v != null && v.getProprietario() != null)
                        CadastroDialogos.editarVeiculo(v.getProprietario(), v, this::carregarVeiculos);
                },
                row -> {
                    Veiculo v = acharVeiculo(row.get("_placa"));
                    if (v == null || v.getProprietario() == null) return;
                    if (confirmar("Excluir veículo", "Excluir " + v.getPlaca() + "?", "Não", "Excluir")) {
                        OficinaService.removerVeiculo(v.getProprietario(), v);
                        carregarVeiculos();
                    }
                }
        );
    }

    private Veiculo acharVeiculo(String placa) {
        if (placa == null) return null;
        for (Veiculo v : OficinaService.listarTodosVeiculos()) {
            if (placa.equalsIgnoreCase(v.getPlaca())) return v;
        }
        return null;
    }

    @FXML private void adminEstoque() { lembrarSecao(this::carregarEstoque, "Estoque"); carregarEstoque(); }

    private void carregarEstoque() {
        VBox area = areaConteudo();
        if (area == null) return;
        try {
            ModulosFxml.carregar(area, "modulo-estoque-view.fxml");
            if (Tema.layoutCompacto()) {
                menuAberto = false;
                configurarMenu(true);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            mostrarMensagem("Estoque", "Falha ao abrir módulo FXML: " + ex.getMessage());
        }
    }

    @FXML private void adminFuncionarios() { lembrarSecao(this::carregarFuncionarios, "Mecânicos"); carregarFuncionarios(); }

    private void carregarFuncionarios() {
        List<Map<String, String>> linhas = new ArrayList<>();
        List<Mecanico> lista = OficinaService.oficina().getMecanicos();
        int i = 1;
        for (Mecanico m : lista) {
            Map<String, String> row = new LinkedHashMap<>();
            row.put("Cód.", String.valueOf(i++));
            row.put("Nome", m.getNome());
            row.put("Login vinculado", m.getLoginVinculado().isBlank() ? "—" : m.getLoginVinculado());
            row.put("Salário", formatarMoeda(m.getSalario()));
            row.put("Serviços", String.valueOf(OficinaService.contarServicosDoMecanico(m)));
            row.put("_idx", String.valueOf(lista.indexOf(m)));
            linhas.add(row);
        }
        abrirSecaoComAcoes(
                "Mecânicos e funcionários",
                "Mecânicos da oficina (não confundir com contas de login).",
                new String[]{"Cód.", "Nome", "Login vinculado", "Salário", "Serviços"},
                linhas,
                "Nenhum mecânico cadastrado.",
                new String[][]{
                        {"Equipe", String.valueOf(linhas.size())},
                        {"Ativos", String.valueOf(linhas.size())},
                        {"Oficina", "Oficina mecânica"}
                },
                () -> CadastroDialogos.cadastrarMecanico(this::carregarFuncionarios),
                this::carregarFuncionarios,
                row -> {
                    int idx = Integer.parseInt(row.getOrDefault("_idx", "-1"));
                    if (idx >= 0 && idx < lista.size())
                        CadastroDialogos.editarMecanico(lista.get(idx), this::carregarFuncionarios);
                },
                row -> {
                    int idx = Integer.parseInt(row.getOrDefault("_idx", "-1"));
                    if (idx < 0 || idx >= lista.size()) return;
                    Mecanico m = lista.get(idx);
                    if (confirmar("Remover", "Remover " + m.getNome() + "?", "Não", "Remover")) {
                        OficinaService.removerMecanico(m);
                        carregarFuncionarios();
                    }
                }
        );
    }

    @FXML private void adminFinanceiro() { lembrarSecao(this::carregarFinanceiro, "Financeiro"); carregarFinanceiro(); }

    /** Painel financeiro com gráficos calculados a partir dos dados cadastrados na oficina. */
    private void carregarFinanceiro() {
        VBox area = areaConteudo();
        if (area == null) return;
        area.getChildren().clear();
        area.setSpacing(14);

        Label titulo = new Label("Financeiro");
        titulo.setStyle("-fx-text-fill: " + paletaAtual().texto() + "; -fx-font-size: 26px; -fx-font-weight: bold;");
        Label subtitulo = new Label("Gastos, mão de obra, estoque (após abertura), salários, ganhos com clientes e lucro da oficina.");
        subtitulo.setStyle("-fx-text-fill: " + paletaAtual().textoSec() + "; -fx-font-size: 13px;");

        List<Cliente> clientes = new ArrayList<>(OficinaService.oficina().getClientes());
        double totalGanho = OficinaService.totalFinanceiroClientes();
        double totalSalarios = OficinaService.totalSalariosMecanicos();
        double estoqueApos = OficinaService.valorEstoqueAposAbertura();
        double gastosTotais = OficinaService.totalGastosEstoqueESalarios();
        double pecasUsadas = OficinaService.totalPecasUtilizadas();
        double despesas = OficinaService.totalDespesasLucro();
        double lucro = OficinaService.calcularLucro();
        double maoDeObra = Orcamento.TAXA_FIXA_MAO_DE_OBRA;
        int totalOS = 0;
        for (Cliente c : clientes) for (Veiculo v : c.getCarros()) totalOS += v.getServicos().size();

        // Linha 1: indicadores principais solicitados
        HBox cards = new HBox(12);
        cards.setFillHeight(true);
        cards.getChildren().addAll(
                cardResumo("Gastos totais", formatarMoeda(gastosTotais)),
                cardResumo("Mão de obra (oficina)", formatarMoeda(maoDeObra)),
                cardResumo("Estoque (após abertura)", formatarMoeda(estoqueApos)),
                cardResumo("Salários mecânicos", formatarMoeda(totalSalarios))
        );
        for (Node n : cards.getChildren()) HBox.setHgrow(n, Priority.ALWAYS);

        HBox cards2 = new HBox(12);
        cards2.setFillHeight(true);
        cards2.getChildren().addAll(
                cardResumo("Ganho (clientes)", formatarMoeda(totalGanho)),
                cardResumo("Peças usadas (serviços)", formatarMoeda(pecasUsadas)),
                cardResumo("Despesas (peças+salários)", formatarMoeda(despesas)),
                cardResumo("Lucro", formatarMoeda(lucro))
        );
        for (Node n : cards2.getChildren()) HBox.setHgrow(n, Priority.ALWAYS);

        CategoryAxis eixoX = new CategoryAxis();
        eixoX.setLabel("Cliente");
        NumberAxis eixoY = new NumberAxis();
        eixoY.setLabel("Valor (R$)");
        BarChart<String, Number> graficoClientes = new BarChart<>(eixoX, eixoY);
        graficoClientes.setTitle("📊  Total de pedidos por cliente");
        graficoClientes.setLegendVisible(false);
        graficoClientes.setAnimated(true);
        graficoClientes.setCategoryGap(18);
        graficoClientes.setBarGap(4);
        javafx.scene.chart.XYChart.Series<String, Number> serie = new javafx.scene.chart.XYChart.Series<>();
        clientes.stream().sorted((a,b) -> Double.compare(b.calcularTotal(), a.calcularTotal())).limit(8).forEach(c -> {
            String nome = c.getNome() == null ? "Cliente" : c.getNome();
            if (nome.length() > 16) nome = nome.substring(0, 15) + "…";
            serie.getData().add(new javafx.scene.chart.XYChart.Data<>(nome, Math.max(0, c.calcularTotal())));
        });
        graficoClientes.getData().add(serie);
        graficoClientes.setMinHeight(300);
        graficoClientes.setPrefHeight(330);
        graficoClientes.setStyle("-fx-background-color: transparent; -fx-text-fill: " + paletaAtual().texto() + "; -fx-padding: 10 8 8 8; -fx-font-size: 12px;");
        graficoClientes.setAlternativeColumnFillVisible(false);
        graficoClientes.setHorizontalGridLinesVisible(true);
        graficoClientes.setVerticalGridLinesVisible(false);
        graficoClientes.setLegendVisible(false);

        Map<String, Integer> status = new LinkedHashMap<>();
        status.put("Orçamento", OficinaService.contarServicosPorStatus(Status.ORCAMENTO));
        status.put("Agendado", OficinaService.contarServicosPorStatus(Status.AGENDADO));
        status.put("Em andamento", OficinaService.contarServicosPorStatus(Status.ANDAMENTO));
        status.put("Finalizado", OficinaService.contarServicosPorStatus(Status.FINALIZADO));
        PieChart graficoStatus = new PieChart();
        graficoStatus.setTitle("📋  Distribuição das ordens por status");
        graficoStatus.setLegendVisible(true);
        graficoStatus.setLabelsVisible(true);
        graficoStatus.setAnimated(true);
        status.forEach((nome, quantidade) -> { if (quantidade > 0) graficoStatus.getData().add(new PieChart.Data(nome + " (" + quantidade + ")", quantidade)); });
        if (graficoStatus.getData().isEmpty()) graficoStatus.setTitle("Ainda não há ordens para distribuir");
        graficoStatus.setMinHeight(300);
        graficoStatus.setPrefHeight(330);
        graficoStatus.setStyle("-fx-background-color: transparent; -fx-text-fill: " + paletaAtual().texto() + "; -fx-padding: 10 8 8 8; -fx-font-size: 12px;");
        graficoStatus.setStartAngle(90);

        // Eixos, marcas, títulos e rótulos precisam acompanhar a paleta ativa.
        String corTextoGrafico = Tema.modoTema() == 1 ? "#202633" : "#f5f7ff";
        String corGradeGrafico = Tema.modoTema() == 1 ? "#d4d8e1" : "#454b5a";
        String estiloTextoGrafico = "-fx-text-fill: " + corTextoGrafico + "; -fx-fill: " + corTextoGrafico + ";";
        eixoX.setStyle(estiloTextoGrafico);
        eixoY.setStyle(estiloTextoGrafico);
        eixoX.setTickLabelFill(javafx.scene.paint.Color.web(corTextoGrafico));
        eixoY.setTickLabelFill(javafx.scene.paint.Color.web(corTextoGrafico));
        eixoX.lookupAll(".axis-label").forEach(n -> n.setStyle(estiloTextoGrafico));
        eixoY.lookupAll(".axis-label").forEach(n -> n.setStyle(estiloTextoGrafico));
        graficoClientes.lookupAll(".chart-title").forEach(n -> n.setStyle(estiloTextoGrafico));
        graficoStatus.lookupAll(".chart-title, .chart-legend, .chart-pie-label").forEach(n -> n.setStyle(estiloTextoGrafico));
        graficoClientes.setStyle(graficoClientes.getStyle() + " -fx-tick-label-fill: " + corTextoGrafico + ";");
        graficoStatus.setStyle(graficoStatus.getStyle() + " -fx-tick-label-fill: " + corTextoGrafico + ";");

        // Cartões usam a paleta ativa, então acompanham os temas claro, escuro e Liquid Glass.
        Tema.Paleta paletaGraf = paletaAtual();
        String fundoCartaoGraf = Visual.fundoPainel();
        String bordaCartaoGraf = Visual.bordaCard();
        String sombraGraf = Tema.modoTema() == 1
                ? "dropshadow(gaussian, rgba(15,23,42,0.10), 18, 0.12, 0, 5)"
                : "dropshadow(gaussian, rgba(0,0,0,0.28), 18, 0.12, 0, 5)";
        String estiloCartaoGraf = "-fx-background-color: " + fundoCartaoGraf
                + "; -fx-background-radius: 18; -fx-border-color: " + bordaCartaoGraf
                + "; -fx-border-radius: 18; -fx-effect: " + sombraGraf + ";";
        VBox cartaoClientes = new VBox(8, graficoClientes);
        cartaoClientes.setPadding(new Insets(14));
        cartaoClientes.setStyle(estiloCartaoGraf);
        VBox cartaoStatus = new VBox(8, graficoStatus);
        cartaoStatus.setPadding(new Insets(14));
        cartaoStatus.setStyle(estiloCartaoGraf);

        // Tooltips e microanimações nos elementos individuais, não apenas no gráfico inteiro.
        Platform.runLater(() -> {
            graficoClientes.lookupAll(".axis-label, .tick-mark, .tick-label, .chart-title").forEach(n ->
                    n.setStyle("-fx-text-fill: " + (Tema.modoTema() == 1 ? "#202633" : "#f5f7ff") + "; -fx-fill: " + (Tema.modoTema() == 1 ? "#202633" : "#f5f7ff") + ";"));
            graficoStatus.lookupAll(".chart-title, .chart-legend, .chart-legend-item, .chart-pie-label").forEach(n ->
                    n.setStyle("-fx-text-fill: " + (Tema.modoTema() == 1 ? "#202633" : "#f5f7ff") + "; -fx-fill: " + (Tema.modoTema() == 1 ? "#202633" : "#f5f7ff") + ";"));
            for (javafx.scene.chart.XYChart.Data<String, Number> ponto : serie.getData()) {
                Node no = ponto.getNode();
                if (no == null) continue;
                Tooltip.install(no, new Tooltip(ponto.getXValue() + " • " + formatarMoeda(ponto.getYValue().doubleValue())));
                no.setOnMouseEntered(ev -> {
                    ScaleTransition st = new ScaleTransition(Duration.millis(140), no);
                    st.setToX(1.08); st.setToY(1.04); st.playFromStart();
                    no.setStyle("-fx-bar-fill: " + paletaAtual().botaoFundo() + ";");
                });
                no.setOnMouseExited(ev -> {
                    ScaleTransition st = new ScaleTransition(Duration.millis(140), no);
                    st.setToX(1.0); st.setToY(1.0); st.playFromStart();
                    no.setStyle("");
                });
            }
            for (PieChart.Data fatia : graficoStatus.getData()) {
                Node no = fatia.getNode();
                if (no == null) continue;
                Tooltip.install(no, new Tooltip(fatia.getName() + " • " + (int) fatia.getPieValue() + " ordem(ns)"));
                no.setOnMouseEntered(ev -> {
                    ScaleTransition st = new ScaleTransition(Duration.millis(160), no);
                    st.setToX(1.07); st.setToY(1.07); st.playFromStart();
                    no.setOpacity(0.88);
                });
                no.setOnMouseExited(ev -> {
                    ScaleTransition st = new ScaleTransition(Duration.millis(160), no);
                    st.setToX(1.0); st.setToY(1.0); st.playFromStart();
                    no.setOpacity(1.0);
                });
            }
        });
        HBox graficos = new HBox(16, cartaoClientes, cartaoStatus);
        HBox.setHgrow(cartaoClientes, Priority.ALWAYS);
        HBox.setHgrow(cartaoStatus, Priority.ALWAYS);
        graficoClientes.setPrefWidth(700);
        graficoStatus.setPrefWidth(430);
        graficos.setAlignment(Pos.CENTER);
        graficos.setFillHeight(true);

        Label aviso = new Label("Gastos totais = salários + valor do estoque cadastrado após a abertura. "
                + "Lucro = ganho dos clientes − (peças usadas em serviços + salários). "
                + "Mão de obra cobrada pela oficina: R$ 150,00 por ordem com itens.");
        aviso.setWrapText(true);
        aviso.setStyle("-fx-text-fill: " + paletaAtual().textoSec() + "; -fx-font-size: 11px;");

        TableView<Map<String, String>> tabela = new TableView<>();
        tabela.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        tabela.setPlaceholder(new Label("Nenhum cliente cadastrado."));
        for (String col : new String[]{"Cliente", "Status", "Veículos", "Total pedido"}) {
            TableColumn<Map<String, String>, String> coluna = new TableColumn<>(col);
            coluna.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(d.getValue().getOrDefault(col, "")));
            tabela.getColumns().add(coluna);
        }
        List<Map<String, String>> linhas = new ArrayList<>();
        for (Cliente c : clientes) {
            Map<String, String> row = new LinkedHashMap<>();
            row.put("Cliente", c.getNome());
            row.put("Status", c.getStatus() != null ? c.getStatus().name() : "—");
            row.put("Veículos", String.valueOf(c.getCarros().size()));
            row.put("Total pedido", formatarMoeda(c.calcularTotal()));
            linhas.add(row);
        }
        tabela.setItems(javafx.collections.FXCollections.observableArrayList(linhas));
        tabela.setPrefHeight(240);
        Visual.estilizarTabela(tabela, 16);
        Label secao = Visual.tituloComIcone("💰", "Contas e pedidos por cliente", 17);
        HBox acoes = new HBox(10);
        Button atualizar = botaoSecao("↻ Atualizar gráficos");
        atualizar.setOnAction(e -> carregarFinanceiro());
        Button relatorios = botaoSecao("Relatórios detalhados");
        relatorios.setOnAction(e -> adminRelatorios());
        acoes.getChildren().addAll(atualizar, relatorios);

        area.getChildren().addAll(titulo, subtitulo, cards, cards2, graficos, aviso, secao, tabela, acoes);
        if (Tema.layoutCompacto()) { menuAberto = false; configurarMenu(true); }
    }

    
    @FXML private void adminContas() {
        lembrarSecao(this::carregarContas, "Contas");
        carregarContas();
    }

    private void carregarContas() {
        VBox area = areaConteudo();
        if (area == null) return;
        try {
            ModulosFxml.carregar(area, "modulo-contas-view.fxml");
            if (Tema.layoutCompacto()) { menuAberto = false; configurarMenu(true); }
        } catch (Exception ex) {
            ex.printStackTrace();
            mostrarMensagem("Contas", "Falha: " + ex.getMessage());
        }
    }

    @FXML private void adminSuporte() {
        lembrarSecao(this::carregarSuporte, "Suporte");
        carregarSuporte();
    }

    private void carregarSuporte() {
        VBox area = areaConteudo();
        if (area == null) return;
        try {
            ModulosFxml.carregar(area, "modulo-suporte-view.fxml");
            if (Tema.layoutCompacto()) { menuAberto = false; configurarMenu(true); }
        } catch (Exception ex) {
            ex.printStackTrace();
            mostrarMensagem("Suporte", "Falha: " + ex.getMessage());
        }
    }

    @FXML private void adminRelatorios() {
        lembrarSecao(this::carregarRelatorios, "Relatórios");
        carregarRelatorios();
    }

    private void carregarRelatorios() {
        List<Map<String, String>> linhas = new ArrayList<>();
        linhas.add(Map.of("Indicador", "Clientes", "Valor", String.valueOf(OficinaService.oficina().getClientes().size())));
        linhas.add(Map.of("Indicador", "Veículos", "Valor", String.valueOf(OficinaService.listarTodosVeiculos().size())));
        linhas.add(Map.of("Indicador", "Itens estoque", "Valor", String.valueOf(OficinaService.oficina().getEstoque().size())));
        linhas.add(Map.of("Indicador", "Unidades estoque", "Valor", String.valueOf(OficinaService.totalUnidadesEstoque())));
        linhas.add(Map.of("Indicador", "Serviços catálogo", "Valor", String.valueOf(OficinaService.oficina().getCatalogoServicos().size())));
        linhas.add(Map.of("Indicador", "Mecânicos", "Valor", String.valueOf(OficinaService.oficina().getMecanicos().size())));
        linhas.add(Map.of("Indicador", "OS Agendadas", "Valor", String.valueOf(OficinaService.contarServicosPorStatus(Status.AGENDADO))));
        linhas.add(Map.of("Indicador", "OS Em andamento", "Valor", String.valueOf(OficinaService.contarServicosPorStatus(Status.ANDAMENTO))));
        linhas.add(Map.of("Indicador", "OS Finalizadas", "Valor", String.valueOf(OficinaService.contarServicosPorStatus(Status.FINALIZADO))));
        linhas.add(Map.of("Indicador", "Total financeiro", "Valor", formatarMoeda(OficinaService.totalFinanceiroClientes())));
        linhas.add(Map.of("Indicador", "Valor estoque", "Valor", formatarMoeda(OficinaService.valorEstoque())));
        abrirSecao(
                "Relatórios",
                "Resumo consolidado da oficina (dados reais).",
                new String[]{"Indicador", "Valor"},
                linhas,
                "Sem dados.",
                new String[][]{
                        {"Clientes", String.valueOf(OficinaService.oficina().getClientes().size())},
                        {"Andamento", String.valueOf(OficinaService.contarServicosPorStatus(Status.ANDAMENTO))},
                        {"Total R$", formatarMoeda(OficinaService.totalFinanceiroClientes())}
                },
                null,
                this::carregarRelatorios
        );
    }

    /** Ordens de serviço — via Nota Fiscal menu was separate; map adminNotaFiscal already exists. Use serviços area for OS list via adminFinanceiro pattern — add method called from nota or services. */

    private static String formatarMoeda(double v) {
        return OficinaService.formatarMoeda(v);
    }

    private void abrirNotaFiscalDoServico(Cliente cliente, Veiculo veiculo, Servico servico) {
        if (cliente == null || veiculo == null || servico == null) {
            mostrarMensagem("Nota Fiscal", "Selecione uma ordem de serviço válida.");
            return;
        }
        servicoParaPreencherNF = new NFServicoRef(cliente, veiculo, servico);
        adminNotaFiscal();
    }

    /** Abre a nota de serviço na mesma interface embutida da nota fiscal (área principal). */
    private void abrirNotaServicoDoServico(Cliente cliente, Veiculo veiculo, Servico servico) {
        if (cliente == null || veiculo == null || servico == null) {
            mostrarMensagem("Nota de Serviço", "Selecione uma ordem de serviço válida.");
            return;
        }
        lembrarSecao(() -> montarNotaServicoEmbutida(cliente, veiculo, servico), "Nota de Serviço");
        montarNotaServicoEmbutida(cliente, veiculo, servico);
    }

    private void montarNotaServicoEmbutida(Cliente cliente, Veiculo veiculo, Servico servico) {
        try {
            areaAdmin.getChildren().clear();
            zoomAtual = 1.0;

            Label titulo = new Label("Nota de serviço");
            titulo.setStyle("-fx-text-fill: " + paletaAtual().texto() + "; -fx-font-size: 24px; -fx-font-weight: bold;");

            WebView web = new WebView();
            web.setPrefHeight(720);
            web.setMinHeight(400);
            web.setMaxWidth(Double.MAX_VALUE);
            web.setPageFill(Color.TRANSPARENT);
            web.setStyle("-fx-background-color: transparent;");
            web.setContextMenuEnabled(false);
            WebEngine engine = web.getEngine();
            webViewNotaFiscal = web;
            engineNotaFiscal = engine;

            Button btnSalvarPdf = new Button("💾  Salvar PDF...");
            estilizarBotaoAcao(btnSalvarPdf);
            Button btnZoomMenos = new Button("−");
            estilizarBotaoAcao(btnZoomMenos);
            btnZoomMenos.setMinWidth(36);
            rotuloZoom = new Label("100%");
            rotuloZoom.setStyle("-fx-text-fill: #cccccc; -fx-font-size: 13px; -fx-min-width: 48px; -fx-alignment: center;");
            Button btnZoomMais = new Button("+");
            estilizarBotaoAcao(btnZoomMais);
            btnZoomMais.setMinWidth(36);
            Button btnZoomReset = new Button("100%");
            estilizarBotaoAcao(btnZoomReset);

            Runnable preencher = () -> {
                try {
                    String json = montarJsonNotaServico(cliente, veiculo, servico);
                    engine.executeScript("preencherNota(" + json + ")");
                } catch (Exception ex) {
                    mostrarMensagem("Nota de Serviço", "Erro ao preencher: " + ex.getMessage());
                }
            };

            btnSalvarPdf.setOnAction(e -> salvarNotaFiscalPdf());
            btnZoomMenos.setOnAction(e -> alterarZoom(-0.1));
            btnZoomMais.setOnAction(e -> alterarZoom(0.1));
            btnZoomReset.setOnAction(e -> { zoomAtual = 1.0; aplicarZoom(); });

            HBox barra = new HBox(10, btnSalvarPdf,
                    new Separator(Orientation.VERTICAL),
                    btnZoomMenos, rotuloZoom, btnZoomMais, btnZoomReset);
            barra.setAlignment(Pos.CENTER_LEFT);

            StackPane areaNota = new StackPane(web);
            areaNota.setStyle("-fx-background-color: transparent;");
            areaNota.layoutBoundsProperty().addListener((o, a, b) ->
                    areaNota.setClip(new javafx.scene.shape.Rectangle(b.getWidth(), b.getHeight())));
            ScrollPane scrollNota = new ScrollPane(areaNota);
            scrollNota.setFitToWidth(true);
            scrollNota.setFitToHeight(true);
            scrollNota.setStyle("-fx-background-color: transparent; -fx-background: transparent;");
            VBox.setVgrow(scrollNota, Priority.ALWAYS);

            areaAdmin.getChildren().addAll(titulo, barra, scrollNota);
            carregarTemplateNotaServico(engine, preencher);
            if (Tema.layoutCompacto()) {
                menuAberto = false;
                configurarMenu(true);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            mostrarMensagem("Nota de Serviço", "Não foi possível abrir: " + ex.getMessage());
        }
    }

    private void carregarTemplateNotaServico(WebEngine engine, Runnable aoSucesso) {
        try {
            InputStream is = getClass().getResourceAsStream("/com/senai/javafx/projeto02/nota_servico.html");
            if (is == null) {
                engine.loadContent("<html><body><h3>Template nota_servico.html não encontrado.</h3></body></html>");
                return;
            }
            String html = new String(is.readAllBytes(), StandardCharsets.UTF_8);
            is.close();
            // Embute a logo em base64 para aparecer no WebView
            try (InputStream logoStream = getClass().getResourceAsStream("/com/senai/javafx/projeto02/logo-oficina.png")) {
                if (logoStream != null) {
                    String b64 = java.util.Base64.getEncoder().encodeToString(logoStream.readAllBytes());
                    String dataUri = "data:image/png;base64," + b64;
                    html = html.replace("src=\"logo-oficina.png\"", "src=\"" + dataUri + "\"")
                            .replace("src='logo-oficina.png'", "src='" + dataUri + "'");
                }
            }
            javafx.beans.value.ChangeListener<Worker.State> listener = new javafx.beans.value.ChangeListener<>() {
                @Override
                public void changed(javafx.beans.value.ObservableValue<? extends Worker.State> obs, Worker.State o, Worker.State n) {
                    if (n != Worker.State.SUCCEEDED) return;
                    engine.getLoadWorker().stateProperty().removeListener(this);
                    if (aoSucesso != null) Platform.runLater(aoSucesso);
                }
            };
            engine.getLoadWorker().stateProperty().addListener(listener);
            engine.loadContent(html, "text/html");
        } catch (Exception e) {
            engine.loadContent("<html><body><h3>Erro: " + e.getMessage() + "</h3></body></html>");
        }
    }

    private static String montarJsonNotaServico(Cliente c, Veiculo v, Servico s) {
        String statusTxt = switch (s.getStatus()) {
            case ORCAMENTO -> "Orçamento";
            case AGENDADO -> "Aberto";
            case ANDAMENTO -> "Em andamento";
            case FINALIZADO -> "Concluído";
        };
        String num = s.getNumeroOrcamento() != null ? String.format("%04d", s.getNumeroOrcamento()) : "0000";
        String mec = s.getMecanicos().isEmpty() ? "" : s.getMecanicos().get(0).getNome();
        StringBuilder servicosJson = new StringBuilder("[");
        servicosJson.append(String.format(Locale.US, "{\"descricao\":%s,\"qtd\":1,\"valor\":%.2f}",
                jsonStr(s.getNome()), s.getPreco())).append("]");
        StringBuilder pecasJson = new StringBuilder("[");
        boolean first = true;
        for (PecaUtilizada p : v.getPecasUtilizadas()) {
            if (!first) pecasJson.append(',');
            first = false;
            pecasJson.append(String.format(Locale.US,
                    "{\"codigo\":%s,\"descricao\":%s,\"qtd\":%.2f,\"valor\":%.2f}",
                    jsonStr(""), jsonStr(p.getNome() != null ? p.getNome() : ""),
                    p.getQuantidade(), p.getPrecoUnitario()));
        }
        pecasJson.append("]");
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return "{"
                + "\"numero\":" + jsonStr(num) + ","
                + "\"status\":" + jsonStr(statusTxt) + ","
                + "\"dataEntrada\":" + jsonStr(s.getDataHoraInicio() == null ? "" : s.getDataHoraInicio().format(fmt)) + ","
                + "\"dataSaida\":" + jsonStr(s.getDataHoraConclusao() == null ? "" : s.getDataHoraConclusao().format(fmt)) + ","
                + "\"mecanico\":" + jsonStr(mec) + ","
                + "\"cliente\":{\"nome\":" + jsonStr(c.getNome()) + ",\"doc\":" + jsonStr(c.getCpf())
                + ",\"tel\":" + jsonStr(c.getTelefone()) + ",\"email\":" + jsonStr("") + ",\"endereco\":" + jsonStr("") + "},"
                + "\"veiculo\":{\"placa\":" + jsonStr(v.getPlaca()) + ",\"marca\":" + jsonStr("")
                + ",\"modelo\":" + jsonStr(v.getModelo()) + ",\"ano\":" + jsonStr("") + ",\"cor\":" + jsonStr("")
                + ",\"km\":" + jsonStr("") + ",\"combustivel\":" + jsonStr("") + ",\"chassi\":" + jsonStr("") + "},"
                + "\"defeito\":" + jsonStr(s.getDefeito() == null ? "" : s.getDefeito()) + ","
                + "\"diagnostico\":" + jsonStr(s.getDiagnostico() == null ? "" : s.getDiagnostico()) + ","
                + "\"pagamento\":" + jsonStr("") + ","
                + "\"observacoes\":" + jsonStr(s.getObservacoes() == null ? "" : s.getObservacoes()) + ","
                + "\"desconto\":0,\"servicos\":" + servicosJson + ",\"pecas\":" + pecasJson
                + "}";
    }

    @FXML private void adminNotaFiscal() {
        lembrarSecao(this::montarNotaFiscal, "Nota Fiscal");
        montarNotaFiscal();
    }

    private void montarNotaFiscal() {
        try {
            areaAdmin.getChildren().clear();
            zoomAtual = 1.0;

            Label titulo = new Label("Nota fiscal");
            titulo.setStyle("-fx-text-fill: " + paletaAtual().texto() + "; -fx-font-size: 24px; -fx-font-weight: bold;");

            HBox barra = new HBox(10);
            barra.setAlignment(Pos.CENTER_LEFT);

            Button btnSalvar = new Button("💾  Salvar PDF...");
            estilizarBotaoAcao(btnSalvar);

            seletorServicoNF = new ComboBox<>();
            seletorServicoNF.setPromptText("Selecione um serviço...");
            seletorServicoNF.setPrefWidth(280);
            preencherSeletorServicosNF();
            seletorNotaSalva = new ComboBox<>();
            seletorNotaSalva.setPromptText("Notas salvas...");
            seletorNotaSalva.setPrefWidth(220);
            atualizarSeletorNotasSalvas();

            Button btnZoomMenos = new Button("−");
            estilizarBotaoAcao(btnZoomMenos);
            btnZoomMenos.setMinWidth(36);

            rotuloZoom = new Label("100%");
            rotuloZoom.setStyle("-fx-text-fill: #cccccc; -fx-font-size: 13px; -fx-min-width: 48px; -fx-alignment: center;");

            Button btnZoomMais = new Button("+");
            estilizarBotaoAcao(btnZoomMais);
            btnZoomMais.setMinWidth(36);

            Button btnZoomReset = new Button("100%");
            estilizarBotaoAcao(btnZoomReset);

            barra.getChildren().addAll(
                    btnSalvar,
                    new Separator(Orientation.VERTICAL),
                    btnZoomMenos, rotuloZoom, btnZoomMais, btnZoomReset
            );

            // WebView com fundo transparente (só a nota fica branca)
            webViewNotaFiscal = new WebView();
            webViewNotaFiscal.setPrefHeight(720);
            webViewNotaFiscal.setMinHeight(400);
            webViewNotaFiscal.setMaxWidth(Double.MAX_VALUE);
            webViewNotaFiscal.setPageFill(Color.TRANSPARENT);
            webViewNotaFiscal.setStyle("-fx-background-color: transparent;");
            webViewNotaFiscal.setContextMenuEnabled(false);

            webViewNotaFiscal.getEngine().documentProperty().addListener((obs, oldDoc, newDoc) -> {
                if (newDoc != null) {
                    try {
                        webViewNotaFiscal.setPageFill(Color.TRANSPARENT);
                        restringirOverflowDanfe(webViewNotaFiscal.getEngine());
                    } catch (Exception ignored) {
                    }
                }
            });

            engineNotaFiscal = webViewNotaFiscal.getEngine();
            carregarTemplateDanfe(engineNotaFiscal);

            btnSalvar.setOnAction(e -> salvarNotaFiscalPdf());
            btnZoomMenos.setOnAction(e -> alterarZoom(-0.1));
            btnZoomMais.setOnAction(e -> alterarZoom(0.1));
            btnZoomReset.setOnAction(e -> {
                zoomAtual = 1.0;
                aplicarZoom();
            });

            // Área da nota: ScrollPane limita o que sai para fora do quadro
            StackPane areaNota = new StackPane(webViewNotaFiscal);
            areaNota.setStyle("-fx-background-color: transparent;");
            areaNota.setMaxWidth(Double.MAX_VALUE);
            // Clip dinâmico: corta qualquer desenho fora dos limites da área
            areaNota.layoutBoundsProperty().addListener((o, a, b) -> {
                areaNota.setClip(new javafx.scene.shape.Rectangle(b.getWidth(), b.getHeight()));
            });

            ScrollPane scrollNota = new ScrollPane(areaNota);
            scrollNota.setFitToWidth(true);
            scrollNota.setFitToHeight(true);
            scrollNota.setPannable(false);
            scrollNota.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
            scrollNota.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
            scrollNota.setStyle("-fx-background-color: transparent; -fx-background: transparent;");
            scrollNota.setMaxWidth(Double.MAX_VALUE);
            VBox.setVgrow(scrollNota, Priority.ALWAYS);

            areaAdmin.getChildren().addAll(titulo, barra, scrollNota);

            if (Tema.layoutCompacto()) {
                menuAberto = false;
                configurarMenu(true);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            mostrarMensagem("Nota Fiscal", "Não foi possível abrir a pré-visualização:\n" + ex.getMessage());
        }
    }


    private void preencherSeletorServicosNF() {
        if (seletorServicoNF == null) return;
        List<NFServicoRef> refs = new ArrayList<>();
        for (Cliente c : OficinaService.oficina().getClientes())
            for (Veiculo v : c.getCarros())
                for (Servico srv : v.getServicos()) refs.add(new NFServicoRef(c, v, srv));
        seletorServicoNF.getItems().setAll(refs);
    }

    private void atualizarSeletorNotasSalvas() {
        if (seletorNotaSalva != null) seletorNotaSalva.getItems().setAll(NotaFiscalRepositorio.listar());
    }

    private void preencherNotaPeloServicoSelecionado() {
        NFServicoRef ref = seletorServicoNF == null ? null : seletorServicoNF.getValue();
        if (ref == null || engineNotaFiscal == null) {
            mostrarMensagem("Nota Fiscal", "Selecione um serviço na lista antes de preencher a nota.");
            return;
        }
        preencherNotaComServico(ref);
    }

    private void preencherNotaComServico(NFServicoRef ref) {
        if (ref == null || engineNotaFiscal == null || engineNotaFiscal.getDocument() == null
                || engineNotaFiscal.getLoadWorker().getState() != Worker.State.SUCCEEDED) {
            mostrarMensagem("Nota Fiscal", "A nota ainda está carregando. Aguarde um instante e tente novamente.");
            return;
        }
        servicoNFAtual = ref;
        notaFiscalAtualId = null;

        String hoje = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        LocalDateTime saida = ref.servico.getDataHoraConclusao();
        String dataSaida = saida == null ? "Não finalizado / não registrado"
                : saida.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        String horaSaida = saida == null ? "—"
                : saida.format(DateTimeFormatter.ofPattern("HH:mm"));
        String numeroOs = ref.servico.getNumeroOrcamento() == null
                ? "----" : String.format("%04d", ref.servico.getNumeroOrcamento());

        double totalPecas = 0.0;
        StringBuilder itensJson = new StringBuilder("[");
        // Serviço principal
        itensJson.append("{")
                .append("\"codigo\":").append(jsonStr("S001")).append(',')
                .append("\"descricao\":").append(jsonStr(ref.servico.getNome())).append(',')
                .append("\"ncm\":").append(jsonStr("—")).append(',')
                .append("\"cfop\":").append(jsonStr("5933")).append(',')
                .append("\"un\":").append(jsonStr("SV")).append(',')
                .append("\"qtd\":1,")
                .append("\"vUnit\":").append(jsonStr(formatarValorNota(ref.servico.getPreco()))).append(',')
                .append("\"vTotal\":").append(jsonStr(formatarValorNota(ref.servico.getPreco()))).append(',')
                .append("\"icms\":").append(jsonStr("0")).append(',')
                .append("\"ipi\":").append(jsonStr("0"))
                .append("}");

        int indicePeca = 1;
        for (PecaUtilizada peca : ref.veiculo.getPecasUtilizadas()) {
            if (peca == null) continue;
            double subtotal = peca.getSubtotal();
            totalPecas += subtotal;
            itensJson.append(",{")
                    .append("\"codigo\":").append(jsonStr(String.format(Locale.ROOT, "P%03d", indicePeca++))).append(',')
                    .append("\"descricao\":").append(jsonStr(peca.getNome())).append(',')
                    .append("\"ncm\":").append(jsonStr("—")).append(',')
                    .append("\"cfop\":").append(jsonStr("5102")).append(',')
                    .append("\"un\":").append(jsonStr("UN")).append(',')
                    .append("\"qtd\":").append(peca.getQuantidade()).append(',')
                    .append("\"vUnit\":").append(jsonStr(formatarValorNota(peca.getPrecoUnitario()))).append(',')
                    .append("\"vTotal\":").append(jsonStr(formatarValorNota(subtotal))).append(',')
                    .append("\"icms\":").append(jsonStr("0")).append(',')
                    .append("\"ipi\":").append(jsonStr("0"))
                    .append("}");
        }
        itensJson.append("]");

        double total = ref.servico.getPreco() + totalPecas;
        String natureza = totalPecas > 0.009
                ? "Prestação de serviços e fornecimento de peças"
                : "Prestação de serviços";
        String observacao = "Documento interno da oficina. Não substitui NF-e/NFS-e autorizada pela autoridade fiscal."
                + " Serviço: " + nullSafe(ref.servico.getNome()) + ". Situação: " + rotuloStatusNota(ref.servico.getStatus()) + ".";

        String json = "{"
                + "\"nfNumero\":" + jsonStr("DOCUMENTO INTERNO") + ","
                + "\"chaveAcesso\":" + jsonStr("Não informado — sem autorização fiscal") + ","
                + "\"protocolo\":" + jsonStr("Documento interno; não transmitido à SEFAZ/prefeitura") + ","
                + "\"cnpjEmitente\":" + jsonStr("Não informado") + ","
                + "\"emitenteNome\":" + jsonStr("Oficina mecânica — dados cadastrais não informados") + ","
                + "\"emitenteEndereco\":" + jsonStr("Preencha os dados cadastrais da oficina.") + ","
                + "\"tipoOperacao\":" + jsonStr("1 - SAÍDA") + ","
                + "\"natureza\":" + jsonStr(natureza) + ","
                + "\"clienteNome\":" + jsonStr(ref.cliente.getNome()) + ","
                + "\"clienteDoc\":" + jsonStr(ref.cliente.getCpf()) + ","
                + "\"clienteFone\":" + jsonStr(ref.cliente.getTelefone()) + ","
                + "\"clienteEndereco\":" + jsonStr("Não informado") + ","
                + "\"clienteBairro\":" + jsonStr("") + ","
                + "\"clienteCep\":" + jsonStr("") + ","
                + "\"clienteMunicipio\":" + jsonStr("") + ","
                + "\"clienteUf\":" + jsonStr("") + ","
                + "\"clienteIe\":" + jsonStr("Não informado") + ","
                + "\"dataEmissao\":" + jsonStr(hoje) + ","
                + "\"dataSaida\":" + jsonStr(dataSaida) + ","
                + "\"horaSaida\":" + jsonStr(horaSaida) + ","
                + "\"veiculoPlaca\":" + jsonStr(ref.veiculo.getPlaca()) + ","
                + "\"veiculoModelo\":" + jsonStr(ref.veiculo.getModelo()) + ","
                + "\"veiculoAno\":" + jsonStr("Não informado") + ","
                + "\"veiculoKm\":" + jsonStr("Não informado") + ","
                + "\"osNumero\":" + jsonStr(numeroOs) + ","
                + "\"transpNome\":" + jsonStr("") + ","
                + "\"freteConta\":" + jsonStr("9 - Sem frete") + ","
                + "\"bcIcms\":" + jsonStr("0,00") + ","
                + "\"vIcms\":" + jsonStr("0,00") + ","
                + "\"bcIcmsSt\":" + jsonStr("0,00") + ","
                + "\"vIcmsSt\":" + jsonStr("0,00") + ","
                + "\"vFrete\":" + jsonStr("0,00") + ","
                + "\"vSeguro\":" + jsonStr("0,00") + ","
                + "\"vDesconto\":" + jsonStr("0,00") + ","
                + "\"vOutras\":" + jsonStr("0,00") + ","
                + "\"vIpi\":" + jsonStr("0,00") + ","
                + "\"imEmitente\":" + jsonStr("Não informado") + ","
                + "\"bcIss\":" + jsonStr("0,00") + ","
                + "\"vIss\":" + jsonStr("0,00") + ","
                + "\"vProdutos\":" + jsonStr(formatarValorNota(totalPecas)) + ","
                + "\"vServicos\":" + jsonStr(formatarValorNota(ref.servico.getPreco())) + ","
                + "\"vTotal\":" + jsonStr(formatarValorNota(total)) + ","
                + "\"infComplementares\":" + jsonStr(observacao) + ","
                + "\"itens\":" + itensJson
                + "}";

        try {
            // Garante que a função exista (template carregado) e preenche os dados
            Object fn = engineNotaFiscal.executeScript("typeof preencherDanfe");
            if (fn == null || !"function".equals(String.valueOf(fn))) {
                // Fallback: injeta a função se o script do template não rodou
                engineNotaFiscal.executeScript(scriptFallbackPreencherDanfe());
            }
            engineNotaFiscal.executeScript("preencherDanfe(" + json + ")");
            mostrarMensagem("Nota Fiscal", "Dados da ordem carregados, incluindo serviço, peças e totais. Revise os campos e salve o documento. Ele é interno e ainda não está autorizado como NF-e/NFS-e.");
        } catch (Exception ex) {
            mostrarMensagem("Nota Fiscal", "Não foi possível preencher a nota: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private static String nullSafe(String s) {
        return s == null ? "" : s;
    }

    /** Escapa string para uso em JSON (aspas duplas). */
    private static String jsonStr(String value) {
        if (value == null) value = "";
        return "\"" + value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", " ")
                .replace("\n", " ")
                .replace("\u2028", " ")
                .replace("\u2029", " ") + "\"";
    }

    /** Fallback caso o template HTML não tenha exposto preencherDanfe. */
    private static String scriptFallbackPreencherDanfe() {
        return """
            window.preencherDanfe = function (dados) {
                if (!dados) return;
                function set(id, v) {
                    var e = document.getElementById(id);
                    if (e) e.textContent = (v == null || v === undefined) ? '' : String(v);
                }
                set('nf-numero', dados.nfNumero || 'DOCUMENTO INTERNO');
                set('chave-acesso', dados.chaveAcesso || '');
                set('protocolo', dados.protocolo || '');
                set('cnpj-emitente', dados.cnpjEmitente || '');
                set('emitente-nome', dados.emitenteNome || '');
                set('emitente-endereco', dados.emitenteEndereco || '');
                set('tipo-operacao', dados.tipoOperacao || '1 - SAÍDA');
                set('natureza', dados.natureza || '');
                set('cliente-nome', dados.clienteNome || '');
                set('cliente-doc', dados.clienteDoc || '');
                set('cliente-fone', dados.clienteFone || '');
                set('cliente-endereco', dados.clienteEndereco || '');
                set('cliente-bairro', dados.clienteBairro || '');
                set('cliente-cep', dados.clienteCep || '');
                set('cliente-municipio', dados.clienteMunicipio || '');
                set('cliente-uf', dados.clienteUf || '');
                set('cliente-ie', dados.clienteIe || '');
                set('data-emissao', dados.dataEmissao || '');
                set('data-saida', dados.dataSaida || '');
                set('hora-saida', dados.horaSaida || '');
                set('veiculo-placa', dados.veiculoPlaca || '');
                set('placa', dados.veiculoPlaca || '');
                set('veiculo-modelo', dados.veiculoModelo || '');
                set('veiculo-ano', dados.veiculoAno || '');
                set('veiculo-km', dados.veiculoKm || '');
                set('os-numero', dados.osNumero || '');
                set('transp-nome', dados.transpNome || '');
                set('frete-conta', dados.freteConta || '9 - Sem frete');
                set('bc-icms', dados.bcIcms || '0,00');
                set('v-icms', dados.vIcms || '0,00');
                set('bc-icms-st', dados.bcIcmsSt || '0,00');
                set('v-icms-st', dados.vIcmsSt || '0,00');
                set('v-frete', dados.vFrete || '0,00');
                set('v-seguro', dados.vSeguro || '0,00');
                set('v-desconto', dados.vDesconto || '0,00');
                set('v-outras', dados.vOutras || '0,00');
                set('v-ipi', dados.vIpi || '0,00');
                set('im-emitente', dados.imEmitente || '');
                set('bc-iss', dados.bcIss || '0,00');
                set('v-iss', dados.vIss || '0,00');
                set('v-produtos', dados.vProdutos || '0,00');
                set('v-servicos', dados.vServicos || '0,00');
                set('v-total', dados.vTotal || '0,00');
                set('inf-complementares', dados.infComplementares || '');
                var body = document.getElementById('itens-body');
                if (body) {
                    body.innerHTML = '';
                    (dados.itens || []).forEach(function (item) {
                        var tr = document.createElement('tr');
                        [item.codigo, item.descricao, item.ncm, item.cfop, item.un, item.qtd, item.vUnit, item.vTotal, item.icms, item.ipi]
                            .forEach(function (val) {
                                var td = document.createElement('td');
                                td.textContent = val == null ? '' : String(val);
                                td.setAttribute('contenteditable', 'true');
                                tr.appendChild(td);
                            });
                        body.appendChild(tr);
                    });
                }
            };
            """;
    }

    private static String formatarValorNota(double valor) {
        return String.format(Locale.ROOT, "%.2f", valor).replace('.', ',');
    }

    private static String rotuloStatusNota(Status status) {
        if (status == null) return "não informado";
        return switch (status) {
            case ORCAMENTO -> "orçamento";
            case AGENDADO -> "agendado";
            case ANDAMENTO -> "em andamento";
            case FINALIZADO -> "finalizado";
        };
    }

    private String jsLiteral(String value) {
        if (value == null) value = "";
        return "'" + value.replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\r", " ")
                .replace("\n", " ")
                .replace("\u2028", " ")
                .replace("\u2029", " ") + "'";
    }

    private void salvarRegistroNotaFiscal() {
        if (engineNotaFiscal == null || engineNotaFiscal.getDocument() == null
                || engineNotaFiscal.getLoadWorker().getState() != Worker.State.SUCCEEDED) {
            mostrarMensagem("Nota Fiscal", "Aguarde o carregamento da nota antes de salvar.");
            return;
        }
        try {
            Object htmlObj = engineNotaFiscal.executeScript("document.documentElement.outerHTML");
            if (htmlObj == null) throw new IllegalStateException("O conteúdo da nota está vazio.");
            String html = htmlObj.toString();
            String cliente="Documento editado", documento="", veiculo="", os="", servico="";
            if (servicoNFAtual != null) {
                cliente=servicoNFAtual.cliente.getNome(); documento=servicoNFAtual.cliente.getCpf();
                veiculo=servicoNFAtual.veiculo.getModelo()+" / "+servicoNFAtual.veiculo.getPlaca();
                os=servicoNFAtual.servico.getNumeroOrcamento()==null?"----":String.format("%04d",servicoNFAtual.servico.getNumeroOrcamento());
                servico=servicoNFAtual.servico.getNome();
            } else if (seletorNotaSalva != null && seletorNotaSalva.getValue()!=null) {
                NotaFiscalRepositorio.Registro r=seletorNotaSalva.getValue(); cliente=r.cliente; documento=r.documento; veiculo=r.veiculo; os=r.os; servico=r.servico;
            }
            notaFiscalAtualId=NotaFiscalRepositorio.salvar(notaFiscalAtualId, html, cliente, documento, veiculo, os, servico);
            atualizarSeletorNotasSalvas();
            mostrarMensagem("Nota salva", "A cópia editável foi salva no computador e ficará disponível na lista 'Notas salvas' mesmo após fechar o sistema.\n\nObservação: isso salva o documento interno; não transmite nem autoriza uma NF-e/NFS-e junto à SEFAZ ou prefeitura.");
        } catch (Exception ex) { mostrarMensagem("Erro ao salvar nota", "Não foi possível salvar a nota: " + ex.getMessage()); }
    }

    private void abrirNotaSalvaSelecionada() {
        NotaFiscalRepositorio.Registro r=seletorNotaSalva==null?null:seletorNotaSalva.getValue();
        if(r==null || engineNotaFiscal==null) { mostrarMensagem("Notas salvas", "Selecione uma nota salva."); return; }
        try {
            notaFiscalAtualId=r.id; servicoNFAtual=null;
            String htmlSalvo = NotaFiscalRepositorio.lerHtml(r.id);
            engineNotaFiscal.getLoadWorker().stateProperty().addListener(new javafx.beans.value.ChangeListener<Worker.State>() {
                @Override public void changed(javafx.beans.value.ObservableValue<? extends Worker.State> o, Worker.State old, Worker.State state) {
                    if(state==Worker.State.SUCCEEDED) {
                        engineNotaFiscal.getLoadWorker().stateProperty().removeListener(this);
                        restringirOverflowDanfe(engineNotaFiscal);
                    }
                }
            });
            engineNotaFiscal.loadContent(htmlSalvo, "text/html");
        } catch(Exception ex) { mostrarMensagem("Notas salvas", "Não foi possível abrir a nota: " + ex.getMessage()); }
    }

    /** Impede que texto editável da DANFE ultrapasse a largura do documento. */
    private void restringirOverflowDanfe(WebEngine engine) {
        if (engine == null) return;
        try {
            engine.executeScript("""
                (function() {
                    try {
                        document.documentElement.style.overflowX = 'hidden';
                        document.body.style.overflowX = 'hidden';
                        document.body.style.maxWidth = '100%';
                        var c = document.querySelector('.danfe-container');
                        if (c) {
                            c.style.overflow = 'hidden';
                            c.style.maxWidth = '850px';
                            c.style.width = '850px';
                            c.style.boxSizing = 'border-box';
                        }
                        document.querySelectorAll('[contenteditable="true"]').forEach(function(el) {
                            el.style.maxWidth = '100%';
                            el.style.overflow = 'hidden';
                            el.style.wordBreak = 'break-word';
                            el.style.overflowWrap = 'anywhere';
                            el.style.whiteSpace = 'normal';
                            el.addEventListener('input', function() {
                                if (el.scrollWidth > el.clientWidth + 2) {
                                    el.style.wordBreak = 'break-all';
                                }
                            });
                        });
                    } catch (e) {}
                })();
                """);
        } catch (Exception ignored) {
        }
    }

    private void alterarZoom(double delta) {
        zoomAtual = Math.max(0.5, Math.min(2.0, zoomAtual + delta));
        // arredonda para 10%
        zoomAtual = Math.round(zoomAtual * 10) / 10.0;
        aplicarZoom();
    }

    private void aplicarZoom() {
        if (webViewNotaFiscal != null) {
            webViewNotaFiscal.setZoom(zoomAtual);
        }
        if (rotuloZoom != null) {
            rotuloZoom.setText(Math.round(zoomAtual * 100) + "%");
        }
    }

    /**
     * Captura a nota completa (sem corte) e salva em PDF.
     */
    private void salvarNotaFiscalPdf() {
        if (webViewNotaFiscal == null || engineNotaFiscal == null || engineNotaFiscal.getDocument() == null
                || engineNotaFiscal.getLoadWorker().getState() != Worker.State.SUCCEEDED) {
            mostrarMensagem("Salvar", "Aguarde o carregamento completo da nota antes de exportar o PDF.");
            return;
        }

        FileChooser seletor = new FileChooser();
        seletor.setTitle("Salvar documento em PDF");
        seletor.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF", "*.pdf"));
        String dataHora = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        seletor.setInitialFileName("Documento_Oficina_" + dataHora + ".pdf");

        File pastaDocs = new File(System.getProperty("user.home"), "Documents");
        if (!pastaDocs.isDirectory()) pastaDocs = new File(System.getProperty("user.home"));
        seletor.setInitialDirectory(pastaDocs);

        Stage stage = areaAdmin != null && areaAdmin.getScene() != null
                ? (Stage) areaAdmin.getScene().getWindow() : null;
        File arquivo = seletor.showSaveDialog(stage);
        if (arquivo == null) return;
        if (!arquivo.getName().toLowerCase(Locale.ROOT).endsWith(".pdf")) {
            arquivo = new File(arquivo.getAbsolutePath() + ".pdf");
        }

        final File destino = arquivo;
        final double zoomAntes = webViewNotaFiscal.getZoom();
        final double alturaPrefAntes = webViewNotaFiscal.getPrefHeight();
        final double alturaMinAntes = webViewNotaFiscal.getMinHeight();
        final double alturaMaxAntes = webViewNotaFiscal.getMaxHeight();
        final double larguraPrefAntes = webViewNotaFiscal.getPrefWidth();

        // Guarda clip/fit dos pais para restaurar
        final java.util.List<Node> pais = new ArrayList<>();
        final java.util.List<javafx.scene.shape.Shape> clipsAntes = new ArrayList<>();
        final java.util.List<ScrollPane> scrolls = new ArrayList<>();
        final java.util.List<Boolean> fitHAntes = new ArrayList<>();
        final java.util.List<Double> scrollVAntes = new ArrayList<>();

        try {
            // Remove restrições que cortam o WebView (clip + ScrollPane)
            Node n = webViewNotaFiscal;
            while (n != null) {
                pais.add(n);
                clipsAntes.add(n.getClip() instanceof javafx.scene.shape.Shape sh ? sh : null);
                n.setClip(null);
                if (n instanceof ScrollPane sp) {
                    scrolls.add(sp);
                    fitHAntes.add(sp.isFitToHeight());
                    scrollVAntes.add(sp.getVvalue());
                    sp.setFitToHeight(false);
                    sp.setVvalue(0);
                }
                n = n.getParent();
            }

            // Altura real do documento (folha da nota)
            try {
                engineNotaFiscal.executeScript(
                        "document.documentElement.style.height='auto';"
                                + "document.body.style.height='auto';"
                                + "document.documentElement.style.overflow='visible';"
                                + "document.body.style.overflow='visible';");
            } catch (Exception ignored) {
            }

            Object hObj = engineNotaFiscal.executeScript("""
                    (function() {
                      var el = document.querySelector('.danfe-container')
                            || document.querySelector('.pagina')
                            || document.body;
                      var r = el.getBoundingClientRect();
                      var h = Math.max(
                        el.scrollHeight || 0,
                        el.offsetHeight || 0,
                        r.height || 0,
                        document.body.scrollHeight || 0,
                        document.documentElement.scrollHeight || 0
                      );
                      return Math.ceil(h + 40);
                    })()
                    """);
            final double conteudoH = Math.max(1000, Math.min(20000,
                    hObj instanceof Number num ? num.doubleValue() : 1400));
            final double largura = 920;

            webViewNotaFiscal.setZoom(1.0);
            webViewNotaFiscal.setMinHeight(conteudoH);
            webViewNotaFiscal.setPrefHeight(conteudoH);
            webViewNotaFiscal.setMaxHeight(conteudoH);
            webViewNotaFiscal.setPrefWidth(largura);
            webViewNotaFiscal.setMinWidth(largura);
            webViewNotaFiscal.resize(largura, conteudoH);
            webViewNotaFiscal.applyCss();
            webViewNotaFiscal.layout();
            if (webViewNotaFiscal.getParent() != null) {
                webViewNotaFiscal.getParent().applyCss();
                webViewNotaFiscal.getParent().requestLayout();
            }

            PauseTransition aguardarRender = new PauseTransition(Duration.millis(700));
            aguardarRender.setOnFinished(event -> {
                try {
                    Object h2 = engineNotaFiscal.executeScript(
                            "Math.max(document.body.scrollHeight, document.documentElement.scrollHeight)");
                    final double hFinal = Math.max(conteudoH, Math.min(20000,
                            h2 instanceof Number nn ? nn.doubleValue() + 40 : conteudoH));
                    webViewNotaFiscal.setMinHeight(hFinal);
                    webViewNotaFiscal.setPrefHeight(hFinal);
                    webViewNotaFiscal.setMaxHeight(hFinal);
                    webViewNotaFiscal.resize(largura, hFinal);
                    webViewNotaFiscal.applyCss();
                    webViewNotaFiscal.layout();

                    SnapshotParameters params = new SnapshotParameters();
                    params.setFill(Color.WHITE);
                    final double escala = hFinal > 3500 ? 1.5 : 2.0;
                    params.setTransform(new Scale(escala, escala));
                    WritableImage imagem = webViewNotaFiscal.snapshot(params, null);
                    if (imagem == null || imagem.getWidth() < 2 || imagem.getHeight() < 2) {
                        throw new IllegalStateException("A captura da nota ficou vazia.");
                    }
                    BufferedImage buffered = SwingFXUtils.fromFXImage(imagem, null);
                    try (FileOutputStream fos = new FileOutputStream(destino)) {
                        NotaFiscalPdf.escrever(buffered, fos);
                    }
                    mostrarMensagem("PDF salvo", "Documento exportado para:\n\n" + destino.getAbsolutePath());
                } catch (Exception ex) {
                    ex.printStackTrace();
                    mostrarMensagem("Erro ao salvar", "Não foi possível gerar o PDF:\n" + ex.getMessage());
                } finally {
                    restaurarAposPdf(zoomAntes, alturaPrefAntes, alturaMinAntes, alturaMaxAntes,
                            larguraPrefAntes, pais, clipsAntes, scrolls, fitHAntes, scrollVAntes);
                }
            });
            aguardarRender.play();
        } catch (Exception ex) {
            restaurarAposPdf(zoomAntes, alturaPrefAntes, alturaMinAntes, alturaMaxAntes,
                    larguraPrefAntes, pais, clipsAntes, scrolls, fitHAntes, scrollVAntes);
            ex.printStackTrace();
            mostrarMensagem("Erro ao salvar", "Não foi possível preparar o PDF:\n" + ex.getMessage());
        }
    }

    private void restaurarAposPdf(double zoomAntes, double alturaPrefAntes, double alturaMinAntes,
                                  double alturaMaxAntes, double larguraPrefAntes,
                                  List<Node> pais, List<javafx.scene.shape.Shape> clipsAntes,
                                  List<ScrollPane> scrolls, List<Boolean> fitHAntes, List<Double> scrollVAntes) {
        try {
            for (int i = 0; i < pais.size(); i++) {
                if (clipsAntes.get(i) != null) {
                    pais.get(i).setClip(clipsAntes.get(i));
                }
            }
            for (int i = 0; i < scrolls.size(); i++) {
                scrolls.get(i).setFitToHeight(fitHAntes.get(i));
                scrolls.get(i).setVvalue(scrollVAntes.get(i));
            }
            if (webViewNotaFiscal != null) {
                webViewNotaFiscal.setMinHeight(alturaMinAntes);
                webViewNotaFiscal.setPrefHeight(alturaPrefAntes);
                webViewNotaFiscal.setMaxHeight(alturaMaxAntes);
                webViewNotaFiscal.setPrefWidth(larguraPrefAntes);
                webViewNotaFiscal.setZoom(zoomAntes);
                aplicarZoom();
                webViewNotaFiscal.requestLayout();
            }
        } catch (Exception ignored) {
        }
    }

    /**
     * Remove faixas transparentes ao redor da nota (mantém só o retângulo branco).
     */
    private static BufferedImage recortarConteudoOpaco(BufferedImage src) {
        if (src == null) return null;
        int w = src.getWidth();
        int h = src.getHeight();
        int minX = w, minY = h, maxX = 0, maxY = 0;
        boolean achou = false;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int argb = src.getRGB(x, y);
                int alpha = (argb >>> 24) & 0xFF;
                // pixel visível (não transparente e não quase preto de fundo)
                if (alpha > 20) {
                    int r = (argb >> 16) & 0xFF;
                    int g = (argb >> 8) & 0xFF;
                    int b = argb & 0xFF;
                    // ignora pixels muito escuros do tema
                    if (r + g + b > 40) {
                        achou = true;
                        if (x < minX) minX = x;
                        if (y < minY) minY = y;
                        if (x > maxX) maxX = x;
                        if (y > maxY) maxY = y;
                    }
                }
            }
        }
        if (!achou || maxX <= minX || maxY <= minY) {
            return src;
        }
        // margem pequena
        minX = Math.max(0, minX - 4);
        minY = Math.max(0, minY - 4);
        maxX = Math.min(w - 1, maxX + 4);
        maxY = Math.min(h - 1, maxY + 4);
        return src.getSubimage(minX, minY, maxX - minX + 1, maxY - minY + 1);
    }

    /** Aplica uma cor explícita ao botão sem depender do tema global. */
    private void pintar(Button b, String fundo, String texto) {
        if (b == null) return;
        b.setPrefHeight(40);
        b.setStyle(
                "-fx-background-color: " + fundo + ";" +
                "-fx-text-fill: " + texto + ";" +
                "-fx-background-radius: 22;" +
                "-fx-border-radius: 22;" +
                "-fx-border-width: 0;" +
                "-fx-cursor: hand;" +
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-padding: 0 18;"
        );
    }

    private void estilizarBotaoAcao(Button b) {
        b.setStyle(
                "-fx-background-color: rgba(255,255,255,0.10);" +
                "-fx-background-radius: 12;" +
                "-fx-text-fill: " + paletaAtual().texto() + ";" +
                "-fx-font-size: 13px;" +
                "-fx-cursor: hand;" +
                "-fx-padding: 8 14;"
        );
        Tema.aplicarEstiloSemantico(b);
    }

    private void carregarTemplateDanfe(WebEngine engine) {
        try {
            InputStream is = getClass().getResourceAsStream("/com/senai/javafx/projeto02/danfe-template.html");
            if (is == null) {
                engine.loadContent("<html><body style='background:transparent'><h3>Template DANFE não encontrado.</h3></body></html>");
                return;
            }
            String html = new String(is.readAllBytes(), StandardCharsets.UTF_8);
            is.close();
            javafx.beans.value.ChangeListener<Worker.State> listener = new javafx.beans.value.ChangeListener<>() {
                @Override
                public void changed(javafx.beans.value.ObservableValue<? extends Worker.State> obs, Worker.State oldState, Worker.State newState) {
                    if (newState != Worker.State.SUCCEEDED) return;
                    engine.getLoadWorker().stateProperty().removeListener(this);
                    restringirOverflowDanfe(engine);
                    limparDanfeParaNovoDocumento(engine);
                    if (engine == engineNotaFiscal && servicoParaPreencherNF != null) {
                        NFServicoRef escolhido = servicoParaPreencherNF;
                        servicoParaPreencherNF = null;
                        // runLater garante que o DOM + script do template já estão prontos
                        Platform.runLater(() -> {
                            if (seletorServicoNF != null) {
                                for (NFServicoRef item : seletorServicoNF.getItems()) {
                                    if (item.servico == escolhido.servico) {
                                        seletorServicoNF.setValue(item);
                                        break;
                                    }
                                }
                            }
                            // Pequeno atraso extra se o worker ainda não estiver SUCCEEDED
                            if (engineNotaFiscal.getLoadWorker().getState() == Worker.State.SUCCEEDED
                                    && engineNotaFiscal.getDocument() != null) {
                                preencherNotaComServico(escolhido);
                            } else {
                                servicoParaPreencherNF = escolhido;
                                mostrarMensagem("Nota Fiscal", "Aguarde o carregamento e use \"Preencher pelo serviço\" se os dados não aparecerem.");
                            }
                        });
                    }
                }
            };
            engine.getLoadWorker().stateProperty().addListener(listener);
            engine.loadContent(html, "text/html");
        } catch (Exception e) {
            engine.loadContent("<html><body style='background:transparent'><h3>Erro: " + e.getMessage() + "</h3></body></html>");
        }
    }

    /** Limpa os dados fictícios de demonstração ao abrir um documento novo. */
    private void limparDanfeParaNovoDocumento(WebEngine engine) {
        if (engine == null || engine.getDocument() == null) return;
        try {
            engine.executeScript("""
                (function(){
                    function set(id, value){ var e=document.getElementById(id); if(e)e.textContent=value; }
                    ['nf-numero','chave-acesso','protocolo','cnpj-emitente'].forEach(function(id){
                        set(id, id==='nf-numero'?'DOCUMENTO INTERNO':
                            id==='chave-acesso'?'Não aplicável — sem autorização fiscal':
                            id==='protocolo'?'Não transmitido / não autorizado':'Não informado');
                    });
                    set('emitente-nome','Oficina mecânica — dados cadastrais não informados');
                    set('emitente-endereco','Preencha os dados cadastrais da oficina.');
                    ['cliente-nome','cliente-doc','cliente-endereco','cliente-bairro','cliente-cep',
                     'cliente-municipio','cliente-uf','cliente-fone','data-emissao','data-saida',
                     'hora-saida','veiculo-placa','veiculo-modelo','veiculo-ano','veiculo-km','os-numero',
                     'transp-nome','im-emitente'].forEach(function(id){set(id,'—');});
                    set('cliente-ie','Não informado'); set('natureza','Documento interno — aguardando dados');
                    ['bc-icms','v-icms','bc-icms-st','v-icms-st','v-produtos','v-frete','v-seguro',
                     'v-desconto','v-outras','v-ipi','v-total','v-servicos','bc-iss','v-iss'].forEach(function(id){set(id,'0,00');});
                    set('inf-complementares','Documento interno da oficina. Não transmitido nem autorizado como NF-e/NFS-e.');
                    set('placa','—'); set('frete-conta','9 - Sem frete'); set('tipo-operacao','1 - SAÍDA');
                    var body=document.getElementById('itens-body');
                    if(body) body.innerHTML='<tr><td colspan="10" class="vazio">Selecione um serviço para carregar os itens.</td></tr>';
                })();
                """);
        } catch (Exception ex) {
            Tema.debugErro("Não foi possível limpar o modelo da nota", ex);
        }
    }

    private void preencherDadosExemplo(WebEngine engine) {
        if (engine == null) return;
        if (engine.getDocument() == null || engine.getLoadWorker().getState() != Worker.State.SUCCEEDED) {
            mostrarMensagem("Nota Fiscal", "A nota ainda está carregando. Aguarde um instante e tente novamente.");
            return;
        }
        servicoNFAtual = null;
        notaFiscalAtualId = null;
        String script = """
            (function() {
                function set(id, txt) {
                    var el = document.getElementById(id);
                    if (el) el.textContent = txt;
                }
                set('nf-numero', 'EXEMPLO — NÃO VÁLIDO');
                set('chave-acesso', 'DADOS DE EXEMPLO — SEM CHAVE FISCAL');
                set('protocolo', 'EXEMPLO — NÃO TRANSMITIDO / NÃO AUTORIZADO');
                set('cnpj-emitente', 'CNPJ DE EXEMPLO — NÃO VÁLIDO');
                set('cliente-nome', 'João da Silva Santos');
                set('cliente-doc', '123.456.789-00');
                set('data-emissao', '19/10/2026');
                set('cliente-endereco', 'Av. Brasil, 1500 - Sala 3');
                set('cliente-bairro', 'Jardim América');
                set('cliente-cep', '01310-100');
                set('data-saida', '19/10/2026');
                set('cliente-municipio', 'São Paulo');
                set('cliente-uf', 'SP');
                set('cliente-fone', '(11) 98888-7777');
                set('cliente-ie', 'ISENTO');
                set('hora-saida', '15:10');
                set('veiculo-placa', 'ABC-1D23');
                set('veiculo-modelo', 'Volkswagen Gol 1.6');
                set('veiculo-ano', '2020 / Branco');
                set('veiculo-km', '62.180');
                set('os-numero', '00087');
                set('v-produtos', '350,00');
                set('v-servicos', '150,00');
                set('v-total', '500,00');
                set('natureza', 'DADOS DE EXEMPLO — NÃO É DOCUMENTO FISCAL');
                set('emitente-nome', 'OFICINA (DADOS DE EXEMPLO)');
                set('inf-complementares', 'Dados fictícios para demonstração. Documento interno, não transmitido nem autorizado como NF-e/NFS-e.');
            })();
            """;
        engine.executeScript(script);
    }

    private void restaurarAreaOriginal() {
        engineNotaFiscal = null;
        webViewNotaFiscal = null;
        // Volta ao dashboard real — nunca restaura o placeholder morto do FXML.
        adminDashboard();
    }
}
