module com.senai.javafx.projeto02 {

    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires javafx.base;
    requires javafx.web;
    requires javafx.swing;

    requires java.prefs;
    requires java.desktop;
    requires java.sql;
    requires java.net.http;

    requires org.xerial.sqlitejdbc;
    requires org.slf4j;

    // FXML e reflection precisam abrir os pacotes
    opens com.senai.javafx.projeto02 to javafx.fxml, javafx.graphics, javafx.base;
    opens com.senai.javafx.projeto02.entidades to javafx.fxml, javafx.base, javafx.graphics;

    exports com.senai.javafx.projeto02;
    exports com.senai.javafx.projeto02.entidades;
}
