# Mecha Consertos — Oficina Mecânica (JavaFX)

## Executar

```bash
./mvnw clean javafx:run
```

Admin: `admin@mecha.com` / `admin123`

## v23 — FXML por módulo

Cada seção do dashboard carrega um FXML próprio:

| Módulo | FXML |
|--------|------|
| Clientes, veículos, catálogo, mecânicos, financeiro, relatórios | `modulo-secao-view.fxml` |
| Ordens de serviço | `modulo-ordens-view.fxml` |
| Estoque (9 operações) | `modulo-estoque-view.fxml` |

Controllers: `ModuloSecaoController`, `ModuloOrdensController`, `ModuloEstoqueController`  
Loader: `ModulosFxml`

Shell do app continua em `dashboard-admin-view.fxml` / `dashboard-funcionario-view.fxml`.

## Atualização v35 — Financeiro com gráficos e catálogo ampliado
- O painel Financeiro agora apresenta indicadores reais, gráfico de barras de total de pedidos por cliente e gráfico de pizza de ordens por status.
- Os gráficos são recalculados ao clicar em “Atualizar gráficos”. Não são simuladas despesas/lucros: esses indicadores só devem ser exibidos quando houver lançamentos específicos no sistema.
- O catálogo local de veículos foi ampliado com modelos Ferrari, Lamborghini, McLaren, Aston Martin, Maserati, Bugatti, Rolls-Royce, Bentley, Lotus, Pagani, Koenigsegg, BYD, GWM e outras marcas.


Catálogo de veículos atualizado na versão v39: foram adicionadas entradas para Tesla, Honda, Rolls-Royce, Bugatti, Bentley, BMW e Mercedes-Benz.

## Melhorias adicionais — serviços e documentos (v59)
- A área Nota Fiscal permite selecionar qualquer serviço, inclusive concluído, para preencher os dados básicos do documento.
- Notas/documentos podem ser salvos como cópias HTML editáveis e reabertos pela lista de documentos salvos.
- A Nota de Serviço também possui ação para salvar sua versão editável na mesma área de documentos salvos.
- As notas salvas ficam na pasta `.mecha-consertos/notas-fiscais` dentro da pasta pessoal do usuário.
- O documento salvo pelo sistema é uma cópia interna/editável e não equivale à transmissão/autorização de NF-e/NFS-e junto à SEFAZ ou prefeitura.
