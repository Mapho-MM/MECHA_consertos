# Loading vetorial de carro — v41

Foi adicionada a classe reutilizável `CarregamentoOficina`, que cria um overlay JavaFX com um carro desenhado por vetores e rotação contínua. Não depende de imagens externas nem de internet.

## Como integrar numa tela

```java
CarregamentoOficina carregamento = new CarregamentoOficina(conteudoAtual);
Scene scene = new Scene(carregamento.getRoot(), 1200, 800);

// Quando uma operação demorada começar:
carregamento.mostrar("Carregando veículos...");

// Ao terminar, tanto em sucesso como em erro:
carregamento.ocultar();
```

Em operações de banco de dados/rede, execute o trabalho pesado numa `Task` ou `Service` JavaFX e chame `mostrar`/`ocultar` na thread JavaFX. Sempre oculte o indicador também no tratamento de falhas.

**Nota:** a classe está pronta para ser conectada às operações demoradas; não foi inserida automaticamente em todas as telas, pois isso exige mover cada operação bloqueante para tarefas assíncronas para não congelar a animação.
