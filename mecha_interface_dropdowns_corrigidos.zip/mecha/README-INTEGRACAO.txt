ESTRUTURA DE TELAS (UMA TELA POR ARQUIVO)
==========================================
Antes tudo ficava em hello-view.fxml + HelloController. Agora cada tela tem o seu
FXML e o seu controller (src/main/resources/.../*.fxml e src/main/java/.../*.java):

  Tela                      FXML                             Controller
  ------------------------  -------------------------------  ------------------------------
  Janela principal          main-view.fxml                   MainController
  Abertura animada          splash-view.fxml                 SplashController
  Login                     login-view.fxml                  LoginController
  Ajuda (senha/login)       ajuda-view.fxml                  AjudaController
  Painel do administrador   dashboard-admin-view.fxml        DashboardAdminController
  Painel do funcionário     dashboard-funcionario-view.fxml  DashboardFuncionarioController
  Carregando (carro)        carregando-view.fxml             CarregandoController

Classes compartilhadas (sem tela própria):
  Navegador              troca de telas: Navegador.ir(Navegador.Tela.LOGIN), irParaPainel(usuario),
                         voltarAoLogin(), executarComCarregamento(...)
  TelaController         ganchos opcionais de cada tela: aoEntrar, aoMudarTema, aoMudarLayout,
                         aoAtualizarAvatar
  Tema                   paletas, cores de destaque, Liquid Glass, tamanho da janela, debug
  Dialogos               avisos/confirmações e blocos visuais no tema atual
  PerfilDialogo          "Minha conta" e foto de perfil
  ConfiguracoesDialogo   Configurações (Tema / Interface / Sobre)
  PesquisaDialogo        pesquisa com sugestões
  DashboardBase          parte comum dos dois painéis (menu, perfil, pesquisa, configurações)

Para criar uma tela nova:
  1) crie nome-view.fxml com fx:controller apontando para o novo controller;
  2) crie o controller (opcionalmente implements TelaController);
  3) adicione uma linha no enum Navegador.Tela;
  4) abra com Navegador.ir(Navegador.Tela.NOVA).

O comportamento (login, temas, configurações só no admin, modo desenvolvedor, loading do carro)
continua o mesmo; só mudou onde cada código mora.

--------------------------------------------------------------------------------------------

MECHA CONSERTOS - AJUSTES DE INTERFACE E LOGIN

Alterações:
- Loading vetorial de carro girando mantido e reutilizável para tarefas demoradas.
- Try/catch na inicialização, login, cadastro, configurações e retorno ao login.
- Ao voltar ao login, usuário/senha são limpos, sessão encerrada e senha volta ao modo oculto.
- CSS externo criado em src/main/resources/com/senai/javafx/projeto02/style.css e carregado pela aplicação.
- AppSingleton.java criado para centralizar sessão e preferências.
- Temas: Claro, Escuro, Automático e Liquid Glass.
- Tema fica salvo e é restaurado ao abrir o sistema.
- Configurações ficam somente no menu do Administrador.
- O visual Liquid Glass foi inspirado nos princípios visuais da referência enviada, adaptado para JavaFX.

Validação:
- hello-view.fxml validado como XML.
- Balanceamento de chaves do HelloController.java verificado.
- Maven não foi executado neste ambiente porque o acesso ao repositório Maven está indisponível.


MODO DESENVOLVEDOR / DEBUG
----------------------------
Em Configurações > Interface existe a opção "Modo desenvolvedor".
Quando ativada, a aplicação salva a preferência e registra eventos técnicos no console do IntelliJ com o prefixo [DEBUG].
O modo fica desativado por padrão e não altera o fluxo normal do sistema quando desligado.


CATÁLOGO DE VEÍCULOS (v32)
- Cadastro de veículo com campos Marca e Modelo, catálogo local baseado em car-list.json.
- Digitar uma combinação reconhecida (ex.: Fiat Uno ou Toyota Corolla) tenta preencher marca/modelo.
- O catálogo funciona offline; ano, versão, motorização, combustível e cor não são inferidos porque o arquivo de origem não contém esses dados.
