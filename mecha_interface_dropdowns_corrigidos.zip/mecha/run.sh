#!/usr/bin/env bash
cd "$(dirname "$0")"
if [ -x ./mvnw ]; then
  ./mvnw clean javafx:run
else
  mvn clean javafx:run
fi
