package com.senai.javafx.projeto02.entidades;

import com.senai.javafx.projeto02.Permissoes;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

/**
 * Regras de negócio da oficina — adaptado do Main.java (console).
 * Fonte única de dados para todos os módulos JavaFX.
 */
public final class OficinaService {

    private OficinaService() {
    }

    public static Oficina oficina() {
        return SingleTon.getInstancia().getOficina();
    }

    // ===================== DADOS INICIAIS =====================

    public static void carregarDadosIniciais(Oficina oficina) {
        if (oficina.getClientes().isEmpty()
                && oficina.getEstoque().isEmpty()
                && oficina.getCatalogoServicos().isEmpty()
                && oficina.getMecanicos().isEmpty()) {
            // Só seed se tudo vazio (primeira execução sem persistência)
            seedDemo(oficina);
        }
    }

    public static void seedDemo(Oficina oficina) {
        oficina.getClientes().clear();
        oficina.getEstoque().clear();
        oficina.getCatalogoServicos().clear();
        oficina.getMecanicos().clear();

        oficina.getClientes().add(new Cliente("Joana de Silva Oliveira", "123.456.789-10", "(48) 98487-1270"));
        oficina.getClientes().add(new Cliente("Paulo Ricardo Mendonça Silveira", "987.456.677-10", "(54) 95874-2853"));
        oficina.getClientes().add(new Cliente("Rogério Alves Mazzino", "567.453.422-20", "(99) 91026-4723"));

        oficina.getEstoque().add(new Estoque("Ar-condicionado", 5, 60.00, false));
        oficina.getEstoque().add(new Estoque("Virabrequim", 5, 40.00, false));
        oficina.getEstoque().add(new Estoque("Freio", 5, 80.00, false));
        oficina.getEstoque().add(new Estoque("Filtro de óleo", 12, 45.00, false));
        oficina.getEstoque().add(new Estoque("Pastilha de freio", 8, 150.00, false));

        oficina.getCatalogoServicos().add(new Servico(29.99, "Troca de óleo"));
        oficina.getCatalogoServicos().add(new Servico(89.90, "Alinhamento e balanceamento"));
        oficina.getCatalogoServicos().add(new Servico(120.00, "Revisão de freios"));
        oficina.getCatalogoServicos().add(new Servico(250.00, "Troca de correia dentada"));

        oficina.getMecanicos().add(new Mecanico("Carlos Eduardo", 2800.00));
        oficina.getMecanicos().add(new Mecanico("Fernanda Souza", 3100.00));
        oficina.getMecanicos().add(new Mecanico("Ricardo Lima", 2950.00));

        Cliente joana = oficina.getClientes().get(0);
        Veiculo v1 = new Veiculo("ABC-1D23", "Fiat Uno 1.0");
        joana.adicionarVeiculo(v1);
        Servico s1 = oficina.getCatalogoServicos().get(0).copiar();
        s1.setStatus(Status.ANDAMENTO);
        s1.adicionarMecanico(oficina.getMecanicos().get(0));
        v1.getServicos().add(s1);
        joana.setStatus(Status.ANDAMENTO);

        Cliente paulo = oficina.getClientes().get(1);
        paulo.adicionarVeiculo(new Veiculo("XYZ-9K87", "VW Gol 1.6"));
    }

    // ===================== CLIENTES =====================

    public static Cliente cadastrarCliente(String nome, String cpf, String telefone) {
        Permissoes.exigirAdmin("cadastrar cliente");
        nome = limpar(nome);
        cpf = limpar(cpf);
        telefone = limpar(telefone);
        if (nome.isBlank() || cpf.isBlank() || telefone.isBlank()) {
            throw new IllegalArgumentException("Preencha nome, CPF e telefone.");
        }
        if (buscarClientePorCpf(cpf) != null) {
            throw new IllegalArgumentException("Já existe um cliente com este CPF.");
        }
        Cliente c = new Cliente(nome, cpf, telefone);
        oficina().getClientes().add(c);
        PersistenciaOficina.salvar();
        return c;
    }

    public static void editarCliente(Cliente c, String nome, String cpf, String telefone) {
        Permissoes.exigirAdmin("editar cliente");
        Objects.requireNonNull(c);
        nome = limpar(nome);
        cpf = limpar(cpf);
        telefone = limpar(telefone);
        if (nome.isBlank() || cpf.isBlank() || telefone.isBlank()) {
            throw new IllegalArgumentException("Preencha nome, CPF e telefone.");
        }
        Cliente outro = buscarClientePorCpf(cpf);
        if (outro != null && outro != c) {
            throw new IllegalArgumentException("Já existe um cliente com este CPF.");
        }
        c.setNome(nome);
        c.setCpf(cpf);
        c.setTelefone(telefone);
        PersistenciaOficina.salvar();
    }

    public static void removerCliente(Cliente c) {
        Permissoes.exigirAdmin("remover cliente");
        Objects.requireNonNull(c);
        for (Veiculo v : new ArrayList<>(c.getCarros())) {
            devolverPecasAoEstoque(v);
            c.removerVeiculo(v);
        }
        oficina().getClientes().remove(c);
        PersistenciaOficina.salvar();
    }

    public static Cliente buscarClientePorCpf(String cpf) {
        String n = limpar(cpf);
        for (Cliente c : oficina().getClientes()) {
            if (c.getCpf().equalsIgnoreCase(n)) return c;
        }
        return null;
    }

    // ===================== VEÍCULOS =====================

    public static Veiculo cadastrarVeiculo(Cliente cliente, String placa, String modelo) {
        Permissoes.exigirAdmin("cadastrar veículo");
        Objects.requireNonNull(cliente);
        placa = limpar(placa).toUpperCase(Locale.ROOT);
        modelo = limpar(modelo);
        if (placa.isBlank() || modelo.isBlank()) {
            throw new IllegalArgumentException("Informe placa e modelo.");
        }
        if (placaJaCadastrada(placa, null)) {
            throw new IllegalArgumentException("Placa já cadastrada: " + placa);
        }
        Veiculo v = new Veiculo(placa, modelo);
        cliente.adicionarVeiculo(v);
        PersistenciaOficina.salvar();
        return v;
    }

    public static void editarVeiculo(Veiculo v, String placa, String modelo) {
        Permissoes.exigirAdmin("editar veículo");
        Objects.requireNonNull(v);
        placa = limpar(placa).toUpperCase(Locale.ROOT);
        modelo = limpar(modelo);
        if (placa.isBlank() || modelo.isBlank()) {
            throw new IllegalArgumentException("Informe placa e modelo.");
        }
        if (placaJaCadastrada(placa, v)) {
            throw new IllegalArgumentException("Placa já cadastrada: " + placa);
        }
        v.setPlaca(placa);
        v.setModelo(modelo);
        PersistenciaOficina.salvar();
    }

    public static void removerVeiculo(Cliente cliente, Veiculo v) {
        Permissoes.exigirAdmin("remover veículo");
        Objects.requireNonNull(cliente);
        Objects.requireNonNull(v);
        devolverPecasAoEstoque(v);
        cliente.removerVeiculo(v);
        atualizarStatusCliente(cliente);
        PersistenciaOficina.salvar();
    }

    public static boolean placaJaCadastrada(String placa, Veiculo excecao) {
        for (Cliente c : oficina().getClientes()) {
            for (Veiculo v : c.getCarros()) {
                if (v != excecao && v.getPlaca().equalsIgnoreCase(placa)) return true;
            }
        }
        return false;
    }

    public static List<Veiculo> listarTodosVeiculos() {
        List<Veiculo> lista = new ArrayList<>();
        for (Cliente c : oficina().getClientes()) lista.addAll(c.getCarros());
        return lista;
    }

    // ===================== SERVIÇOS (CATÁLOGO + EXECUÇÃO) =====================

    public static Servico cadastrarServicoCatalogo(String nome, double preco) {
        Permissoes.exigirAdmin("cadastrar serviço");
        nome = limpar(nome);
        if (nome.isBlank()) throw new IllegalArgumentException("Informe o nome do serviço.");
        if (preco < 0) throw new IllegalArgumentException("Preço não pode ser negativo.");
        Servico s = new Servico(preco, nome);
        oficina().getCatalogoServicos().add(s);
        PersistenciaOficina.salvar();
        return s;
    }

    public static void editarServicoCatalogo(Servico s, String nome, double preco) {
        Permissoes.exigirAdmin("editar serviço");
        Objects.requireNonNull(s);
        nome = limpar(nome);
        if (nome.isBlank()) throw new IllegalArgumentException("Informe o nome.");
        if (preco < 0) throw new IllegalArgumentException("Preço não pode ser negativo.");
        s.setNome(nome);
        s.setPreco(preco);
        PersistenciaOficina.salvar();
    }

    public static void removerServicoCatalogo(Servico s) {
        Permissoes.exigirAdmin("remover serviço");
        oficina().getCatalogoServicos().remove(s);
        PersistenciaOficina.salvar();
    }

    /**
     * Vincula uma cópia do serviço do catálogo ao veículo (execução independente).
     */
    public static Servico vincularServicoAoVeiculo(Cliente cliente, Veiculo veiculo, Servico doCatalogo, Mecanico mecanico) {
        Permissoes.exigirAdmin("criar ordem de serviço");
        Objects.requireNonNull(cliente);
        Objects.requireNonNull(veiculo);
        Objects.requireNonNull(doCatalogo);
        Servico exec = doCatalogo.copiar();
        // Nova OS começa como ORÇAMENTO (cliente ainda não aprovou)
        exec.setStatus(Status.ORCAMENTO);
        if (mecanico != null) {
            exec.adicionarMecanico(mecanico);
        }
        veiculo.getServicos().add(exec);
        doCatalogo.incrementarUso();
        atualizarStatusCliente(cliente);
        PersistenciaOficina.salvar();
        return exec;
    }

    /**
     * Cliente aprovou o orçamento → status AGENDADO (gera Nota de Serviço no controller).
     */
    public static void aprovarOrcamento(Cliente cliente, Veiculo veiculo, Servico exec) {
        Objects.requireNonNull(exec);
        if (exec.getStatus() != Status.ORCAMENTO) {
            throw new IllegalStateException("Só é possível aprovar itens em ORÇAMENTO. Status atual: " + exec.getStatus());
        }
        if (!exec.avancarStatus(Status.AGENDADO)) {
            throw new IllegalStateException("Falha ao aprovar orçamento. Status atual: " + exec.getStatus());
        }
        atualizarStatusCliente(cliente);
        PersistenciaOficina.salvar();
    }

    public static void iniciarServico(Cliente cliente, Veiculo veiculo, Servico exec) {
        Objects.requireNonNull(exec);
        if (exec.getMecanicos().isEmpty()) {
            throw new IllegalStateException("Atribua um mecânico antes de iniciar o serviço.");
        }
        if (exec.getStatus() == Status.ORCAMENTO) {
            throw new IllegalStateException("Aprove o orçamento (cliente) antes de iniciar o serviço.");
        }
        if (!exec.avancarStatus(Status.ANDAMENTO)) {
            throw new IllegalStateException("Só é possível iniciar serviços AGENDADOS. Status atual: " + exec.getStatus());
        }
        atualizarStatusCliente(cliente);
        PersistenciaOficina.salvar();
    }

    public static void finalizarServico(Cliente cliente, Veiculo veiculo, Servico exec) {
        Objects.requireNonNull(exec);
        if (oficina().getMecanicos().isEmpty()) {
            throw new IllegalStateException("Não há mecânicos cadastrados.");
        }
        if (exec.getMecanicos().isEmpty()) {
            throw new IllegalStateException("O serviço precisa de um mecânico responsável.");
        }
        if (!exec.avancarStatus(Status.FINALIZADO)) {
            throw new IllegalStateException("Só é possível finalizar serviços EM ANDAMENTO. Status atual: " + exec.getStatus());
        }
        atualizarStatusCliente(cliente);
        PersistenciaOficina.salvar();
    }

    public static void atribuirMecanico(Servico exec, Mecanico m) {
        Objects.requireNonNull(exec);
        Objects.requireNonNull(m);
        if (!exec.adicionarMecanico(m)) {
            throw new IllegalStateException("Este mecânico já está atribuído a este serviço.");
        }
        PersistenciaOficina.salvar();
    }

    public static void removerMecanicoDoServico(Servico exec, Mecanico m) {
        exec.removerMecanico(m);
        PersistenciaOficina.salvar();
    }

    public static void removerServicoDoVeiculo(Cliente cliente, Veiculo veiculo, Servico exec) {
        if (exec.getStatus() != Status.AGENDADO && exec.getStatus() != Status.ORCAMENTO) {
            throw new IllegalStateException("Não é possível remover um serviço já iniciado ou finalizado.");
        }
        veiculo.getServicos().remove(exec);
        atualizarStatusCliente(cliente);
        PersistenciaOficina.salvar();
    }

    // ===================== MECÂNICOS =====================

    public static Mecanico cadastrarMecanico(String nome, double salario) {
        return cadastrarMecanico(nome, salario, "");
    }

    public static Mecanico cadastrarMecanico(String nome, double salario, String loginVinculado) {
        Permissoes.exigirAdmin("cadastrar mecânico");
        nome = limpar(nome);
        if (nome.isBlank()) throw new IllegalArgumentException("Informe o nome.");
        if (salario < 0) throw new IllegalArgumentException("Salário não pode ser negativo.");
        Mecanico m = new Mecanico(nome, salario, loginVinculado);
        oficina().getMecanicos().add(m);
        PersistenciaOficina.salvar();
        return m;
    }

    public static void editarMecanico(Mecanico m, String nome, double salario) {
        editarMecanico(m, nome, salario, m.getLoginVinculado());
    }

    public static void editarMecanico(Mecanico m, String nome, double salario, String loginVinculado) {
        Permissoes.exigirAdmin("editar mecânico");
        Objects.requireNonNull(m);
        nome = limpar(nome);
        if (nome.isBlank()) throw new IllegalArgumentException("Informe o nome.");
        if (salario < 0) throw new IllegalArgumentException("Salário não pode ser negativo.");
        m.setNome(nome);
        m.setSalario(salario);
        m.setLoginVinculado(loginVinculado);
        PersistenciaOficina.salvar();
    }

    /** Localiza mecânico vinculado ao login da conta (e-mail). */
    public static Mecanico buscarMecanicoPorLogin(String login) {
        if (login == null || login.isBlank()) return null;
        String l = login.trim().toLowerCase(Locale.ROOT);
        for (Mecanico m : oficina().getMecanicos()) {
            if (l.equals(m.getLoginVinculado())) return m;
        }
        return null;
    }

    public static void removerMecanico(Mecanico m) {
        Permissoes.exigirAdmin("remover mecânico");
        // remove de serviços
        for (Cliente c : oficina().getClientes()) {
            for (Veiculo v : c.getCarros()) {
                for (Servico s : v.getServicos()) {
                    s.removerMecanico(m);
                }
            }
        }
        oficina().getMecanicos().remove(m);
        PersistenciaOficina.salvar();
    }

    public static int contarServicosDoMecanico(Mecanico m) {
        int n = 0;
        for (Cliente c : oficina().getClientes()) {
            for (Veiculo v : c.getCarros()) {
                for (Servico s : v.getServicos()) {
                    if (s.getMecanicos().contains(m)) n++;
                }
            }
        }
        return n;
    }

    // ===================== ESTOQUE =====================

    public static Estoque cadastrarPeca(String produto, int qtd, double preco) {
        Permissoes.exigirAdmin("cadastrar peça");
        produto = limpar(produto);
        if (produto.isBlank()) throw new IllegalArgumentException("Informe o nome da peça.");
        if (qtd < 0) throw new IllegalArgumentException("Quantidade não pode ser negativa.");
        if (preco < 0) throw new IllegalArgumentException("Preço não pode ser negativo.");
        Estoque e = new Estoque(produto, qtd, preco);
        oficina().getEstoque().add(e);
        PersistenciaOficina.salvar();
        return e;
    }

    public static void editarPeca(Estoque e, String produto, int qtd, double preco) {
        Permissoes.exigirAdmin("editar peça");
        Objects.requireNonNull(e);
        produto = limpar(produto);
        if (produto.isBlank()) throw new IllegalArgumentException("Informe o nome.");
        if (qtd < 0) throw new IllegalArgumentException("Quantidade inválida.");
        if (preco < 0) throw new IllegalArgumentException("Preço inválido.");
        e.setProduto(produto);
        e.setQuantidade(qtd);
        e.setPreco(preco);
        PersistenciaOficina.salvar();
    }

    public static void reporEstoque(Estoque e, int qtdAdicionar) {
        Permissoes.exigirAdmin("repor estoque");
        Objects.requireNonNull(e);
        if (qtdAdicionar <= 0) throw new IllegalArgumentException("Informe uma quantidade positiva.");
        e.setQuantidade(e.getQuantidade() + qtdAdicionar);
        PersistenciaOficina.salvar();
    }

    public static void venderPecaSeparada(Estoque e, int qtd) {
        Permissoes.exigirAdmin("vender peça");
        Objects.requireNonNull(e);
        if (qtd <= 0) throw new IllegalArgumentException("Quantidade deve ser positiva.");
        if (e.getQuantidade() < qtd) throw new IllegalStateException("Estoque insuficiente.");
        e.setQuantidade(e.getQuantidade() - qtd);
        PersistenciaOficina.salvar();
    }

    public static void adicionarPecaAoVeiculo(Cliente cliente, Veiculo veiculo, Estoque peca, int qtd) {
        Permissoes.exigirAdmin("adicionar peça ao veículo");
        Objects.requireNonNull(veiculo);
        Objects.requireNonNull(peca);
        if (qtd <= 0) throw new IllegalArgumentException("Quantidade deve ser positiva.");
        if (peca.getQuantidade() < qtd) throw new IllegalStateException("Estoque insuficiente. Disponível: " + peca.getQuantidade());

        peca.setQuantidade(peca.getQuantidade() - qtd);
        PecaUtilizada existente = buscarPecaUtilizada(veiculo, peca);
        if (existente != null) {
            existente.setQuantidade(existente.getQuantidade() + qtd);
        } else {
            veiculo.getPecasUtilizadas().add(new PecaUtilizada(peca, qtd));
        }
        if (cliente != null) atualizarStatusCliente(cliente);
        PersistenciaOficina.salvar();
    }

    public static void removerPecaDoCatalogo(Estoque e) {
        Permissoes.exigirAdmin("remover peça do catálogo");
        // verifica vínculos
        for (Cliente c : oficina().getClientes()) {
            for (Veiculo v : c.getCarros()) {
                for (PecaUtilizada p : v.getPecasUtilizadas()) {
                    if (p.getOrigemEstoque() == e) {
                        throw new IllegalStateException("Peça vinculada a veículos. Remova dos veículos antes.");
                    }
                }
            }
        }
        oficina().getEstoque().remove(e);
        PersistenciaOficina.salvar();
    }

    public static void alterarPecaNoVeiculo(Veiculo veiculo, PecaUtilizada usada, int novaQtd) {
        Permissoes.exigirAdmin("alterar peça no veículo");
        Objects.requireNonNull(usada);
        if (novaQtd <= 0) throw new IllegalArgumentException("Quantidade deve ser positiva.");
        int diff = novaQtd - usada.getQuantidade();
        Estoque origem = usada.getOrigemEstoque();
        if (diff > 0) {
            if (origem.getQuantidade() < diff) throw new IllegalStateException("Estoque insuficiente.");
            origem.setQuantidade(origem.getQuantidade() - diff);
        } else if (diff < 0) {
            origem.setQuantidade(origem.getQuantidade() + (-diff));
        }
        usada.setQuantidade(novaQtd);
        PersistenciaOficina.salvar();
    }

    public static void removerPecaDoVeiculo(Veiculo veiculo, PecaUtilizada usada) {
        Permissoes.exigirAdmin("remover peça do veículo");
        Estoque origem = usada.getOrigemEstoque();
        origem.setQuantidade(origem.getQuantidade() + usada.getQuantidade());
        veiculo.getPecasUtilizadas().remove(usada);
        PersistenciaOficina.salvar();
    }

    public static void devolverPecasAoEstoque(Veiculo veiculo) {
        for (PecaUtilizada p : new ArrayList<>(veiculo.getPecasUtilizadas())) {
            Estoque o = p.getOrigemEstoque();
            if (o != null) o.setQuantidade(o.getQuantidade() + p.getQuantidade());
        }
        veiculo.getPecasUtilizadas().clear();
    }

    public static PecaUtilizada buscarPecaUtilizada(Veiculo veiculo, Estoque peca) {
        for (PecaUtilizada u : veiculo.getPecasUtilizadas()) {
            if (u.getOrigemEstoque() == peca) return u;
        }
        return null;
    }

    public static int totalUnidadesEstoque() {
        int t = 0;
        for (Estoque e : oficina().getEstoque()) t += e.getQuantidade();
        return t;
    }

    public static int itensEstoqueBaixo(int limite) {
        int n = 0;
        for (Estoque e : oficina().getEstoque()) if (e.getQuantidade() <= limite) n++;
        return n;
    }

    public static double valorEstoque() {
        double t = 0;
        for (Estoque e : oficina().getEstoque()) t += e.getPreco() * e.getQuantidade();
        return t;
    }

    // ===================== STATUS / FINANCEIRO =====================

    public static void atualizarStatusCliente(Cliente cliente) {
        boolean temServico = false;
        boolean existeEmAndamento = false;
        boolean todosFinalizados = true;
        for (Veiculo v : cliente.getCarros()) {
            for (Servico s : v.getServicos()) {
                temServico = true;
                if (s.getStatus() == Status.ANDAMENTO) existeEmAndamento = true;
                if (s.getStatus() != Status.FINALIZADO) todosFinalizados = false;
            }
        }
        if (!temServico) cliente.setStatus(Status.ORCAMENTO);
        else if (todosFinalizados) cliente.setStatus(Status.FINALIZADO);
        else if (existeEmAndamento) cliente.setStatus(Status.ANDAMENTO);
        else cliente.setStatus(Status.AGENDADO);
    }

    public static GerenciadorContadores contadores() {
        GerenciadorContadores g = new GerenciadorContadores();
        g.atualizarContadoresDaLista(oficina().getClientes());
        return g;
    }

    /** Conta execuções de serviço por status (não status do cliente). */
    public static int contarServicosPorStatus(Status st) {
        int n = 0;
        for (Cliente c : oficina().getClientes()) {
            for (Veiculo v : c.getCarros()) {
                for (Servico s : v.getServicos()) {
                    if (s.getStatus() == st) n++;
                }
            }
        }
        return n;
    }

    public static double totalFinanceiroClientes() {
        double t = 0;
        for (Cliente c : oficina().getClientes()) t += c.calcularTotal();
        return t;
    }

    public static double somarServicos(Veiculo veiculo) {
        double t = 0;
        for (Servico s : veiculo.getServicos()) t += s.getPreco();
        return t;
    }

    public static double somarPecas(Veiculo veiculo) {
        double t = 0;
        for (PecaUtilizada p : veiculo.getPecasUtilizadas()) t += p.getSubtotal();
        return t;
    }

    /** Soma dos salários de todos os mecânicos cadastrados. */
    public static double totalSalariosMecanicos() {
        double t = 0;
        for (Mecanico m : oficina().getMecanicos()) t += m.getSalario();
        return t;
    }

    /**
     * Valor total em estoque apenas dos produtos cadastrados após a abertura do sistema
     * (exclui itens do seed de demonstração).
     */
    public static double valorEstoqueAposAbertura() {
        double t = 0;
        for (Estoque e : oficina().getEstoque()) {
            if (e.isAposAbertura()) t += e.getPreco() * e.getQuantidade();
        }
        return t;
    }

    /** Soma do subtotal de todas as peças aplicadas em veículos/serviços. */
    public static double totalPecasUtilizadas() {
        double t = 0;
        for (Cliente c : oficina().getClientes()) {
            for (Veiculo v : c.getCarros()) {
                t += somarPecas(v);
            }
        }
        return t;
    }

    /**
     * Despesas para cálculo de lucro: peças usadas em serviços + salários dos mecânicos.
     */
    public static double totalDespesasLucro() {
        return totalPecasUtilizadas() + totalSalariosMecanicos();
    }

    /**
     * Gastos totais (visão de estoque): salários + valor das peças cadastradas após abertura.
     */
    public static double totalGastosEstoqueESalarios() {
        return totalSalariosMecanicos() + valorEstoqueAposAbertura();
    }

    /** Lucro = total pago pelos clientes − (peças usadas + salários). */
    public static double calcularLucro() {
        return totalFinanceiroClientes() - totalDespesasLucro();
    }

    public static String formatarMoeda(double v) {
        return String.format(Locale.forLanguageTag("pt-BR"), "R$ %.2f", v);
    }

    private static String limpar(String s) {
        return s == null ? "" : s.trim();
    }
}
