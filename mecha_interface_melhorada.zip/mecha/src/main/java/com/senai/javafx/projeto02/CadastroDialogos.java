package com.senai.javafx.projeto02;

import com.senai.javafx.projeto02.Tema.Paleta;
import com.senai.javafx.projeto02.entidades.*;
import javafx.application.Platform;
import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

import java.util.List;

import static com.senai.javafx.projeto02.Dialogos.*;
import static com.senai.javafx.projeto02.Tema.*;

/** Formulários de cadastro, edição e operações da oficina. */
public final class CadastroDialogos {

    private CadastroDialogos() {}

    // ---------- CLIENTE ----------
    public static void cadastrarCliente(Runnable aoSalvar) {
        formCliente(null, aoSalvar);
    }

    public static void editarCliente(Cliente c, Runnable aoSalvar) {
        formCliente(c, aoSalvar);
    }

    private static void formCliente(Cliente existente, Runnable aoSalvar) {
        try {
            garantir();
            Paleta p = paletaAtual();
            Stage janela = criarJanelaTematica();
            VBox cartao = criarCartaoTematico(440, p);
            cartao.setSpacing(10);

            TextField nome = campo(p, "Nome completo");
            TextField cpf = campo(p, "CPF");
            TextField tel = campo(p, "Telefone");
            if (existente != null) {
                nome.setText(existente.getNome());
                cpf.setText(existente.getCpf());
                tel.setText(existente.getTelefone());
            }
            Label erro = labelErro();

            Button salvar = botaoPrimario(existente == null ? "Salvar cliente" : "Salvar alterações", p);
            salvar.setOnAction(e -> {
                try {
                    if (vazio(nome, cpf, tel)) { erro.setText("Preencha todos os campos."); return; }
                    if (existente == null) OficinaService.cadastrarCliente(nome.getText(), cpf.getText(), tel.getText());
                    else OficinaService.editarCliente(existente, nome.getText(), cpf.getText(), tel.getText());
                    fecharOk(janela, aoSalvar, existente == null ? "Cliente cadastrado!" : "Cliente atualizado!");
                } catch (Exception ex) { erro.setText(msg(ex)); }
            });
            Button cancelar = botaoSecundario("Cancelar", p);
            cancelar.setOnAction(ev -> janela.close());

            cartao.getChildren().addAll(
                    criarTitulo(existente == null ? "Novo cliente" : "Editar cliente", p),
                    rotulo("Nome", p), nome, rotulo("CPF", p), cpf, rotulo("Telefone", p), tel,
                    erro, botoes(cancelar, salvar));
            exibirJanela(janela, cartao);
        } catch (Exception ex) {
            mostrarMensagem("Erro", msg(ex));
        }
    }

    // ---------- VEÍCULO ----------
    public static void cadastrarVeiculo(Runnable aoSalvar) {
        formVeiculo(null, null, aoSalvar);
    }

    public static void editarVeiculo(Cliente dono, Veiculo v, Runnable aoSalvar) {
        formVeiculo(dono, v, aoSalvar);
    }

    private static void formVeiculo(Cliente donoFixo, Veiculo existente, Runnable aoSalvar) {
        try {
            garantir();
            List<Cliente> clientes = OficinaService.oficina().getClientes();
            if (clientes.isEmpty()) { mostrarMensagem("Veículo", "Cadastre um cliente antes."); return; }

            Paleta p = paletaAtual();
            Stage janela = criarJanelaTematica();
            VBox cartao = criarCartaoTematico(440, p);
            cartao.setSpacing(10);

            ComboBox<Cliente> combo = comboClientes(clientes, p);
            if (donoFixo != null) {
                combo.getSelectionModel().select(donoFixo);
                combo.setDisable(true);
            } else if (existente != null && existente.getProprietario() != null) {
                combo.getSelectionModel().select(existente.getProprietario());
                combo.setDisable(true);
            }

            TextField placa = campo(p, "ABC-1D23");
            // Prévia de logotipo: nesta versão de teste, Porsche usa a imagem SVG fornecida.
            WebView logoMarca = new WebView();
            logoMarca.setPrefSize(112, 76);
            logoMarca.setMinSize(112, 76);
            logoMarca.setMaxSize(112, 76);
            logoMarca.setContextMenuEnabled(false);
            logoMarca.setStyle("-fx-background-color: transparent;");
            Label nomeMarcaPreview = new Label("Selecione uma marca para ver sua identificação visual");
            nomeMarcaPreview.setWrapText(true);
            nomeMarcaPreview.setStyle("-fx-font-size: 11px; -fx-text-fill: " + p.textoSec() + ";");
            HBox previewMarca = new HBox(10, logoMarca, nomeMarcaPreview);
            previewMarca.setAlignment(Pos.CENTER_LEFT);
            logoMarca.setVisible(false);
            logoMarca.setManaged(false);
            ComboBox<String> marca = new ComboBox<>();
            marca.getItems().setAll(CarCatalogService.marcas());
            marca.setEditable(true);
            marca.setMaxWidth(Double.MAX_VALUE);
            marca.setPromptText("Digite a marca (ex.: Ferrari)");
            ComboBox<String> modelo = new ComboBox<>();
            modelo.setEditable(true);
            modelo.setMaxWidth(Double.MAX_VALUE);
            modelo.setPromptText("Digite o modelo (ex.: 458 Italia)");
            configurarComboVeiculo(marca, () -> CarCatalogService.marcas(), p);
            configurarComboVeiculo(modelo, () -> {
                String m = marca.getEditor().getText();
                return CarCatalogService.modelos(m);
            }, p);
            Label dica = new Label("Digite a marca ou o modelo: as opções serão filtradas automaticamente. Também aceita ‘Ferrari 458 Italia’.");
            dica.setWrapText(true);
            dica.setStyle("-fx-font-size: 11px; -fx-text-fill: " + p.textoSec() + ";");

            final boolean[] atualizandoCatalogo = {false};
            Runnable atualizarModelos = () -> {
                if (atualizandoCatalogo[0]) return;
                atualizandoCatalogo[0] = true;
                try { modelo.getItems().setAll(CarCatalogService.modelos(marca.getEditor().getText())); }
                finally { atualizandoCatalogo[0] = false; }
            };
            Runnable atualizarPreviewMarca = () -> {
                String nome = marca.getEditor().getText() == null ? "" : marca.getEditor().getText().trim();
                if (nome.equalsIgnoreCase("Porsche")) {
                    String urlLogo = "https://cdn.brandfetch.io/idOSUjsXG-/theme/dark/idsOGnpYPS.svg?c=1bxid64Mup7aczewSAYMX\u0026t=1726555554300";
                    logoMarca.getEngine().loadContent("<!doctype html><html><body style='margin:0;background:transparent;display:flex;align-items:center;justify-content:center;height:100vh;overflow:hidden'><img alt='Porsche' style='max-width:108px;max-height:72px;object-fit:contain' src='" + urlLogo + "'></body></html>");
                    logoMarca.setVisible(true);
                    logoMarca.setManaged(true);
                    nomeMarcaPreview.setText("Porsche — logotipo de teste");
                } else {
                    logoMarca.setVisible(false);
                    logoMarca.setManaged(false);
                    nomeMarcaPreview.setText(nome.isBlank() ? "Selecione uma marca para ver sua identificação visual" : nome + " — logotipo ainda não cadastrado");
                }
            };
            marca.valueProperty().addListener((o, a, b) -> { atualizarModelos.run(); atualizarPreviewMarca.run(); });
            marca.getEditor().textProperty().addListener((o, a, b) -> {
                atualizarPreviewMarca.run();
                if (atualizandoCatalogo[0] || b == null || b.isBlank()) return;
                atualizarModelos.run();
                CarCatalogService.detectar(b).filter(id -> !id.modelo().isBlank()).ifPresent(id -> {
                    atualizandoCatalogo[0] = true;
                    try {
                        marca.setValue(id.marca()); marca.getEditor().setText(id.marca());
                        modelo.getItems().setAll(CarCatalogService.modelos(id.marca()));
                        modelo.setValue(id.modelo()); modelo.getEditor().setText(id.modelo());
                    } finally { atualizandoCatalogo[0] = false; }
                });
            });
            modelo.getEditor().textProperty().addListener((o, a, b) -> {
                if (atualizandoCatalogo[0] || b == null || b.isBlank()) return;
                CarCatalogService.detectar(b).ifPresent(id -> {
                    atualizandoCatalogo[0] = true;
                    try {
                        marca.setValue(id.marca()); marca.getEditor().setText(id.marca());
                        modelo.getItems().setAll(CarCatalogService.modelos(id.marca()));
                        if (!id.modelo().isBlank()) { modelo.setValue(id.modelo()); modelo.getEditor().setText(id.modelo()); }
                    } finally { atualizandoCatalogo[0] = false; }
                });
            });
            if (existente != null) {
                placa.setText(existente.getPlaca());
                String textoModelo = existente.getModelo();
                CarCatalogService.detectar(textoModelo).ifPresentOrElse(id -> {
                    marca.setValue(id.marca()); marca.getEditor().setText(id.marca());
                    modelo.getItems().setAll(CarCatalogService.modelos(id.marca()));
                    modelo.setValue(id.modelo()); modelo.getEditor().setText(id.modelo());
                }, () -> modelo.getEditor().setText(textoModelo));
            }
            Label erro = labelErro();

            Button salvar = botaoPrimario(existente == null ? "Salvar veículo" : "Salvar alterações", p);
            salvar.setOnAction(e -> {
                try {
                    Cliente cli = combo.getSelectionModel().getSelectedItem();
                    String marcaTexto = marca.getEditor().getText() == null ? "" : marca.getEditor().getText().trim();
                    String modeloTexto = modelo.getEditor().getText() == null ? "" : modelo.getEditor().getText().trim();
                    if (modeloTexto.isBlank()) { erro.setText("Informe o modelo do veículo."); return; }
                    String modeloCompleto = !marcaTexto.isBlank() && !modeloTexto.toLowerCase(java.util.Locale.ROOT).startsWith(marcaTexto.toLowerCase(java.util.Locale.ROOT) + " ")
                            ? marcaTexto + " " + modeloTexto : modeloTexto;
                    if (cli == null || placa.getText().isBlank()) { erro.setText("Preencha cliente e placa."); return; }
                    if (existente == null) OficinaService.cadastrarVeiculo(cli, placa.getText(), modeloCompleto);
                    else OficinaService.editarVeiculo(existente, placa.getText(), modeloCompleto);
                    fecharOk(janela, aoSalvar, existente == null ? "Veículo cadastrado!" : "Veículo atualizado!");
                } catch (Exception ex) { erro.setText(msg(ex)); }
            });
            Button cancelar = botaoSecundario("Cancelar", p);
            cancelar.setOnAction(ev -> janela.close());

            cartao.getChildren().addAll(
                    criarTitulo(existente == null ? "Novo veículo" : "Editar veículo", p),
                    rotulo("Cliente", p), combo, rotulo("Placa", p), placa,
                    rotulo("Marca", p), marca, rotulo("Modelo", p), modelo, dica,
                    erro, botoes(cancelar, salvar));
            exibirJanela(janela, cartao);
        } catch (Exception ex) {
            mostrarMensagem("Erro", msg(ex));
        }
    }

    // ---------- PEÇA ----------
    public static void cadastrarPeca(Runnable aoSalvar) { formPeca(null, aoSalvar); }
    public static void editarPeca(Estoque e, Runnable aoSalvar) { formPeca(e, aoSalvar); }

    private static void formPeca(Estoque existente, Runnable aoSalvar) {
        try {
            garantir();
            Paleta p = paletaAtual();
            Stage janela = criarJanelaTematica();
            VBox cartao = criarCartaoTematico(440, p);
            cartao.setSpacing(10);
            TextField produto = campo(p, "Nome da peça");
            TextField qtd = campo(p, "0");
            TextField preco = campo(p, "0.00");
            if (existente != null) {
                produto.setText(existente.getProduto());
                qtd.setText(String.valueOf(existente.getQuantidade()));
                preco.setText(String.valueOf(existente.getPreco()));
            }
            Label erro = labelErro();
            Button salvar = botaoPrimario("Salvar", p);
            salvar.setOnAction(e -> {
                try {
                    if (vazio(produto, qtd, preco)) { erro.setText("Preencha todos os campos."); return; }
                    int q = Integer.parseInt(qtd.getText().trim());
                    double pr = Double.parseDouble(preco.getText().trim().replace(',', '.'));
                    if (existente == null) OficinaService.cadastrarPeca(produto.getText(), q, pr);
                    else OficinaService.editarPeca(existente, produto.getText(), q, pr);
                    fecharOk(janela, aoSalvar, "Peça salva!");
                } catch (NumberFormatException nfe) { erro.setText("Quantidade/preço inválidos."); }
                catch (Exception ex) { erro.setText(msg(ex)); }
            });
            Button cancelar = botaoSecundario("Cancelar", p);
            cancelar.setOnAction(ev -> janela.close());
            cartao.getChildren().addAll(criarTitulo(existente == null ? "Nova peça" : "Editar peça", p),
                    rotulo("Produto", p), produto, rotulo("Quantidade", p), qtd, rotulo("Preço unitário", p), preco,
                    erro, botoes(cancelar, salvar));
            exibirJanela(janela, cartao);
        } catch (Exception ex) { mostrarMensagem("Erro", msg(ex)); }
    }

    public static void reporPeca(Estoque e, Runnable aoSalvar) {
        try {
            Paleta p = paletaAtual();
            Stage janela = criarJanelaTematica();
            VBox cartao = criarCartaoTematico(400, p);
            cartao.setSpacing(10);
            TextField qtd = campo(p, "Quantidade a adicionar");
            Label erro = labelErro();
            Button ok = botaoPrimario("Repor", p);
            ok.setOnAction(ev -> {
                try {
                    int q = Integer.parseInt(qtd.getText().trim());
                    OficinaService.reporEstoque(e, q);
                    fecharOk(janela, aoSalvar, "Estoque reposto!");
                } catch (Exception ex) { erro.setText(msg(ex)); }
            });
            Button cancelar = botaoSecundario("Cancelar", p);
            cancelar.setOnAction(x -> janela.close());
            cartao.getChildren().addAll(criarTitulo("Repor: " + e.getProduto(), p),
                    rotulo("Quantidade", p), qtd, erro, botoes(cancelar, ok));
            exibirJanela(janela, cartao);
        } catch (Exception ex) { mostrarMensagem("Erro", msg(ex)); }
    }

    public static void venderPeca(Estoque e, Runnable aoSalvar) {
        try {
            Paleta p = paletaAtual();
            Stage janela = criarJanelaTematica();
            VBox cartao = criarCartaoTematico(400, p);
            cartao.setSpacing(10);
            TextField qtd = campo(p, "Quantidade a vender");
            Label erro = labelErro();
            Button ok = botaoPrimario("Vender", p);
            ok.setOnAction(ev -> {
                try {
                    int q = Integer.parseInt(qtd.getText().trim());
                    OficinaService.venderPecaSeparada(e, q);
                    fecharOk(janela, aoSalvar, "Venda registrada!");
                } catch (Exception ex) { erro.setText(msg(ex)); }
            });
            Button cancelar = botaoSecundario("Cancelar", p);
            cancelar.setOnAction(x -> janela.close());
            cartao.getChildren().addAll(criarTitulo("Vender: " + e.getProduto(), p),
                    rotulo("Quantidade (disp: " + e.getQuantidade() + ")", p), qtd, erro, botoes(cancelar, ok));
            exibirJanela(janela, cartao);
        } catch (Exception ex) { mostrarMensagem("Erro", msg(ex)); }
    }

    public static void adicionarPecaVeiculo(Runnable aoSalvar) {
        try {
            garantir();
            List<Cliente> clientes = OficinaService.oficina().getClientes();
            List<Estoque> estoque = OficinaService.oficina().getEstoque();
            if (clientes.isEmpty() || estoque.isEmpty()) {
                mostrarMensagem("Peças", "É necessário ter clientes e peças no estoque.");
                return;
            }
            Paleta p = paletaAtual();
            Stage janela = criarJanelaTematica();
            VBox cartao = criarCartaoTematico(460, p);
            cartao.setSpacing(10);

            ComboBox<Cliente> cbCli = comboClientes(clientes, p);
            ComboBox<Veiculo> cbVei = new ComboBox<>();
            cbVei.setMaxWidth(Double.MAX_VALUE);
            cbVei.setPrefHeight(42);
            estiloCombo(cbVei, p);
            cbCli.valueProperty().addListener((o, a, n) -> {
                cbVei.getItems().clear();
                if (n != null) cbVei.getItems().addAll(n.getCarros());
                if (!cbVei.getItems().isEmpty()) cbVei.getSelectionModel().selectFirst();
            });
            if (!clientes.isEmpty()) {
                cbCli.getSelectionModel().selectFirst();
                cbVei.getItems().addAll(clientes.get(0).getCarros());
                if (!cbVei.getItems().isEmpty()) cbVei.getSelectionModel().selectFirst();
            }
            cbVei.setCellFactory(lv -> new ListCell<>() {
                @Override protected void updateItem(Veiculo item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getModelo() + " (" + item.getPlaca() + ")");
                    pintarCelula(this, p);
                }
            });
            cbVei.setButtonCell(new ListCell<>() {
                @Override protected void updateItem(Veiculo item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getModelo() + " (" + item.getPlaca() + ")");
                    pintarCelula(this, p);
                }
            });

            ComboBox<Estoque> cbPeca = new ComboBox<>();
            cbPeca.getItems().addAll(estoque);
            cbPeca.setMaxWidth(Double.MAX_VALUE);
            cbPeca.setPrefHeight(42);
            estiloCombo(cbPeca, p);
            cbPeca.setCellFactory(lv -> new ListCell<>() {
                @Override protected void updateItem(Estoque item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getProduto() + " (qtd " + item.getQuantidade() + ")");
                }
            });
            cbPeca.setButtonCell(new ListCell<>() {
                @Override protected void updateItem(Estoque item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getProduto() + " (qtd " + item.getQuantidade() + ")");
                }
            });
            if (!estoque.isEmpty()) cbPeca.getSelectionModel().selectFirst();

            TextField qtd = campo(p, "1");
            Label erro = labelErro();
            Button ok = botaoPrimario("Adicionar ao veículo", p);
            ok.setOnAction(e -> {
                try {
                    Cliente c = cbCli.getValue();
                    Veiculo v = cbVei.getValue();
                    Estoque pe = cbPeca.getValue();
                    if (c == null || v == null || pe == null) { erro.setText("Selecione cliente, veículo e peça."); return; }
                    int q = Integer.parseInt(qtd.getText().trim());
                    OficinaService.adicionarPecaAoVeiculo(c, v, pe, q);
                    fecharOk(janela, aoSalvar, "Peça adicionada ao veículo!");
                } catch (Exception ex) { erro.setText(msg(ex)); }
            });
            Button cancelar = botaoSecundario("Cancelar", p);
            cancelar.setOnAction(x -> janela.close());
            cartao.getChildren().addAll(criarTitulo("Adicionar peça ao veículo", p),
                    rotulo("Cliente", p), cbCli, rotulo("Veículo", p), cbVei,
                    rotulo("Peça", p), cbPeca, rotulo("Quantidade", p), qtd,
                    erro, botoes(cancelar, ok));
            exibirJanela(janela, cartao);
        } catch (Exception ex) { mostrarMensagem("Erro", msg(ex)); }
    }

    // ---------- SERVIÇO CATÁLOGO ----------
    public static void cadastrarServico(Runnable aoSalvar) { formServico(null, aoSalvar); }
    public static void editarServico(Servico s, Runnable aoSalvar) { formServico(s, aoSalvar); }

    private static void formServico(Servico existente, Runnable aoSalvar) {
        try {
            garantir();
            Paleta p = paletaAtual();
            Stage janela = criarJanelaTematica();
            VBox cartao = criarCartaoTematico(440, p);
            cartao.setSpacing(10);
            TextField nome = campo(p, "Nome do serviço");
            TextField preco = campo(p, "0.00");
            if (existente != null) {
                nome.setText(existente.getNome());
                preco.setText(String.valueOf(existente.getPreco()));
            }
            Label erro = labelErro();
            Button salvar = botaoPrimario("Salvar", p);
            salvar.setOnAction(e -> {
                try {
                    if (vazio(nome, preco)) { erro.setText("Preencha todos os campos."); return; }
                    double pr = Double.parseDouble(preco.getText().trim().replace(',', '.'));
                    if (existente == null) OficinaService.cadastrarServicoCatalogo(nome.getText(), pr);
                    else OficinaService.editarServicoCatalogo(existente, nome.getText(), pr);
                    fecharOk(janela, aoSalvar, "Serviço salvo!");
                } catch (Exception ex) { erro.setText(msg(ex)); }
            });
            Button cancelar = botaoSecundario("Cancelar", p);
            cancelar.setOnAction(x -> janela.close());
            cartao.getChildren().addAll(criarTitulo(existente == null ? "Novo serviço" : "Editar serviço", p),
                    rotulo("Nome", p), nome, rotulo("Preço", p), preco, erro, botoes(cancelar, salvar));
            exibirJanela(janela, cartao);
        } catch (Exception ex) { mostrarMensagem("Erro", msg(ex)); }
    }

    /** Cria ordem: cliente + veículo + serviço catálogo + mecânico */
    public static void criarOrdemServico(Runnable aoSalvar) {
        try {
            garantir();
            List<Cliente> clientes = OficinaService.oficina().getClientes();
            List<Servico> cat = OficinaService.oficina().getCatalogoServicos();
            List<Mecanico> mecs = OficinaService.oficina().getMecanicos();
            if (clientes.isEmpty() || cat.isEmpty()) {
                mostrarMensagem("Ordem", "Cadastre clientes e serviços no catálogo antes.");
                return;
            }
            Paleta p = paletaAtual();
            Stage janela = criarJanelaTematica();
            VBox cartao = criarCartaoTematico(480, p);
            cartao.setSpacing(10);

            ComboBox<Cliente> cbCli = comboClientes(clientes, p);
            ComboBox<Veiculo> cbVei = new ComboBox<>();
            cbVei.setMaxWidth(Double.MAX_VALUE); cbVei.setPrefHeight(42); estiloCombo(cbVei, p);
            cbCli.valueProperty().addListener((o, a, n) -> {
                cbVei.getItems().clear();
                if (n != null) cbVei.getItems().addAll(n.getCarros());
                if (!cbVei.getItems().isEmpty()) cbVei.getSelectionModel().selectFirst();
            });
            cbVei.setCellFactory(lv -> new ListCell<>() {
                @Override protected void updateItem(Veiculo item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getModelo() + " (" + item.getPlaca() + ")");
                    pintarCelula(this, p);
                }
            });
            cbVei.setButtonCell(new ListCell<>() {
                @Override protected void updateItem(Veiculo item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getModelo() + " (" + item.getPlaca() + ")");
                    pintarCelula(this, p);
                }
            });
            if (!clientes.isEmpty()) {
                cbCli.getSelectionModel().selectFirst();
                cbVei.getItems().addAll(clientes.get(0).getCarros());
                if (!cbVei.getItems().isEmpty()) cbVei.getSelectionModel().selectFirst();
            }

            ComboBox<Servico> cbSrv = new ComboBox<>();
            cbSrv.getItems().addAll(cat);
            cbSrv.setMaxWidth(Double.MAX_VALUE); cbSrv.setPrefHeight(42); estiloCombo(cbSrv, p);
            cbSrv.setCellFactory(lv -> new ListCell<>() {
                @Override protected void updateItem(Servico item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getNome() + " — " + OficinaService.formatarMoeda(item.getPreco()));
                    pintarCelula(this, p);
                }
            });
            cbSrv.setButtonCell(new ListCell<>() {
                @Override protected void updateItem(Servico item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getNome() + " — " + OficinaService.formatarMoeda(item.getPreco()));
                    pintarCelula(this, p);
                }
            });
            if (!cat.isEmpty()) cbSrv.getSelectionModel().selectFirst();

            ComboBox<Mecanico> cbMec = new ComboBox<>();
            cbMec.getItems().addAll(mecs);
            cbMec.setMaxWidth(Double.MAX_VALUE); cbMec.setPrefHeight(42); estiloCombo(cbMec, p);
            cbMec.setCellFactory(lv -> new ListCell<>() {
                @Override protected void updateItem(Mecanico item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getNome());
                    pintarCelula(this, p);
                }
            });
            cbMec.setButtonCell(new ListCell<>() {
                @Override protected void updateItem(Mecanico item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getNome());
                    pintarCelula(this, p);
                }
            });
            if (!mecs.isEmpty()) cbMec.getSelectionModel().selectFirst();

            Label erro = labelErro();
            Button ok = botaoPrimario("Criar ordem", p);
            ok.setOnAction(e -> {
                try {
                    Cliente c = cbCli.getValue();
                    Veiculo v = cbVei.getValue();
                    Servico s = cbSrv.getValue();
                    Mecanico m = cbMec.getValue();
                    if (c == null || v == null || s == null) { erro.setText("Selecione cliente, veículo e serviço."); return; }
                    if (c.getCarros().stream().noneMatch(x -> x == v)) { erro.setText("Veículo não pertence ao cliente."); return; }
                    OficinaService.vincularServicoAoVeiculo(c, v, s, m);
                    fecharOk(janela, aoSalvar, "Ordem de serviço criada (AGENDADO)!");
                } catch (Exception ex) { erro.setText(msg(ex)); }
            });
            Button cancelar = botaoSecundario("Cancelar", p);
            cancelar.setOnAction(x -> janela.close());
            cartao.getChildren().addAll(criarTitulo("Nova ordem de serviço", p),
                    rotulo("Cliente", p), cbCli, rotulo("Veículo", p), cbVei,
                    rotulo("Serviço (catálogo)", p), cbSrv, rotulo("Mecânico", p), cbMec,
                    erro, botoes(cancelar, ok));
            exibirJanela(janela, cartao);
        } catch (Exception ex) { mostrarMensagem("Erro", msg(ex)); }
    }

    // ---------- MECÂNICO ----------
    public static void cadastrarMecanico(Runnable aoSalvar) { formMecanico(null, aoSalvar); }
    public static void editarMecanico(Mecanico m, Runnable aoSalvar) { formMecanico(m, aoSalvar); }

    private static void formMecanico(Mecanico existente, Runnable aoSalvar) {
        try {
            garantir();
            Paleta p = paletaAtual();
            Stage janela = criarJanelaTematica();
            VBox cartao = criarCartaoTematico(440, p);
            cartao.setSpacing(10);
            TextField nome = campo(p, "Nome do mecânico");
            TextField salario = campo(p, "0.00");
            TextField login = campo(p, "email da conta (opcional)");
            if (existente != null) {
                nome.setText(existente.getNome());
                salario.setText(String.valueOf(existente.getSalario()));
                login.setText(existente.getLoginVinculado());
            }
            Label dica = new Label("Login vinculado: e-mail da conta de funcionário para ver as tarefas no painel.");
            dica.setWrapText(true);
            dica.setStyle("-fx-text-fill: " + p.textoTerc() + "; -fx-font-size: 11px;");
            Label erro = labelErro();
            Button salvar = botaoPrimario("Salvar", p);
            salvar.setOnAction(e -> {
                try {
                    if (vazio(nome, salario)) { erro.setText("Preencha nome e salário."); return; }
                    double s = Double.parseDouble(salario.getText().trim().replace(',', '.'));
                    String lg = login.getText() == null ? "" : login.getText().trim();
                    if (existente == null) OficinaService.cadastrarMecanico(nome.getText(), s, lg);
                    else OficinaService.editarMecanico(existente, nome.getText(), s, lg);
                    fecharOk(janela, aoSalvar, "Mecânico salvo!");
                } catch (Exception ex) { erro.setText(msg(ex)); }
            });
            Button cancelar = botaoSecundario("Cancelar", p);
            cancelar.setOnAction(x -> janela.close());
            cartao.getChildren().addAll(criarTitulo(existente == null ? "Novo mecânico" : "Editar mecânico", p),
                    rotulo("Nome", p), nome, rotulo("Salário", p), salario,
                    rotulo("Login da conta (opcional)", p), login, dica, erro, botoes(cancelar, salvar));
            exibirJanela(janela, cartao);
        } catch (Exception ex) { mostrarMensagem("Erro", msg(ex)); }
    }


    /** Resumo financeiro e veículos do cliente (equivalente ao "Detalhes do pedido"). */
    public static void detalhesCliente(Cliente c) {
        if (c == null) return;
        try {
            Paleta p = paletaAtual();
            Stage janela = criarJanelaTematica();
            VBox cartao = criarCartaoTematico(520, p);
            cartao.setSpacing(10);
            cartao.setAlignment(Pos.TOP_LEFT);

            StringBuilder sb = new StringBuilder();
            sb.append("Nome: ").append(c.getNome()).append("\n");
            sb.append("CPF: ").append(c.getCpf()).append("\n");
            sb.append("Telefone: ").append(c.getTelefone()).append("\n");
            sb.append("Status: ").append(c.getStatus() != null ? c.getStatus().name() : "—").append("\n");
            sb.append("Veículos: ").append(c.getCarros().size()).append("\n\n");

            double totalServ = 0, totalPecas = 0;
            boolean temItens = false;
            for (Veiculo v : c.getCarros()) {
                sb.append("—— ").append(v.getModelo()).append(" (").append(v.getPlaca()).append(") ——\n");
                for (Servico s : v.getServicos()) {
                    temItens = true;
                    totalServ += s.getPreco();
                    String mecs = s.getMecanicos().isEmpty() ? "sem mecânico" :
                            s.getMecanicos().stream().map(Mecanico::getNome).reduce((a, b) -> a + ", " + b).orElse("");
                    sb.append("  Serviço: ").append(s.getNome())
                      .append(" | ").append(OficinaService.formatarMoeda(s.getPreco()))
                      .append(" | ").append(s.getStatus().name())
                      .append(" | ").append(mecs).append("\n");
                }
                for (PecaUtilizada pe : v.getPecasUtilizadas()) {
                    temItens = true;
                    totalPecas += pe.getSubtotal();
                    sb.append("  Peça: ").append(pe.getNome())
                      .append(" x").append(pe.getQuantidade())
                      .append(" = ").append(OficinaService.formatarMoeda(pe.getSubtotal())).append("\n");
                }
                if (v.getServicos().isEmpty() && v.getPecasUtilizadas().isEmpty()) {
                    sb.append("  (sem serviços/peças)\n");
                }
                sb.append("\n");
            }
            double mao = temItens ? Orcamento.TAXA_FIXA_MAO_DE_OBRA : 0;
            sb.append("Total serviços: ").append(OficinaService.formatarMoeda(totalServ)).append("\n");
            sb.append("Total peças: ").append(OficinaService.formatarMoeda(totalPecas)).append("\n");
            sb.append("Mão de obra: ").append(OficinaService.formatarMoeda(mao)).append("\n");
            sb.append("TOTAL: ").append(OficinaService.formatarMoeda(totalServ + totalPecas + mao));

            Label corpo = new Label(sb.toString());
            corpo.setWrapText(true);
            corpo.setStyle("-fx-text-fill: " + p.texto() + "; -fx-font-size: 12px;");
            ScrollPane scroll = new ScrollPane(corpo);
            scroll.setFitToWidth(true);
            scroll.setPrefHeight(360);
            scroll.setStyle("-fx-background: transparent; -fx-background-color: transparent;");

            Button fechar = botaoPrimario("Fechar", p);
            fechar.setOnAction(e -> janela.close());

            cartao.getChildren().addAll(criarTitulo("Detalhes do pedido", p), scroll, fechar);
            exibirJanela(janela, cartao);
        } catch (Exception ex) {
            mostrarMensagem("Erro", msg(ex));
        }
    }


    /** Alterar ou remover peça já utilizada em um veículo (opções 7 parcial e 9 do menu estoque). */
    public static void gerenciarPecasVeiculo(Runnable aoSalvar) {
        try {
            garantir();
            List<Cliente> clientes = OficinaService.oficina().getClientes();
            if (clientes.isEmpty()) {
                mostrarMensagem("Peças no veículo", "Não há clientes cadastrados.");
                return;
            }
            Paleta p = paletaAtual();
            Stage janela = criarJanelaTematica();
            VBox cartao = criarCartaoTematico(480, p);
            cartao.setSpacing(10);

            ComboBox<Cliente> cbCli = comboClientes(clientes, p);
            ComboBox<Veiculo> cbVei = new ComboBox<>();
            cbVei.setMaxWidth(Double.MAX_VALUE); cbVei.setPrefHeight(42); estiloCombo(cbVei, p);
            ComboBox<PecaUtilizada> cbPeca = new ComboBox<>();
            cbPeca.setMaxWidth(Double.MAX_VALUE); cbPeca.setPrefHeight(42); estiloCombo(cbPeca, p);

            Runnable refreshPecas = () -> {
                cbPeca.getItems().clear();
                Veiculo v = cbVei.getValue();
                if (v != null) cbPeca.getItems().addAll(v.getPecasUtilizadas());
                if (!cbPeca.getItems().isEmpty()) cbPeca.getSelectionModel().selectFirst();
            };
            cbCli.valueProperty().addListener((o, a, n) -> {
                cbVei.getItems().clear();
                if (n != null) cbVei.getItems().addAll(n.getCarros());
                if (!cbVei.getItems().isEmpty()) cbVei.getSelectionModel().selectFirst();
                refreshPecas.run();
            });
            cbVei.valueProperty().addListener((o, a, n) -> refreshPecas.run());
            cbVei.setCellFactory(lv -> new ListCell<>() {
                @Override protected void updateItem(Veiculo item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getModelo() + " (" + item.getPlaca() + ")");
                    pintarCelula(this, p);
                }
            });
            cbVei.setButtonCell(new ListCell<>() {
                @Override protected void updateItem(Veiculo item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getModelo() + " (" + item.getPlaca() + ")");
                    pintarCelula(this, p);
                }
            });
            cbPeca.setCellFactory(lv -> new ListCell<>() {
                @Override protected void updateItem(PecaUtilizada item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getNome() + " x" + item.getQuantidade()
                            + " = " + OficinaService.formatarMoeda(item.getSubtotal()));
                }
            });
            cbPeca.setButtonCell(new ListCell<>() {
                @Override protected void updateItem(PecaUtilizada item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getNome() + " x" + item.getQuantidade());
                }
            });
            if (!clientes.isEmpty()) {
                cbCli.getSelectionModel().selectFirst();
                cbVei.getItems().addAll(clientes.get(0).getCarros());
                if (!cbVei.getItems().isEmpty()) cbVei.getSelectionModel().selectFirst();
                refreshPecas.run();
            }

            TextField novaQtd = campo(p, "Nova quantidade");
            Label erro = labelErro();

            Button alterar = botaoPrimario("Alterar quantidade", p);
            alterar.setOnAction(e -> {
                try {
                    Veiculo v = cbVei.getValue();
                    PecaUtilizada pu = cbPeca.getValue();
                    if (v == null || pu == null) { erro.setText("Selecione veículo e peça."); return; }
                    int q = Integer.parseInt(novaQtd.getText().trim());
                    OficinaService.alterarPecaNoVeiculo(v, pu, q);
                    fecharOk(janela, aoSalvar, "Quantidade atualizada (estoque ajustado)!");
                } catch (Exception ex) { erro.setText(msg(ex)); }
            });
            Button remover = botaoSecundario("Remover do veículo (devolver estoque)", p);
            remover.setOnAction(e -> {
                try {
                    Veiculo v = cbVei.getValue();
                    PecaUtilizada pu = cbPeca.getValue();
                    if (v == null || pu == null) { erro.setText("Selecione veículo e peça."); return; }
                    OficinaService.removerPecaDoVeiculo(v, pu);
                    fecharOk(janela, aoSalvar, "Peça removida e devolvida ao estoque!");
                } catch (Exception ex) { erro.setText(msg(ex)); }
            });
            Button cancelar = botaoSecundario("Cancelar", p);
            cancelar.setOnAction(x -> janela.close());

            HBox rowBtns = new HBox(10, cancelar, remover, alterar);
            cartao.getChildren().addAll(
                    criarTitulo("Peças utilizadas no veículo", p),
                    rotulo("Cliente", p), cbCli, rotulo("Veículo", p), cbVei,
                    rotulo("Peça no veículo", p), cbPeca,
                    rotulo("Nova quantidade (para alterar)", p), novaQtd,
                    erro, rowBtns
            );
            exibirJanela(janela, cartao);
        } catch (Exception ex) {
            mostrarMensagem("Erro", msg(ex));
        }
    }

    // ---------- helpers ----------
    private static void garantir() {
        SingleTon.getInstancia().getOficina();
    }

    private static void fecharOk(Stage janela, Runnable aoSalvar, String msg) {
        janela.close();
        Platform.runLater(() -> {
            try { if (aoSalvar != null) aoSalvar.run(); }
            catch (Exception ex) { mostrarMensagem("Erro", msg(ex)); return; }
            mostrarMensagem("Sucesso", msg);
        });
    }

    private static ComboBox<Cliente> comboClientes(List<Cliente> clientes, Paleta p) {
        ComboBox<Cliente> combo = new ComboBox<>();
        combo.getItems().setAll(clientes);
        combo.setMaxWidth(Double.MAX_VALUE);
        combo.setPrefHeight(42);
        estiloCombo(combo, p);
        combo.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Cliente item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getNome() + " — " + item.getCpf());
                pintarCelula(this, p);
            }
        });
        combo.setButtonCell(new ListCell<>() {
            @Override protected void updateItem(Cliente item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getNome() + " — " + item.getCpf());
                pintarCelula(this, p);
            }
        });
        if (!clientes.isEmpty()) combo.getSelectionModel().selectFirst();
        return combo;
    }

    /** Campo pesquisável: filtra as opções em tempo real e mantém a aparência do tema. */
    private static void configurarComboVeiculo(ComboBox<String> combo,
            java.util.function.Supplier<List<String>> fonte, Paleta p) {
        combo.setEditable(true);
        combo.setPrefHeight(42);
        combo.setMaxWidth(Double.MAX_VALUE);
        combo.setStyle("-fx-background-color: " + p.overlay() + "0.12); -fx-background-radius: 12; "
                + "-fx-border-color: " + p.borda() + "; -fx-border-radius: 12; "
                + "-fx-control-inner-background: " + p.fundoCartao() + "; -fx-text-fill: " + p.texto() + ";");
        combo.getEditor().setStyle("-fx-background-color: transparent; -fx-text-fill: " + p.texto()
                + "; -fx-prompt-text-fill: " + p.textoTerc() + "; -fx-highlight-fill: " + p.botaoFundo()
                + "; -fx-highlight-text-fill: white; -fx-padding: 0 8;");
        combo.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item);
                setStyle("-fx-background-color: " + p.fundoCartao() + "; -fx-text-fill: " + p.texto() + "; -fx-padding: 8 10;");
            }
        });
        combo.setButtonCell(new ListCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item);
                setStyle("-fx-background-color: transparent; -fx-text-fill: " + p.texto() + ";");
            }
        });
        final boolean[] filtrando = {false};
        combo.getEditor().textProperty().addListener((obs, anterior, digitado) -> {
            if (filtrando[0]) return;
            List<String> todas = fonte.get();
            String busca = normalizarFiltro(digitado);
            List<String> filtradas = busca.isEmpty() ? todas : todas.stream()
                    .filter(op -> normalizarFiltro(op).contains(busca))
                    .limit(80).toList();
            filtrando[0] = true;
            try {
                combo.getItems().setAll(filtradas);
                if (digitado != null) {
                    combo.getEditor().setText(digitado);
                    combo.getEditor().positionCaret(digitado.length());
                }
            } finally { filtrando[0] = false; }
            if (!busca.isEmpty() && !filtradas.isEmpty() && combo.getScene() != null && combo.isFocused()) {
                if (!combo.isShowing()) combo.show();
            } else if (busca.isEmpty() && combo.isShowing()) {
                combo.hide();
            }
        });
        combo.focusedProperty().addListener((obs, antes, focado) -> {
            if (!focado && combo.getEditor().getText().isBlank()) combo.getItems().setAll(fonte.get());
        });
        combo.getItems().setAll(fonte.get());
    }

    private static String normalizarFiltro(String texto) {
        if (texto == null) return "";
        return java.text.Normalizer.normalize(texto, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").toLowerCase(java.util.Locale.ROOT)
                .replaceAll("[^a-z0-9]+", " ").trim().replaceAll("\\s+", " ");
    }

    private static void estiloCombo(ComboBox<?> c, Paleta p) {
        c.setStyle(
                "-fx-background-color: " + p.overlay() + "0.14);" +
                "-fx-background-radius: 12;" +
                "-fx-border-color: " + p.borda() + ";" +
                "-fx-border-radius: 12;" +
                "-fx-border-width: 1;" +
                "-fx-text-fill: " + p.texto() + ";" +
                "-fx-prompt-text-fill: " + p.textoSec() + ";"
        );
    }

    /** Aplica cor de texto do tema em qualquer ListCell de combo (modo escuro legível). */
    private static <T> void pintarCelula(ListCell<T> cell, Paleta p) {
        cell.setTextFill(javafx.scene.paint.Color.web(p.texto()));
        cell.setStyle("-fx-text-fill: " + p.texto() + "; -fx-background-color: transparent; -fx-padding: 8 10;");
    }

    private static HBox botoes(Button cancelar, Button salvar) {
        cancelar.setMaxWidth(Double.MAX_VALUE);
        salvar.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(cancelar, Priority.ALWAYS);
        HBox.setHgrow(salvar, Priority.ALWAYS);
        return new HBox(10, cancelar, salvar);
    }

    private static TextField campo(Paleta p, String prompt) {
        TextField t = new TextField();
        t.setPromptText(prompt);
        t.setPrefHeight(42);
        t.setMaxWidth(Double.MAX_VALUE);
        t.setStyle("-fx-background-color: " + p.overlay() + "0.12); -fx-text-fill: " + p.texto()
                + "; -fx-prompt-text-fill: " + p.textoTerc() + "; -fx-background-radius: 12; -fx-border-color: "
                + p.borda() + "; -fx-border-radius: 12; -fx-padding: 0 12;");
        return t;
    }

    private static Label rotulo(String texto, Paleta p) {
        Label l = new Label(texto);
        l.setStyle("-fx-text-fill: " + p.textoSec() + "; -fx-font-size: 11px;");
        return l;
    }

    private static Label labelErro() {
        Label l = new Label("");
        l.setWrapText(true);
        l.setStyle("-fx-text-fill: #ff6b6b; -fx-font-size: 12px;");
        return l;
    }

    private static boolean vazio(TextField... campos) {
        for (TextField c : campos) if (c.getText() == null || c.getText().isBlank()) return true;
        return false;
    }

    private static String msg(Throwable ex) {
        return ex.getMessage() != null ? ex.getMessage() : ex.getClass().getSimpleName();
    }
}
